# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
#
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

def gSearch(fringe, problem, heuristic = None): #a general search function that checks for what type of data structure is used to determine how to manipulate the data
    currentPop = [] #a list to keep all of the popped items from fringe
    expanded = [] #list to keep all of the states we expanded

    if isinstance(fringe, util.Stack) or isinstance(fringe, util.Queue): #an if else statement to check if they are a bfs or dfs since they dont use a heuristic
        fringe.push((problem.getStartState(), 0, [])) #push the start state onto the fringe stack
    else:
        fringe.push((problem.getStartState(), [], 0), heuristic(problem.getStartState(), problem)) #push the start state and heuristic onto the fringe queue

    while fringe:#loop to pop and push the path onto the stack
        currentPop = fringe.pop() #pops the fringe to the current stack
        #print currentPop[0]
        #print currentPop[1]
        #print currentPop[2]
        if isinstance(fringe, util.Stack) or isinstance(fringe, util.Queue):
            cState = currentPop[0] #next 2 lines are for assigning state and path to their relative value from the item just popped.
            cPath = currentPop[2]
        else:
            cState = currentPop[0] #next 3 lines are for assigning state, path, and cost to their relative values
            cPath = currentPop[1]
            cCost = currentPop[2]

        if cState not in expanded:#checks if the recently popped items are in the expanded list
            expanded.append(cState) #adds the new Coordinate into the expanded list
            if problem.isGoalState(cState):#checks if the expanding node is a goal state
                return cPath #this is the exit from the function, leaves when it finds the goal state and returns the path to it
            successorsList = problem.getSuccessors(cState) #this is the actual expantion of the node, looking at its successors
            #print successorsList
            for item in successorsList:
                if item[0] not in expanded:
                    if isinstance(fringe, util.Stack) or isinstance(fringe, util.Queue):#an if else statement to check if they are a bfs or dfs since they dont use a heuristic
                        fringe.push((item[0], item[1], cPath + [item[1]]))#pushes the nonexpanded state and pushes it on top of the stack
                    else:
                        fringe.push((item[0], cPath + [item[1]], cCost + item[2]), cCost + item[2] + heuristic(item[0], problem))#push the next state and heuristic onto the fringe queue
    return []

def depthFirstSearch(problem):
    """
    print "Start:", problem.getStartState()
    print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    print "Start's successors:", problem.getSuccessors(problem.getStartState())
    """
    "*** YOUR CODE HERE ***"

    fringe = util.Stack() #initialize a stack to put the states on
    return gSearch(fringe, problem) #use general search function, nullHeuristic doesnt do anything its just a filler

def breadthFirstSearch(problem):
    """Search the shallowest nodes in the search tree first."""
    "*** YOUR CODE HERE ***"

    fringe = util.Queue() #initialize a queue to put the states on
    return gSearch(fringe, problem) #use general search function, nullHeuristic doesnt do anything its just a filler

def uniformCostSearch(problem):
    """Search the node of least total cost first."""
    "*** YOUR CODE HERE ***"

    fringe = util.PriorityQueue() #initialize a priority queue to put the states on
    return gSearch(fringe, problem, nullHeuristic) #use general search function with a nullHeuristic

def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""
    "*** YOUR CODE HERE ***"

    fringe = util.PriorityQueue() #initialize a priority queue to put the states on
    return gSearch(fringe, problem, heuristic) #use general search function with a heuristic


# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
