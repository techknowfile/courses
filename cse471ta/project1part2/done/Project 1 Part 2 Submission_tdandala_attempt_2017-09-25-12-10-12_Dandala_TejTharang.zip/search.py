# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]



def depthFirstSearch(problem):
    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches the
    goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:
	"""
    #print "Start:", problem.getStartState()
    #print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    #print "Start's successors:", problem.getSuccessors(problem.getStartState())
    
    
    
    "*** YOUR CODE HERE ***"
    """
    vis is a dictionary that is used to check if a state has already been visited
    If visited, the key will be the state and the value will be marked as "True"   
    """
    vis = {}
    # If the start state is the goal state, no actions are required and an empty list is returned    
    if problem.isGoalState(problem.getStartState()):
	    return []
    """
	A stack is used to store all nodes that need to be expanded
	Any new state that is added will be added to the end of the stack and since DFS follows LIFO
	policy, the newly added states are expanded first
    """
    queueForDfs = util.Stack()
    """
    The list "o" is used to store the logical sequence of actions the is returned towards the end
    after the goal state is reached.
    
    """
    o = [problem.getStartState()]
    """
    l is a temporary list that is used time and again to store successors of a state and add them 
    to the list of nodes to be expanded
    """
    l = problem.getSuccessors(problem.getStartState())
    """
    In the next piece of code, the start node is visited and then expanded for children.
	""" 
    vis[problem.getStartState()] = True
    for i in l:
        queueForDfs.push(i)
        o.append(i)
    l = []
    actions = []
    """
    From here on every node is being expanded according to its stading in the DFS LIFO queue 
    """
    while not queueForDfs.isEmpty():
        # qpop is the node that is being popped from the queue
        qpop = queueForDfs.pop()

        opop = o.pop()
        """
        If the current state is already present in the queue, then the program neglects it and
        goes to the next iteration i.e. it goes to the next state in the queue
        """
        if qpop[0] in vis:
        	continue
        """
        If the sequence of states in the queue is not the same as in o, the actions is invalid
        and both the most recent action and the state in q are popped.
        This process repeats till the states popped from the queue and the list o are the same.
        """
        while qpop[0]!=opop[0]:
            opop = o.pop()
            actions.pop()
        """
        If the popped states in both the queue and o are equal then the action is added to the 
        list of actions.
        """
        if qpop[0]==opop[0]:
            actions.append(qpop[1])
        """
        The state which is to be expanded next is marked as visited and if it is the goal state,
        the actions are returned.
        """
        vis[qpop[0]] = True
        if problem.isGoalState(qpop[0]):            
            return actions
        else:
#
            l = problem.getSuccessors(qpop[0])
            for i in l:
                if i[0] in vis:
                    l.remove(i)	
            #strongly feel something should be done here
            """
            If the node that is expanded is the leaf node, the action that leads to that node is 
            taken out of the list of nodes
            Else, the node is expanded and the children are added to the queue
            """
            if len(l)==0:
                actions.pop()
            
            else :
                o.append(opop) 
                for i in l:
                    if i[0] not in vis:
                    ##if i[0] not in problem._visited:
                        queueForDfs.push(i)
                        o.append(i)
                l = []
    return actions
    
    util.raiseNotDefined()

def breadthFirstSearch(problem):
    """Search the shallowest nodes in the search tree first."""
    #print "Start:", problem.getStartState()
    #print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    "*** YOUR CODE HERE ***"
    """
    vis is a list that is used to check if a state has already been visited
    If visited, the key will be the state and the value will be marked as "True"
    """
    vis = []
    """
    This dictionary keeps track of where each node originated from while initially
    expanding the tree
    """
    keepingtrack = {}
    """
    If the start state is the goal state, no actions are required and an empty list is returned
    """
    if problem.isGoalState(problem.getStartState()):
        return []
    """
    In BFS, we use a FIFO queue
    """
    queue = util.Queue()
    """
    l is a temporary list that is used time and again to store successors of a state and add them 
    to the list of nodes to be expanded
    """
    l = problem.getSuccessors(problem.getStartState())
    """
    In the next piece of code, the start node is visited and then expanded for children.
    """
    vis.append(problem.getStartState())
    for i in l:
        queue.push(i)
        """
        The following step is to make the children of the root node or the start node store the root
        as their origin
        """
        keepingtrack[i] = (problem.getStartState())
    l = []
    actions = []
    """
    From here on every node is being expanded according to its stading in the DFS LIFO queue
    """
    while not queue.isEmpty():
        qpop = queue.pop()
        """
        If a node expanded from the queue is found to have already been visited, it is ignored and the 
        next node is considered.
        """
        if qpop[0] in vis:
            continue
        
        actions = []
        """
        If the node popped from the queue has already been tracked, the actions leading to that node from
        the start node are reconstructed
        """
        if qpop in keepingtrack:
            temp = qpop
                
            while temp in keepingtrack:
                actions.insert(0,temp[1])
                temp = keepingtrack[temp]
        """
        The node is then marked as visited
        """                
        vis.append(qpop[0])
         
        if problem.isGoalState(qpop[0]):
            
            
            return actions
            
        else:
            
            l = problem.getSuccessors(qpop[0])
            
            for i in l:
                
                if i[0] in vis:
                    l.remove(i)
                
            """
            If the node that is expanded is the leaf node, the action that leads to that node is 
            taken out of the list of nodes

            Else, the node is expanded and the children are added to the queue
            """
            
            if len(l) == 0:
                actions = []
            else:
                for i in l:
                    #if i[0] not in vis:
                        queue.push(i)
                        if i not in keepingtrack:
                            keepingtrack[i] = qpop
                l = []
    return actions
    util.raiseNotDefined()



def uniformCostSearch(problem):
    """Search the node of least total cost first."""
    "*** YOUR CODE HERE ***"
    """
    vis is a dictionary that is used to check if a state has already been visited
    If visited, the key will be the state and the value will be marked as "True"
    """
    vis = []
    """
    This dictionary keeps track of where each node originated from while initially
    expanding the tree
    """
    keepingTrackOfParents = {}
    actions = []
    """
    If the start state is the goal state, no actions are required and an empty list is returned
    """
    if problem.isGoalState(problem.getStartState()):
        return []
    """
    In the next piece of code, the start node is visited and then expanded for children.
    """
    vis.append(problem.getStartState())
    """
    In UCS, we use a priority queue because the cost of going to the next state has to be accounted
    for and has to be done in the lowest order
    """
    pQueue = util.PriorityQueue()
    """
    The successors to the start state are strored in l, a temporary list
    """
    l = problem.getSuccessors(problem.getStartState())
    """
    for every child in the start state, the succesors tracked and pushed into the queue according to 
    the edge costs
    """
    for i in l:
        actions.append(i[1]) 
        pQueue.push(i,problem.getCostOfActions(actions))
        keepingTrackOfParents[i] = (problem.getStartState())
        actions = []
    l = []
    """
    From here on every node is being expanded according to its stading in the priority in the priority queue
    """
    while not pQueue.isEmpty():
        qpop = pQueue.pop()
        """
        If a node expanded from the queue is found to have already been visited, it is ignored and the 
        next node is considered.
        """
        if qpop[0] in vis:
            continue
        actions = []
        """
        If the node popped from the queue has already been tracked, the actions leading to that node from
        the start node are reconstructed
        """
        if qpop in keepingTrackOfParents:
            temp = qpop
            while temp in keepingTrackOfParents:
                actions.insert(0,temp[1])
                temp = keepingTrackOfParents[temp]
        """
        The node is then marked as visited
        """
        vis.append(qpop[0])
        """
        If the goal state is reached, the actions are returned else, the node is expanded
        """

        if problem.isGoalState(qpop[0]):
            
    	    return actions
        else:
            l = problem.getSuccessors(qpop[0])
            for i in l:
                if i[0] in vis:
            	    l.remove(i)
            """
            If the node that is expanded is the leaf node, the action that leads to that node is 
            taken out of the list of nodes

            Else, the node is expanded and the children are added to the queue
            """
            if len(l) == 0:
        	    actions = []
            else:
                for i in l:
                    if i[0] not in vis:
                        if i not in keepingTrackOfParents:
                            keepingTrackOfParents[i] = qpop
                        if i in keepingTrackOfParents:	
                            actions = []
                            temp = i
                            while temp in keepingTrackOfParents:
                                actions.insert(0,temp[1])
                                temp = keepingTrackOfParents[temp]
                            pQueue.push(i,problem.getCostOfActions(actions))
                        
                        actions = []
                l = []
    return actions
    util.raiseNotDefined()

def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""
    "*** YOUR CODE HERE ***"
    """
    vis is a dictionary that is used to check if a state has already been visited
    If visited, the key will be the state and the value will be marked as "True"
    """
    vis = []
    """
    This dictionary keeps track of where each node originated from while initially
    expanding the tree
    """
    keepingTrackOfParents = {}
    actions = []
    """
    If the start state is the goal state, no actions are required and an empty list is returned
    """
    if problem.isGoalState(problem.getStartState()):
        return []
    """
    In the next piece of code, the start node is visited and then expanded for children.
    """
    vis.append(problem.getStartState())
    """
    In A-Star search, we use a priority queue because the cost of reaching a state and the cost to go have to be accounted
    for and has to be done in the lowest order
    """
    pQueue = util.PriorityQueue()
    """
    The successors to the start state are strored in l, a temporary list
    """
    l = problem.getSuccessors(problem.getStartState())
    """
    for every child in the start state, the succesors tracked and pushed into the queue according to 
    the edge costs and the cost to go. The function heuristic evaluates the cost to go
    """
    for i in l:
        actions.append(i[1]) 
        pQueue.push(i,problem.getCostOfActions(actions) + heuristic(i[0],problem))
        keepingTrackOfParents[i] = (problem.getStartState())
        actions = []
    l = []
    """
    From here on every node is being expanded according to its stading in the priority in the priority queue
    """
    while not pQueue.isEmpty():
        qpop = pQueue.pop()
        """
        If a node expanded from the queue is found to have already been visited, it is ignored and the 
        next node is considered.
        """
        if qpop[0] in vis:
            continue
        actions = []
        """
        If the node popped from the queue has already been tracked, the actions leading to that node from
        the start node are reconstructed
        """
        if qpop in keepingTrackOfParents:
            temp = qpop
            while temp in keepingTrackOfParents:
                actions.insert(0,temp[1])
                temp = keepingTrackOfParents[temp]
            """
            The node is then marked as visited
            """
        vis.append(qpop[0])
        """
        If the goal state is reached, the actions are returned else, the node is expanded
        """
        if problem.isGoalState(qpop[0]):
            return actions
        else:
            l = problem.getSuccessors(qpop[0])
            for i in l:
                if i[0] in vis:
                    l.remove(i)
            """
            If the node that is expanded is the leaf node, the action that leads to that node is 
            taken out of the list of nodes

            Else, the node is expanded and the children are added to the queue
            """
            if len(l) == 0:
                actions = []
            else:
                for i in l:
                    if i[0] not in vis:
                        if i not in keepingTrackOfParents:
                            keepingTrackOfParents[i] = qpop
                        if i in keepingTrackOfParents:  
                            actions = []
                            temp = i
                            while temp in keepingTrackOfParents:
                                actions.insert(0,temp[1])
                                temp = keepingTrackOfParents[temp]
                            
                            pQueue.push(i,problem.getCostOfActions(actions) + heuristic(i[0],problem))
                            
                        actions = []
                l = []
    return actions

    util.raiseNotDefined()

# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
