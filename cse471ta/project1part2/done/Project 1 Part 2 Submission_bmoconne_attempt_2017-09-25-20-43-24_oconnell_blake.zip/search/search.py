# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

def depthFirstSearch(problem):
    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches the
    goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:

    print "Start:", problem.getStartState()
    print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    print "Start's successors:", problem.getSuccessors(problem.getStartState())
    """
    "*** YOUR CODE HERE ***"

    fringe = util.Stack()  # dfs uses stack to store nodes
    fringe.push((problem.getStartState(),[], []))  # push the start state, empty sets for moves and seen nodes

    while not fringe.isEmpty():
        current,moves,seen = fringe.pop()  # pop top of stack, check if it is a goal, expand if not
        if problem.isGoalState(current):
            return moves  # return the list of moves if the popped node is the goal
        for pos,dir,cost in problem.getSuccessors(current):  # expansion loop
            if not pos in seen:
                fringe.push((pos,moves+[dir],seen+[pos]))  # only push nodes that are not already seen

    return []


def breadthFirstSearch(problem):
    """Search the shallowest nodes in the search tree first."""
    "*** YOUR CODE HERE ***"

    fringe = util.Queue()  # bfs uses queue to parse
    fringe.push((problem.getStartState(), []))  # push start state, empty list to contain moves

    # this is global seen list in bfs rather than in each node, important difference between bfs and dfs
    seen = [problem.getStartState()]  # we mark start state as seen immediately to avoid expansion later
    while not fringe.isEmpty():
        current, moves = fringe.pop()  # pop current node out of queue
        if problem.isGoalState(current):
            return moves  # if current node is goal state, return list of moves to get there
        for pos,dir,cost in problem.getSuccessors(current):  # very similar for loop to dfs
            if not pos in seen:
                fringe.push((pos,moves+[dir]))
                seen.append(pos)  # we append the node to seen here because it is global, unlike dfs
    return []



def uniformCostSearch(problem):
    """Search the node of least total cost first."""
    "*** YOUR CODE HERE ***"

    fringe = util.PriorityQueue()  # UCS will use priority queue based on cost
    fringe.push((problem.getStartState(), []), 0)  # push start state, moves, and cost which is obviously 0 to start

    seen = []  # global seen set, like bfs
    while not fringe.isEmpty():
        current, moves = fringe.pop()  # pops the next lowest cost node out of queue
        if problem.isGoalState(current):
            return moves  # if current node is goal, return the moves to get there
        if not current in seen:
            seen.append(current)  # we need this in case we see a goal state, as it will not be added in for loop
        for pos,dir,cost in problem.getSuccessors(current):  # very similar loop to above functions
            if not pos in seen:
                # pushes the node along with the cost
                fringe.push((pos,(moves + [dir])), problem.getCostOfActions(moves + [dir]))
                if not problem.isGoalState(pos):
                    seen.append(pos)  # main seen append, but wont catch goal states

    return []


def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""
    "*** YOUR CODE HERE ***"

    fringe = util.PriorityQueue()  # just like UCS, uses priority queue
    fringe.push((problem.getStartState(), []), 0)  # push start state, moves, cost + heuristic, which is 0 obviously

    seen = []  # again, global seen set
    while not fringe.isEmpty():
        current, moves = fringe.pop()  # pop current node
        if problem.isGoalState(current):
            return moves  # return if goal state
        if not current in seen:
            seen.append(current)  # same append as UCS
        for pos,dir,cost in problem.getSuccessors(current):  # similar for loop to above functions
            if not pos in seen:
                # push the node, moves, and f from g + h
                fringe.push((pos, (moves+[dir])), (problem.getCostOfActions(moves+[dir]) + heuristic(pos,problem)))
                if not problem.isGoalState(pos):
                    seen.append(pos)  # same append as UCS
    return []


# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
