# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util
import searchAgents

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

def depthFirstSearch(problem):
    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches the
    goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:

    print "Start:", problem.getStartState()
    print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    print "Start's successors:", problem.getSuccessors(problem.getStartState())
    """
    s = util.Stack()  # uses LIFO queue
    node_to_add = problem.getStartState()  # coordinates of starting position
    s.push(node_to_add)  # push initial position into stack
    closed_list = list()  # closed list of visited (expanded) nodes
    count_iterations = 0  # while-loop iterator
    while not s.isEmpty():  # DFS loops until the stack is empty
        popped = s.pop()  # last element in the stack is popped
        if count_iterations == 0:  # node being expanded is the start node, first iteration of while loop
            node_to_expand = popped  # popped value is just the coordinate
            direction_of_parent = list()  # no direction to get to start node
        else:  # all other iterations of while loop, popped value is coordinate and directions from root to node
            node_to_expand = popped[0]
            direction_of_parent = popped[1:]  # parent's direction is implemented as a list of strings
        if not problem.isGoalState(node_to_expand):  # stop when goal node is expanded
            closed_list.append(node_to_expand)  # add visited node to closed list
            start_successors = problem.getSuccessors(node_to_expand)  # list of expanded node's children to add to stack
            for (start_successor) in start_successors:  # go through each of these children individually
                if start_successor[0] not in closed_list:  # not yet visited
                    tuple_list = list()
                    tuple_list.append(start_successor[0])  # add coordinate to list that will go in stack
                    direction_list = list()  # include path to take to get to this node
                    if len(direction_of_parent) == 0:  # successor of start node
                        direction_list.append(start_successor[1])  # must append (rather than concatenate) str to list
                    else:
                        new_direction = list()
                        new_direction.append(start_successor[1]) # must append str to list
                        direction_list = direction_of_parent + new_direction # concatenate lists
                    push_list = tuple_list + direction_list  # put together coordinate and path
                    s.push(push_list)  # push all information
        else:  # goal node expanded
            return direction_of_parent  # path to get to goal node
        count_iterations += 1  # increment while-loop iterator


def breadthFirstSearch(problem):
    """Search the shallowest nodes in the search tree first."""
    # This method is almost exactly the same as DFS. This just uses a different queue strategy (FiFO).
    # Only differences are commented.
    q = util.Queue()  # uses FIFO queue
    state_to_add = problem.getStartState()
    q.push(state_to_add)
    closed_list = list()
    count_iterations = 0
    while not q.isEmpty():
        popped = q.pop()
        if count_iterations == 0:
            while popped in closed_list:  # don't expand already-visited nodes
                popped = q.pop()
            state_to_expand = popped
            # print "Coordinate to expand:", state_to_expand[0], "Number of corners:", len(state_to_expand[1])
            direction_of_parent = list()
        else:
            while popped[0] in closed_list:  # don't expand already-visited nodes
                popped = q.pop()
            state_to_expand = popped[0]
            # print "Coordinate to expand:", state_to_expand[0], "Number of corners:", len(state_to_expand[1])
            direction_of_parent = popped[1:]
        if not problem.isGoalState(state_to_expand):
            closed_list.append(state_to_expand)
            # print "Closed list:", closed_list
            start_successors = problem.getSuccessors(state_to_expand)
            for (start_successor) in start_successors:
                if start_successor[0] not in closed_list:
                    tuple_list = list()
                    tuple_list.append(start_successor[0])
                    direction_list = list()
                    if len(direction_of_parent) == 0:
                        direction_list.append(start_successor[1])
                        # print "Successor", tuple_list[0][0]
                    else:
                        new_direction = list()
                        new_direction.append(start_successor[1])
                        direction_list = direction_of_parent + new_direction
                        # print "Successor", tuple_list[0][0]
                    push_list = tuple_list + direction_list
                    q.push(push_list)
        else:
            print direction_of_parent
            return direction_of_parent

        count_iterations += 1


def uniformCostSearch(problem):
    """Search the node of least total cost first."""
    # This code is similar to BFS. It uses another queueing strategy.
    # Only differences are commented.
    p = util.PriorityQueue()  # priority queue prioritizes lowest cost to node from root, or g(n)
    node_to_add = problem.getStartState()
    p.push(node_to_add, 0)
    closed_list = list()
    count_iterations = 0
    priorities = dict()  # keep track of nodes and their g(n) values in a dictionary
    while not p.isEmpty():
        popped = p.pop()
        if count_iterations == 0:
            while popped in closed_list:
                popped = p.pop()
            node_to_expand = popped
            direction_of_parent = list()
            g_n_parent = 0  # source node has g(n) value of 0 (distance from root is 0)
        else:
            while popped[0] in closed_list:
                popped = p.pop()
            node_to_expand = popped[0]
            direction_of_parent = popped[1:len(popped)-1]  # parent's direction is implemented as a list of strings
            g_n_parent = float(popped[-1])  # last item in popped object is g(n) of the parent node
        if not problem.isGoalState(node_to_expand):
            closed_list.append(node_to_expand)
            start_successors = problem.getSuccessors(node_to_expand)
            for (start_successor) in start_successors:
                if start_successor[0] not in closed_list:
                    tuple_list = list()
                    tuple_list.append(start_successor[0])
                    direction_list = list()
                    if len(direction_of_parent) == 0:
                        direction_list.append(start_successor[1])
                    else:
                        new_direction = list()
                        new_direction.append(start_successor[1])
                        direction_list = direction_of_parent + new_direction
                    push_list = tuple_list + direction_list
                    coordinate = start_successor[0]  # location of node
                    if coordinate in priorities:  # if node is already in priorities dictionary
                        if (g_n_parent + float(start_successor[2])) >= priorities[coordinate]:  # if new g(n) >= old
                            g_n_successor = priorities[coordinate]  # g(n) value of node should remain as old value
                        else:  # g(n) value for node must be updated
                            g_n_successor = g_n_parent = float(start_successor[2])  # g(n) of parent + weight of edge
                            priorities[coordinate] = g_n_successor
                        push_list.append(g_n_successor)
                        p.update(push_list, g_n_successor)  # update priority queue with new value
                    else:  # node is not yet in priorities dictionary
                        g_n_successor = g_n_parent + float(start_successor[2])
                        push_list.append(g_n_successor)
                        p.push(push_list, g_n_successor)  # add all information for node into priority queue
        else:
            return direction_of_parent
        count_iterations += 1


def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""
    # This method is almost exactly the same as UCS, but prioritizes queue by f(n) = g(n) + h(n) (rather than g(n)).
    # Only differences are commented.
    p = util.PriorityQueue()
    node_to_add = problem.getStartState()
    p.push(node_to_add, 0)
    closed_list = list()
    count_iterations = 0
    priorities = dict()
    while not p.isEmpty():
        popped = p.pop()
        if count_iterations == 0:
            while popped in closed_list:
                popped = p.pop()
            node_to_expand = popped
            direction_of_parent = list()
            g_n_parent = 0
        else:
            while popped[0] in closed_list:
                popped = p.pop()
            node_to_expand = popped[0]
            direction_of_parent = popped[1:len(popped) - 1]
            g_n_parent = float(popped[-1])
        if not problem.isGoalState(node_to_expand):
            closed_list.append(node_to_expand)
            start_successors = problem.getSuccessors(node_to_expand)
            for (start_successor) in start_successors:
                if start_successor[0] not in closed_list:
                    tuple_list = list()
                    tuple_list.append(start_successor[0])
                    direction_list = list()
                    if len(direction_of_parent) == 0:
                        direction_list.append(start_successor[1])
                    else:
                        new_direction = list()
                        new_direction.append(start_successor[1])
                        direction_list = direction_of_parent + new_direction
                    push_list = tuple_list + direction_list
                    coordinate = start_successor[0]
                    h_n = float(heuristic(coordinate, problem))  # use heuristic passed in as argument to measure h(n)
                    if coordinate[0] in priorities:
                        if (g_n_parent + float(start_successor[2])) >= priorities[coordinate]:
                            g_n_successor = priorities[coordinate]
                        else:
                            g_n_successor = g_n_parent = float(start_successor[2])
                            priorities[coordinate] = g_n_successor + h_n  # prioritize by f(n) = g(n) + h(n)
                        push_list.append(g_n_successor)
                        p.update(push_list, g_n_successor + h_n)
                    else:
                        g_n_successor = g_n_parent + float(start_successor[2])
                        push_list.append(g_n_successor)
                        p.push(push_list, g_n_successor + h_n)
        else:
            return direction_of_parent
        count_iterations += 1
    util.raiseNotDefined()


# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
