# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

def depthFirstSearch(problem):
    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches the
    goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:

    print "Start:", problem.getStartState()
    print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    print "Start's successors:", problem.getSuccessors(problem.getStartState())
    """
    "*** YOUR CODE HERE ***"
    "***  util.raiseNotDefined() ***"
    start = problem.getStartState()
    stack = util.Stack()
    visited = dict()
    # a node in the stack contains parent (for back tracking), current state, action 
    startNode = {"parent" : None, "action" : None, "state" : start}
    stack.push(startNode)
    # run the loop until the stack is empty
    while stack.isEmpty() is not True:
        currNode = stack.pop()
        currState = currNode["state"]
        if problem.isGoalState(currState):
            goalNode = currNode
            # if goal node is found, break the loop. No need to search further
            break
        if hash(currState) not in visited:
            # only expand those nodes which are not yet expanded / visited
            visited[hash(currState)] = True
            for successor, action, stepCost in problem.getSuccessors(currState):
                successorNode = {"parent" : currNode, "action" : action, "state" : successor}
                stack.push(successorNode)
    actions = []
    # back track to start node,whose parent is None, to get the list of actions
    while "parent" in goalNode and goalNode["parent"] is not None:
        actions.insert(0, goalNode["action"])
        goalNode = goalNode["parent"]
    return actions
            

def breadthFirstSearch(problem):
    """Search the shallowest nodes in the search tree first."""
    "*** YOUR CODE HERE ***"
    "*** util.raiseNotDefined() ***"
    start = problem.getStartState()
    # for BFS, queue is being used for its FIFO property
    queue = util.Queue()
    visited = dict()
    startNode = {"parent" : None, "action" : None, "state" : start}
    queue.push(startNode)
    while queue.isEmpty() is not True:
        currNode = queue.pop()
        currState = currNode["state"]
        if problem.isGoalState(currState):
            goalNode = currNode
            # when goal state is found, break the loop. No need to search further.
            break
        #if hash(currState) in visited : print "visited state", currState.state
        if hash(currState) not in visited:
            # only expand those nodes which are not yet expanded / visited
            visited[hash(currState)] = True
            for successor, action, stepCost in problem.getSuccessors(currState):
                successorNode = {"parent" : currNode, "action" : action, "state" : successor}
                queue.push(successorNode)
    actions = []
    # back track to start node,whose parent is None, to get the list of actions
    while "parent" in goalNode and goalNode["parent"] is not None:
        actions.insert(0, goalNode["action"])
        goalNode = goalNode["parent"]
    return actions

def uniformCostSearch(problem):
    """Search the node of least total cost first."""
    "*** YOUR CODE HERE ***"
    "*** util.raiseNotDefined() ***"
    start = problem.getStartState()
    priorityQueue = util.PriorityQueue()
    visited = dict()
    startNode = {"parent" : None, "action" : None, "state" : start, "cost" : 0}
    priorityQueue.push(startNode, 0)
    while priorityQueue.isEmpty() is not True:
        # since the priority is the cost, least cost node will be popped first
        currNode = priorityQueue.pop()
        currState = currNode["state"]
        if problem.isGoalState(currState):
            goalNode = currNode
            break
        if hash(currState) not in visited:
            visited[hash(currState)] = True
            for successor, action, stepCost in problem.getSuccessors(currState):
                # total cost to reach the child node is equal to the cost of the current node plus the cost to reach the child node from the current node
                cost = stepCost + currNode["cost"]
                successorNode = {"parent" : currNode, "action" : action, "state" : successor, "cost" : cost}
                # add the cost to reach the current node
                priorityQueue.push(successorNode, cost)
    actions = []
    # back track to start node,whose parent is None, to get the list of actions
    while "parent" in goalNode and goalNode["parent"] is not None:
        actions.insert(0, goalNode["action"])
        goalNode = goalNode["parent"]
    return actions

def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""
    "*** YOUR CODE HERE ***"
    "*** util.raiseNotDefined() ***"
    start = problem.getStartState()
    priorityQueue = util.PriorityQueue()
    visited = dict()
    startNode = {"parent" : None, "action" : None, "state" : start, "cost" : 0}
    priorityQueue.push(startNode, heuristic(start, problem))
    while priorityQueue.isEmpty() is not True:
        # since the priority is the cost, least cost node will be popped first
        currNode = priorityQueue.pop()
        currState = currNode["state"]
        if problem.isGoalState(currState):
            goalNode = currNode
            break
        if hash(currState) not in visited:
            visited[hash(currState)] = True
            successors = problem.getSuccessors(currState)
            for successor, action, stepCost in successors:
                cost = stepCost + currNode["cost"]
                successorNode = {"parent" : currNode, "action" : action, "state" : successor, "cost" : cost}
                # priority is the cost to reach the node plus cost to go from the node to goal node
                priorityQueue.push(successorNode, cost + heuristic(successor, problem))
    actions = []
    # back track to start node,whose parent is None, to get the list of actions
    while "parent" in goalNode and goalNode["parent"] is not None:
        actions.insert(0, goalNode["action"])
        goalNode = goalNode["parent"]
    return actions


# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
