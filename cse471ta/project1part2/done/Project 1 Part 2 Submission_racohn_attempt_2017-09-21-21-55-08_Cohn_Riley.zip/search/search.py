# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).

"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

# Search function will be called for DFS, BFS, and A*/UCS since the algorithms are the same,
# just the data structure will be different
# DFS structure will be of type util.Stack()
# BFS structure will be of type util.Queue()
# A*/UCS structure will be of type util.PriorityQueueWithFunction()


def searchFunction(problem, structure):

    # create a list of the explored nodes, so we do not end up cycling
    explored_nodes = []

    # push the start state onto the stack
    structure.push([(problem.getStartState(), None, 0)])

    # now loop through and perform the search while the structure has not been emptied

    while not structure.isEmpty():

        current_path = structure.pop()

        current_node = current_path[len(current_path)-1]
        current_node = current_node[0]

        if problem.isGoalState(current_node):

            # found the goal state, now return the list of instructions for pacman
            # start at current_path[1] to avoid printing the extra 'Stop'
            return [node[1] for node in current_path[1:]]

        # do not expand again if this node has already been found before
        if current_node not in explored_nodes:

            # add the node to the explored_nodes list
            explored_nodes.append(current_node)

            # loop through the nodes successors and add them to the structure
            for successor_node in problem.getSuccessors(current_node):

                # first time this node has been found
                if successor_node[0] not in explored_nodes:
                    new_path = current_path[:]
                    new_path.append(successor_node)

                    # push the new path into the structure for processing
                    structure.push(new_path)


def depthFirstSearch(problem):
    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches the
    goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:
    """

    # print out the start of the problem for debugging purposes
    """
    print "Start:", problem.getStartState()
    print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    print "Start's successors:", problem.getSuccessors(problem.getStartState())
    """
    # searchFunction will be called with an empty stack and the given problem
    structure = util.Stack()
    return searchFunction(problem, structure)



def breadthFirstSearch(problem):
    """Search the shallowest nodes in the search tree first."""

    # breath first search algorithm will follow the same idea as DFS, but will be using a Queue instead of a Stack
    structure = util.Queue()
    return searchFunction(problem, structure)


def uniformCostSearch(problem):
    """Search the node of least total cost first."""

    # for uniformCostSearch, we will be calculating a cost and will use a PriorityQueue()
    # this will allow us to have a priority based on the nodes' costs

    # getCosts is called for each insertion into the priority queue
    # it gets the cost value for the list of actions for the current path in the queue and adds a priority based on this
    # cost

    def getCosts(search_path):
        actions = []
        for node in search_path:
            if node[1] is not None:
                actions.append(node[1])

        return problem.getCostOfActions(actions)

    structure = util.PriorityQueueWithFunction(getCosts)
    return searchFunction(problem, structure)


def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""

    # A* search is just a UCS with an added heuristic value

    def getCosts(search_path):
        actions = []
        for node in search_path:
            if node[1] is not None:
                actions.append(node[1])

        #  instead of returning the cost alone, this time add the heuristic information from the passed in heuristic
        #  function. The cost + heuristic is the difference from UCS
        return problem.getCostOfActions(actions) + heuristic(search_path[len(search_path)-1][0], problem)

    structure = util.PriorityQueueWithFunction(getCosts)
    return searchFunction(problem, structure)


# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
