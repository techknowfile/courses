1000	SQLSTATE: HY000 (ER_HASHCHK) hashchk
1001	SQLSTATE: HY000 (ER_NISAMCHK) isamchk
1002	SQLSTATE: HY000 (ER_NO) NO
1003	SQLSTATE: HY000 (ER_YES) YES
1004	SQLSTATE: HY000 (ER_CANT_CREATE_FILE) Can't create file '%s' (errno: %d)
1005	SQLSTATE: HY000 (ER_CANT_CREATE_TABLE) Can't create table '%s' (errno: %d)
1006	SQLSTATE: HY000 (ER_CANT_CREATE_DB) Can't create database '%s' (errno: %d)
1007	SQLSTATE: HY000 (ER_DB_CREATE_EXISTS) Can't create database '%s'; database exists
1008	SQLSTATE: HY000 (ER_DB_DROP_EXISTS) Can't drop database '%s'; database doesn't exist
1009	SQLSTATE: HY000 (ER_DB_DROP_DELETE) Error dropping database (can't delete '%s', errno: %d)
1010	SQLSTATE: HY000 (ER_DB_DROP_RMDIR) Error dropping database (can't rmdir '%s', errno: %d)
1011	SQLSTATE: HY000 (ER_CANT_DELETE_FILE) Error on delete of '%s' (errno: %d)
1012	SQLSTATE: HY000 (ER_CANT_FIND_SYSTEM_REC) Can't read record in system table
1013	SQLSTATE: HY000 (ER_CANT_GET_STAT) Can't get status of '%s' (errno: %d)
1014	SQLSTATE: HY000 (ER_CANT_GET_WD) Can't get working directory (errno: %d)
1015	SQLSTATE: HY000 (ER_CANT_LOCK) Can't lock file (errno: %d)
1016	SQLSTATE: HY000 (ER_CANT_OPEN_FILE) Can't open file: '%s' (errno: %d)
1017	SQLSTATE: HY000 (ER_FILE_NOT_FOUND) Can't find file: '%s' (errno: %d)
1018	SQLSTATE: HY000 (ER_CANT_READ_DIR) Can't read dir of '%s' (errno: %d)
1019	SQLSTATE: HY000 (ER_CANT_SET_WD) Can't change dir to '%s' (errno: %d)
1020	SQLSTATE: HY000 (ER_CHECKREAD) Record has changed since last read in table '%s'
1021	SQLSTATE: HY000 (ER_DISK_FULL) Disk full (%s); waiting for someone to free some space...
1022	SQLSTATE: 23000 (ER_DUP_KEY) Can't write; duplicate key in table '%s'
1023	SQLSTATE: HY000 (ER_ERROR_ON_CLOSE) Error on close of '%s' (errno: %d)
1024	SQLSTATE: HY000 (ER_ERROR_ON_READ) Error reading file '%s' (errno: %d)
1025	SQLSTATE: HY000 (ER_ERROR_ON_RENAME) Error on rename of '%s' to '%s' (errno: %d)
1026	SQLSTATE: HY000 (ER_ERROR_ON_WRITE) Error writing file '%s' (errno: %d)
1027	SQLSTATE: HY000 (ER_FILE_USED) '%s' is locked against change
1028	SQLSTATE: HY000 (ER_FILSORT_ABORT) Sort aborted
1029	SQLSTATE: HY000 (ER_FORM_NOT_FOUND) View '%s' doesn't exist for '%s'
1030	SQLSTATE: HY000 (ER_GET_ERRNO) Got error %d from storage engine
1031	SQLSTATE: HY000 (ER_ILLEGAL_HA) Table storage engine for '%s' doesn't have this option
1032	SQLSTATE: HY000 (ER_KEY_NOT_FOUND) Can't find record in '%s'
1033	SQLSTATE: HY000 (ER_NOT_FORM_FILE) Incorrect information in file: '%s'
1034	SQLSTATE: HY000 (ER_NOT_KEYFILE) Incorrect key file for table '%s'; try to repair it
1035	SQLSTATE: HY000 (ER_OLD_KEYFILE) Old key file for table '%s'; repair it!
1036	SQLSTATE: HY000 (ER_OPEN_AS_READONLY) Table '%s' is read only
1037	SQLSTATE: HY001 (ER_OUTOFMEMORY) Out of memory; restart server and try again (needed %d bytes)
1038	SQLSTATE: HY001 (ER_OUT_OF_SORTMEMORY) Out of sort memory; increase server sort buffer size
1039	SQLSTATE: HY000 (ER_UNEXPECTED_EOF) Unexpected EOF found when reading file '%s' (errno: %d)
1040	SQLSTATE: 08004 (ER_CON_COUNT_ERROR) Too many connections
1041	SQLSTATE: HY000 (ER_OUT_OF_RESOURCES) Out of memory; check if mysqld or some other process uses all available memory; if not, you may have to use 'ulimit' to allow mysqld to use more memory or you can add more swap space
1042	SQLSTATE: 08S01 (ER_BAD_HOST_ERROR) Can't get hostname for your address
1043	SQLSTATE: 08S01 (ER_HANDSHAKE_ERROR) Bad handshake
1044	SQLSTATE: 42000 (ER_DBACCESS_DENIED_ERROR) Access denied for user '%s'@'%s' to database '%s'
1045	SQLSTATE: 28000 (ER_ACCESS_DENIED_ERROR) Access denied for user '%s'@'%s' (using password: %s)
1046	SQLSTATE: 3D000 (ER_NO_DB_ERROR) No database selected
1047	SQLSTATE: 08S01 (ER_UNKNOWN_COM_ERROR) Unknown command
1048	SQLSTATE: 23000 (ER_BAD_NULL_ERROR) Column '%s' cannot be null
1049	SQLSTATE: 42000 (ER_BAD_DB_ERROR) Unknown database '%s'
1050	SQLSTATE: 42S01 (ER_TABLE_EXISTS_ERROR) Table '%s' already exists
1051	SQLSTATE: 42S02 (ER_BAD_TABLE_ERROR) Unknown table '%s'
1052	SQLSTATE: 23000 (ER_NON_UNIQ_ERROR) Column '%s' in %s is ambiguous
1053	SQLSTATE: 08S01 (ER_SERVER_SHUTDOWN) Server shutdown in progress
1054	SQLSTATE: 42S22 (ER_BAD_FIELD_ERROR) Unknown column '%s' in '%s'
1055	SQLSTATE: 42000 (ER_WRONG_FIELD_WITH_GROUP) '%s' isn't in GROUP BY
1056	SQLSTATE: 42000 (ER_WRONG_GROUP_FIELD) Can't group on '%s'
1057	SQLSTATE: 42000 (ER_WRONG_SUM_SELECT) Statement has sum functions and columns in same statement
1058	SQLSTATE: 21S01 (ER_WRONG_VALUE_COUNT) Column count doesn't match value count
1059	SQLSTATE: 42000 (ER_TOO_LONG_IDENT) Identifier name '%s' is too long
1060	SQLSTATE: 42S21 (ER_DUP_FIELDNAME) Duplicate column name '%s'
1061	SQLSTATE: 42000 (ER_DUP_KEYNAME) Duplicate key name '%s'
1062	SQLSTATE: 23000 (ER_DUP_ENTRY) Duplicate entry '%s' for key %d
1063	SQLSTATE: 42000 (ER_WRONG_FIELD_SPEC) Incorrect column specifier for column '%s'
1064	SQLSTATE: 42000 (ER_PARSE_ERROR) %s near '%s' at line %d
1065	SQLSTATE: HY000 (ER_EMPTY_QUERY) Query was empty
1066	SQLSTATE: 42000 (ER_NONUNIQ_TABLE) Not unique table/alias: '%s'
1067	SQLSTATE: 42000 (ER_INVALID_DEFAULT) Invalid default value for '%s'
1068	SQLSTATE: 42000 (ER_MULTIPLE_PRI_KEY) Multiple primary key defined
1069	SQLSTATE: 42000 (ER_TOO_MANY_KEYS) Too many keys specified; max %d keys allowed
1070	SQLSTATE: 42000 (ER_TOO_MANY_KEY_PARTS) Too many key parts specified; max %d parts allowed
1071	SQLSTATE: 42000 (ER_TOO_LONG_KEY) Specified key was too long; max key length is %d bytes
1072	SQLSTATE: 42000 (ER_KEY_COLUMN_DOES_NOT_EXITS) Key column '%s' doesn't exist in table
1073	SQLSTATE: 42000 (ER_BLOB_USED_AS_KEY) BLOB column '%s' can't be used in key specification with the used table type
1074	SQLSTATE: 42000 (ER_TOO_BIG_FIELDLENGTH) Column length too big for column '%s' (max = %d); use BLOB instead
1075	SQLSTATE: 42000 (ER_WRONG_AUTO_KEY) Incorrect table definition; there can be only one auto column and it must be defined as a key
1076	SQLSTATE: HY000 (ER_READY) %s: ready for connections. Version: '%s' socket: '%s' port: %d
1077	SQLSTATE: HY000 (ER_NORMAL_SHUTDOWN) %s: Normal shutdown
1078	SQLSTATE: HY000 (ER_GOT_SIGNAL) %s: Got signal %d. Aborting!
1079	SQLSTATE: HY000 (ER_SHUTDOWN_COMPLETE) %s: Shutdown complete
1080	SQLSTATE: 08S01 (ER_FORCING_CLOSE) %s: Forcing close of thread %ld user: '%s'
1081	SQLSTATE: 08S01 (ER_IPSOCK_ERROR) Can't create IP socket
1082	SQLSTATE: 42S12 (ER_NO_SUCH_INDEX) Table '%s' has no index like the one used in CREATE INDEX; recreate the table
1083	SQLSTATE: 42000 (ER_WRONG_FIELD_TERMINATORS) Field separator argument is not what is expected; check the manual
1084	SQLSTATE: 42000 (ER_BLOBS_AND_NO_TERMINATED) You can't use fixed rowlength with BLOBs; please use 'fields terminated by'
1085	SQLSTATE: HY000 (ER_TEXTFILE_NOT_READABLE) The file '%s' must be in the database directory or be readable by all
1086	SQLSTATE: HY000 (ER_FILE_EXISTS_ERROR) File '%s' already exists
1087	SQLSTATE: HY000 (ER_LOAD_INFO) Records: %ld Deleted: %ld Skipped: %ld Warnings: %ld
1088	SQLSTATE: HY000 (ER_ALTER_INFO) Records: %ld Duplicates: %ld
1089	SQLSTATE: HY000 (ER_WRONG_SUB_KEY) Incorrect sub part key; the used key part isn't a string, the used length is longer than the key part, or the storage engine doesn't support unique sub keys
1090	SQLSTATE: 42000 (ER_CANT_REMOVE_ALL_FIELDS) You can't delete all columns with ALTER TABLE; use DROP TABLE instead
1091	SQLSTATE: 42000 (ER_CANT_DROP_FIELD_OR_KEY) Can't DROP '%s'; check that column/key exists
1092	SQLSTATE: HY000 (ER_INSERT_INFO) Records: %ld Duplicates: %ld Warnings: %ld
1093	SQLSTATE: HY000 (ER_UPDATE_TABLE_USED) You can't specify target table '%s' for update in FROM clause
1094	SQLSTATE: HY000 (ER_NO_SUCH_THREAD) Unknown thread id: %lu
1095	SQLSTATE: HY000 (ER_KILL_DENIED_ERROR) You are not owner of thread %lu
1096	SQLSTATE: HY000 (ER_NO_TABLES_USED) No tables used
1097	SQLSTATE: HY000 (ER_TOO_BIG_SET) Too many strings for column %s and SET
1098	SQLSTATE: HY000 (ER_NO_UNIQUE_LOGFILE) Can't generate a unique log-filename %s.(1-999)
1099	SQLSTATE: HY000 (ER_TABLE_NOT_LOCKED_FOR_WRITE) Table '%s' was locked with a READ lock and can't be updated
1100	SQLSTATE: HY000 (ER_TABLE_NOT_LOCKED) Table '%s' was not locked with LOCK TABLES
1101	SQLSTATE: 42000 (ER_BLOB_CANT_HAVE_DEFAULT) BLOB/TEXT column '%s' can't have a default value
1102	SQLSTATE: 42000 (ER_WRONG_DB_NAME) Incorrect database name '%s'
1103	SQLSTATE: 42000 (ER_WRONG_TABLE_NAME) Incorrect table name '%s'
1104	SQLSTATE: 42000 (ER_TOO_BIG_SELECT) The SELECT would examine more than MAX_JOIN_SIZE rows; check your WHERE and use SET SQL_BIG_SELECTS=1 or SET SQL_MAX_JOIN_SIZE=# if the SELECT is okay
1105	SQLSTATE: HY000 (ER_UNKNOWN_ERROR) Unknown error
1106	SQLSTATE: 42000 (ER_UNKNOWN_PROCEDURE) Unknown procedure '%s'
1107	SQLSTATE: 42000 (ER_WRONG_PARAMCOUNT_TO_PROCEDURE) Incorrect parameter count to procedure '%s'
1108	SQLSTATE: HY000 (ER_WRONG_PARAMETERS_TO_PROCEDURE) Incorrect parameters to procedure '%s'
1109	SQLSTATE: 42S02 (ER_UNKNOWN_TABLE) Unknown table '%s' in %s
1110	SQLSTATE: 42000 (ER_FIELD_SPECIFIED_TWICE) Column '%s' specified twice
1111	SQLSTATE: HY000 (ER_INVALID_GROUP_FUNC_USE) Invalid use of group function
1112	SQLSTATE: 42000 (ER_UNSUPPORTED_EXTENSION) Table '%s' uses an extension that doesn't exist in this MySQL version
1113	SQLSTATE: 42000 (ER_TABLE_MUST_HAVE_COLUMNS) A table must have at least 1 column
1114	SQLSTATE: HY000 (ER_RECORD_FILE_FULL) The table '%s' is full
1115	SQLSTATE: 42000 (ER_UNKNOWN_CHARACTER_SET) Unknown character set: '%s'
1116	SQLSTATE: HY000 (ER_TOO_MANY_TABLES) Too many tables; MySQL can only use %d tables in a join
1117	SQLSTATE: HY000 (ER_TOO_MANY_FIELDS) Too many columns
1118	SQLSTATE: 42000 (ER_TOO_BIG_ROWSIZE) Row size too large. The maximum row size for the used table type, not counting BLOBs, is %ld. You have to change some columns to TEXT or BLOBs
1119	SQLSTATE: HY000 (ER_STACK_OVERRUN) Thread stack overrun: Used: %ld of a %ld stack. Use 'mysqld -O thread_stack=#' to specify a bigger stack if needed
1120	SQLSTATE: 42000 (ER_WRONG_OUTER_JOIN) Cross dependency found in OUTER JOIN; examine your ON conditions
1121	SQLSTATE: 42000 (ER_NULL_COLUMN_IN_INDEX) Column '%s' is used with UNIQUE or INDEX but is not defined as NOT NULL
1122	SQLSTATE: HY000 (ER_CANT_FIND_UDF) Can't load function '%s'
1123	SQLSTATE: HY000 (ER_CANT_INITIALIZE_UDF) Can't initialize function '%s'; %s
1124	SQLSTATE: HY000 (ER_UDF_NO_PATHS) No paths allowed for shared library
1125	SQLSTATE: HY000 (ER_UDF_EXISTS) Function '%s' already exists
1126	SQLSTATE: HY000 (ER_CANT_OPEN_LIBRARY) Can't open shared library '%s' (errno: %d %s)
1127	SQLSTATE: HY000 (ER_CANT_FIND_DL_ENTRY) Can't find function '%s' in library'
1128	SQLSTATE: HY000 (ER_FUNCTION_NOT_DEFINED) Function '%s' is not defined
1129	SQLSTATE: HY000 (ER_HOST_IS_BLOCKED) Host '%s' is blocked because of many connection errors; unblock with 'mysqladmin flush-hosts'
1130	SQLSTATE: HY000 (ER_HOST_NOT_PRIVILEGED) Host '%s' is not allowed to connect to this MySQL server
1131	SQLSTATE: 42000 (ER_PASSWORD_ANONYMOUS_USER) You are using MySQL as an anonymous user and anonymous users are not allowed to change passwords
1132	SQLSTATE: 42000 (ER_PASSWORD_NOT_ALLOWED) You must have privileges to update tables in the mysql database to be able to change passwords for others
1133	SQLSTATE: 42000 (ER_PASSWORD_NO_MATCH) Can't find any matching row in the user table
1134	SQLSTATE: HY000 (ER_UPDATE_INFO) Rows matched: %ld Changed: %ld Warnings: %ld
1135	SQLSTATE: HY000 (ER_CANT_CREATE_THREAD) Can't create a new thread (errno %d); if you are not out of available memory, you can consult the manual for a possible OS-dependent bug
1136	SQLSTATE: 21S01 (ER_WRONG_VALUE_COUNT_ON_ROW) Column count doesn't match value count at row %ld
1137	SQLSTATE: HY000 (ER_CANT_REOPEN_TABLE) Can't reopen table: '%s'
1138	SQLSTATE: 42000 (ER_INVALID_USE_OF_NULL) Invalid use of NULL value
1139	SQLSTATE: 42000 (ER_REGEXP_ERROR) Got error '%s' from regexp
1140	SQLSTATE: 42000 (ER_MIX_OF_GROUP_FUNC_AND_FIELDS) Mixing of GROUP columns (MIN(),MAX(),COUNT(),...) with no GROUP columns is illegal if there is no GROUP BY clause
1141	SQLSTATE: 42000 (ER_NONEXISTING_GRANT) There is no such grant defined for user '%s' on host '%s'
1142	SQLSTATE: 42000 (ER_TABLEACCESS_DENIED_ERROR) %s command denied to user '%s'@'%s' for table '%s'
1143	SQLSTATE: 42000 (ER_COLUMNACCESS_DENIED_ERROR) %s command denied to user '%s'@'%s' for column '%s' in table '%s'
1144	SQLSTATE: 42000 (ER_ILLEGAL_GRANT_FOR_TABLE) Illegal GRANT/REVOKE command; please consult the manual to see which privileges can be used
1145	SQLSTATE: 42000 (ER_GRANT_WRONG_HOST_OR_USER) The host or user argument to GRANT is too long
1146	SQLSTATE: 42S02 (ER_NO_SUCH_TABLE) Table '%s.%s' doesn't exist
1147	SQLSTATE: 42000 (ER_NONEXISTING_TABLE_GRANT) There is no such grant defined for user '%s' on host '%s' on table '%s'
1148	SQLSTATE: 42000 (ER_NOT_ALLOWED_COMMAND) The used command is not allowed with this MySQL version
1149	SQLSTATE: 42000 (ER_SYNTAX_ERROR) You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use
1150	SQLSTATE: HY000 (ER_DELAYED_CANT_CHANGE_LOCK) Delayed insert thread couldn't get requested lock for table %s
1151	SQLSTATE: HY000 (ER_TOO_MANY_DELAYED_THREADS) Too many delayed threads in use
1152	SQLSTATE: 08S01 (ER_ABORTING_CONNECTION) Aborted connection %ld to db: '%s' user: '%s' (%s)
1153	SQLSTATE: 08S01 (ER_NET_PACKET_TOO_LARGE) Got a packet bigger than 'max_allowed_packet' bytes
1154	SQLSTATE: 08S01 (ER_NET_READ_ERROR_FROM_PIPE) Got a read error from the connection pipe
1155	SQLSTATE: 08S01 (ER_NET_FCNTL_ERROR) Got an error from fcntl()
1156	SQLSTATE: 08S01 (ER_NET_PACKETS_OUT_OF_ORDER) Got packets out of order
1157	SQLSTATE: 08S01 (ER_NET_UNCOMPRESS_ERROR) Couldn't uncompress communication packet
1158	SQLSTATE: 08S01 (ER_NET_READ_ERROR) Got an error reading communication packets
1159	SQLSTATE: 08S01 (ER_NET_READ_INTERRUPTED) Got timeout reading communication packets
1160	SQLSTATE: 08S01 (ER_NET_ERROR_ON_WRITE) Got an error writing communication packets
1161	SQLSTATE: 08S01 (ER_NET_WRITE_INTERRUPTED) Got timeout writing communication packets
1162	SQLSTATE: 42000 (ER_TOO_LONG_STRING) Result string is longer than 'max_allowed_packet' bytes
1163	SQLSTATE: 42000 (ER_TABLE_CANT_HANDLE_BLOB) The used table type doesn't support BLOB/TEXT columns
1164	SQLSTATE: 42000 (ER_TABLE_CANT_HANDLE_AUTO_INCREMENT) The used table type doesn't support AUTO_INCREMENT columns
1165	SQLSTATE: HY000 (ER_DELAYED_INSERT_TABLE_LOCKED) INSERT DELAYED can't be used with table '%s' because it is locked with LOCK TABLES
1166	SQLSTATE: 42000 (ER_WRONG_COLUMN_NAME) Incorrect column name '%s'
1167	SQLSTATE: 42000 (ER_WRONG_KEY_COLUMN) The used storage engine can't index column '%s'
1168	SQLSTATE: HY000 (ER_WRONG_MRG_TABLE) All tables in the MERGE table are not identically defined
1169	SQLSTATE: 23000 (ER_DUP_UNIQUE) Can't write, because of unique constraint, to table '%s'
1170	SQLSTATE: 42000 (ER_BLOB_KEY_WITHOUT_LENGTH) BLOB/TEXT column '%s' used in key specification without a key length
1171	SQLSTATE: 42000 (ER_PRIMARY_CANT_HAVE_NULL) All parts of a PRIMARY KEY must be NOT NULL; if you need NULL in a key, use UNIQUE instead
1172	SQLSTATE: 42000 (ER_TOO_MANY_ROWS) Result consisted of more than one row
1173	SQLSTATE: 42000 (ER_REQUIRES_PRIMARY_KEY) This table type requires a primary key
1174	SQLSTATE: HY000 (ER_NO_RAID_COMPILED) This version of MySQL is not compiled with RAID support
1175	SQLSTATE: HY000 (ER_UPDATE_WITHOUT_KEY_IN_SAFE_MODE) You are using safe update mode and you tried to update a table without a WHERE that uses a KEY column
1176	SQLSTATE: HY000 (ER_KEY_DOES_NOT_EXITS) Key '%s' doesn't exist in table '%s'
1177	SQLSTATE: 42000 (ER_CHECK_NO_SUCH_TABLE) Can't open table
1178	SQLSTATE: 42000 (ER_CHECK_NOT_IMPLEMENTED) The storage engine for the table doesn't support %s
1179	SQLSTATE: 25000 (ER_CANT_DO_THIS_DURING_AN_TRANSACTION) You are not allowed to execute this command in a transaction
1180	SQLSTATE: HY000 (ER_ERROR_DURING_COMMIT) Got error %d during COMMIT
1181	SQLSTATE: HY000 (ER_ERROR_DURING_ROLLBACK) Got error %d during ROLLBACK
1182	SQLSTATE: HY000 (ER_ERROR_DURING_FLUSH_LOGS) Got error %d during FLUSH_LOGS
1183	SQLSTATE: HY000 (ER_ERROR_DURING_CHECKPOINT) Got error %d during CHECKPOINT
1184	SQLSTATE: 08S01 (ER_NEW_ABORTING_CONNECTION) Aborted connection %ld to db: '%s' user: '%s' host: `%s' (%s)
1185	SQLSTATE: HY000 (ER_DUMP_NOT_IMPLEMENTED) The storage engine for the table does not support binary table dump
1186	SQLSTATE: HY000 (ER_FLUSH_MASTER_BINLOG_CLOSED) Binlog closed, cannot RESET MASTER
1187	SQLSTATE: HY000 (ER_INDEX_REBUILD) Failed rebuilding the index of dumped table '%s'
1188	SQLSTATE: HY000 (ER_MASTER) Error from master: '%s'
1189	SQLSTATE: 08S01 (ER_MASTER_NET_READ) Net error reading from master
1190	SQLSTATE: 08S01 (ER_MASTER_NET_WRITE) Net error writing to master
1191	SQLSTATE: HY000 (ER_FT_MATCHING_KEY_NOT_FOUND) Can't find FULLTEXT index matching the column list
1192	SQLSTATE: HY000 (ER_LOCK_OR_ACTIVE_TRANSACTION) Can't execute the given command because you have active locked tables or an active transaction
1193	SQLSTATE: HY000 (ER_UNKNOWN_SYSTEM_VARIABLE) Unknown system variable '%s'
1194	SQLSTATE: HY000 (ER_CRASHED_ON_USAGE) Table '%s' is marked as crashed and should be repaired
1195	SQLSTATE: HY000 (ER_CRASHED_ON_REPAIR) Table '%s' is marked as crashed and last (automatic?) repair failed
1196	SQLSTATE: HY000 (ER_WARNING_NOT_COMPLETE_ROLLBACK) Some non-transactional changed tables couldn't be rolled back
1197	SQLSTATE: HY000 (ER_TRANS_CACHE_FULL) Multi-statement transaction required more than 'max_binlog_cache_size' bytes of storage; increase this mysqld variable and try again
1198	SQLSTATE: HY000 (ER_SLAVE_MUST_STOP) This operation cannot be performed with a running slave; run STOP SLAVE first
1199	SQLSTATE: HY000 (ER_SLAVE_NOT_RUNNING) This operation requires a running slave; configure slave and do START SLAVE
1200	SQLSTATE: HY000 (ER_BAD_SLAVE) The server is not configured as slave; fix in config file or with CHANGE MASTER TO
1201	SQLSTATE: HY000 (ER_MASTER_INFO) Could not initialize master info structure; more error messages can be found in the MySQL error log
1202	SQLSTATE: HY000 (ER_SLAVE_THREAD) Could not create slave thread; check system resources
1203	SQLSTATE: 42000 (ER_TOO_MANY_USER_CONNECTIONS) User %s has already more than 'max_user_connections' active connections
1204	SQLSTATE: HY000 (ER_SET_CONSTANTS_ONLY) You may only use constant expressions with SET
1205	SQLSTATE: HY000 (ER_LOCK_WAIT_TIMEOUT) Lock wait timeout exceeded; try restarting transaction
1206	SQLSTATE: HY000 (ER_LOCK_TABLE_FULL) The total number of locks exceeds the lock table size
1207	SQLSTATE: 25000 (ER_READ_ONLY_TRANSACTION) Update locks cannot be acquired during a READ UNCOMMITTED transaction
1208	SQLSTATE: HY000 (ER_DROP_DB_WITH_READ_LOCK) DROP DATABASE not allowed while thread is holding global read lock
1209	SQLSTATE: HY000 (ER_CREATE_DB_WITH_READ_LOCK) CREATE DATABASE not allowed while thread is holding global read lock
1210	SQLSTATE: HY000 (ER_WRONG_ARGUMENTS) Incorrect arguments to %s
1211	SQLSTATE: 42000 (ER_NO_PERMISSION_TO_CREATE_USER) '%s'@'%s' is not allowed to create new users
1212	SQLSTATE: HY000 (ER_UNION_TABLES_IN_DIFFERENT_DIR) Incorrect table definition; all MERGE tables must be in the same database
1213	SQLSTATE: 40001 (ER_LOCK_DEADLOCK) Deadlock found when trying to get lock; try restarting transaction
1214	SQLSTATE: HY000 (ER_TABLE_CANT_HANDLE_FT) The used table type doesn't support FULLTEXT indexes
1215	SQLSTATE: HY000 (ER_CANNOT_ADD_FOREIGN) Cannot add foreign key constraint
1216	SQLSTATE: 23000 (ER_NO_REFERENCED_ROW) Cannot add or update a child row: a foreign key constraint fails
1217	SQLSTATE: 23000 (ER_ROW_IS_REFERENCED) Cannot delete or update a parent row: a foreign key constraint fails
1218	SQLSTATE: 08S01 (ER_CONNECT_TO_MASTER) Error connecting to master: %s
1219	SQLSTATE: HY000 (ER_QUERY_ON_MASTER) Error running query on master: %s
1220	SQLSTATE: HY000 (ER_ERROR_WHEN_EXECUTING_COMMAND) Error when executing command %s: %s
1221	SQLSTATE: HY000 (ER_WRONG_USAGE) Incorrect usage of %s and %s
1222	SQLSTATE: 21000 (ER_WRONG_NUMBER_OF_COLUMNS_IN_SELECT) The used SELECT statements have a different number of columns
1223	SQLSTATE: HY000 (ER_CANT_UPDATE_WITH_READLOCK) Can't execute the query because you have a conflicting read lock
1224	SQLSTATE: HY000 (ER_MIXING_NOT_ALLOWED) Mixing of transactional and non-transactional tables is disabled
1225	SQLSTATE: HY000 (ER_DUP_ARGUMENT) Option '%s' used twice in statement
1226	SQLSTATE: 42000 (ER_USER_LIMIT_REACHED) User '%s' has exceeded the '%s' resource (current value: %ld)
1227	SQLSTATE: HY000 (ER_SPECIFIC_ACCESS_DENIED_ERROR) Access denied; you need the %s privilege for this operation
1228	SQLSTATE: HY000 (ER_LOCAL_VARIABLE) Variable '%s' is a SESSION variable and can't be used with SET GLOBAL
1229	SQLSTATE: HY000 (ER_GLOBAL_VARIABLE) Variable '%s' is a GLOBAL variable and should be set with SET GLOBAL
1230	SQLSTATE: 42000 (ER_NO_DEFAULT) Variable '%s' doesn't have a default value
1231	SQLSTATE: 42000 (ER_WRONG_VALUE_FOR_VAR) Variable '%s' can't be set to the value of '%s'
1232	SQLSTATE: 42000 (ER_WRONG_TYPE_FOR_VAR) Incorrect argument type to variable '%s'
1233	SQLSTATE: HY000 (ER_VAR_CANT_BE_READ) Variable '%s' can only be set, not read
1234	SQLSTATE: 42000 (ER_CANT_USE_OPTION_HERE) Incorrect usage/placement of '%s'
1235	SQLSTATE: 42000 (ER_NOT_SUPPORTED_YET) This version of MySQL doesn't yet support '%s'
1236	SQLSTATE: HY000 (ER_MASTER_FATAL_ERROR_READING_BINLOG) Got fatal error %d: '%s' from master when reading data from binary log
1237	SQLSTATE: HY000 (ER_SLAVE_IGNORED_TABLE) Slave SQL thread ignored the query because of replicate-*-table rules
1238	SQLSTATE: HY000 (ER_INCORRECT_GLOBAL_LOCAL_VAR) Variable '%s' is a %s variable
1239	SQLSTATE: 42000 (ER_WRONG_FK_DEF) Incorrect foreign key definition for '%s': %s
1240	SQLSTATE: HY000 (ER_KEY_REF_DO_NOT_MATCH_TABLE_REF) Key reference and table reference don't match
1241	SQLSTATE: 21000 (ER_OPERAND_COLUMNS) Operand should contain %d column(s)
1242	SQLSTATE: 21000 (ER_SUBQUERY_NO_1_ROW) Subquery returns more than 1 row
1243	SQLSTATE: HY000 (ER_UNKNOWN_STMT_HANDLER) Unknown prepared statement handler (%.*s) given to %s
1244	SQLSTATE: HY000 (ER_CORRUPT_HELP_DB) Help database is corrupt or does not exist
1245	SQLSTATE: HY000 (ER_CYCLIC_REFERENCE) Cyclic reference on subqueries
1246	SQLSTATE: HY000 (ER_AUTO_CONVERT) Converting column '%s' from %s to %s
1247	SQLSTATE: 42S22 (ER_ILLEGAL_REFERENCE) Reference '%s' not supported (%s)
1248	SQLSTATE: 42000 (ER_DERIVED_MUST_HAVE_ALIAS) Every derived table must have its own alias
1249	SQLSTATE: 01000 (ER_SELECT_REDUCED) Select %u was reduced during optimization
1250	SQLSTATE: 42000 (ER_TABLENAME_NOT_ALLOWED_HERE) Table '%s' from one of the SELECTs cannot be used in %s
1251	SQLSTATE: 08004 (ER_NOT_SUPPORTED_AUTH_MODE) Client does not support authentication protocol requested by server; consider upgrading MySQL client
1252	SQLSTATE: 42000 (ER_SPATIAL_CANT_HAVE_NULL) All parts of a SPATIAL index must be NOT NULL
1253	SQLSTATE: 42000 (ER_COLLATION_CHARSET_MISMATCH) COLLATION '%s' is not valid for CHARACTER SET '%s'
1254	SQLSTATE: HY000 (ER_SLAVE_WAS_RUNNING) Slave is already running
1255	SQLSTATE: HY000 (ER_SLAVE_WAS_NOT_RUNNING) Slave has already been stopped
1256	SQLSTATE: HY000 (ER_TOO_BIG_FOR_UNCOMPRESS) Uncompressed data size too large; the maximum size is %d (probably, length of uncompressed data was corrupted)
1257	SQLSTATE: HY000 (ER_ZLIB_Z_MEM_ERROR) ZLIB: Not enough memory
1258	SQLSTATE: HY000 (ER_ZLIB_Z_BUF_ERROR) ZLIB: Not enough room in the output buffer (probably, length of uncompressed data was corrupted)
1259	SQLSTATE: HY000 (ER_ZLIB_Z_DATA_ERROR) ZLIB: Input data corrupted
1260	SQLSTATE: HY000 (ER_CUT_VALUE_GROUP_CONCAT) %d line(s) were cut by GROUP_CONCAT()
1261	SQLSTATE: 01000 (ER_WARN_TOO_FEW_RECORDS) Row %ld doesn't contain data for all columns
1262	SQLSTATE: 01000 (ER_WARN_TOO_MANY_RECORDS) Row %ld was truncated; it contained more data than there were input columns
1263	SQLSTATE: 01000 (ER_WARN_NULL_TO_NOTNULL) Data truncated; NULL supplied to NOT NULL column '%s' at row %ld
1264	SQLSTATE: 01000 (ER_WARN_DATA_OUT_OF_RANGE) Data truncated; out of range for column '%s' at row %ld
1265	SQLSTATE: 01000 (ER_WARN_DATA_TRUNCATED) Data truncated for column '%s' at row %ld
1266	SQLSTATE: HY000 (ER_WARN_USING_OTHER_HANDLER) Using storage engine %s for table '%s'
1267	SQLSTATE: HY000 (ER_CANT_AGGREGATE_2COLLATIONS) Illegal mix of collations (%s,%s) and (%s,%s) for operation '%s'
1268	SQLSTATE: HY000 (ER_DROP_USER) Can't drop one or more of the requested users
1269	SQLSTATE: HY000 (ER_REVOKE_GRANTS) Can't revoke all privileges, grant for one or more of the requested users
1270	SQLSTATE: HY000 (ER_CANT_AGGREGATE_3COLLATIONS) Illegal mix of collations (%s,%s), (%s,%s), (%s,%s) for operation '%s'
1271	SQLSTATE: HY000 (ER_CANT_AGGREGATE_NCOLLATIONS) Illegal mix of collations for operation '%s'
1272	SQLSTATE: HY000 (ER_VARIABLE_IS_NOT_STRUCT) Variable '%s' is not a variable component (can't be used as XXXX.variable_name)
1273	SQLSTATE: HY000 (ER_UNKNOWN_COLLATION) Unknown collation: '%s'
1274	SQLSTATE: HY000 (ER_SLAVE_IGNORED_SSL_PARAMS) SSL parameters in CHANGE MASTER are ignored because this MySQL slave was compiled without SSL support; they can be used later if MySQL slave with SSL is started
1275	SQLSTATE: HY000 (ER_SERVER_IS_IN_SECURE_AUTH_MODE) Server is running in --secure-auth mode, but '%s'@'%s' has a password in the old format; please change the password to the new format
1276	SQLSTATE: HY000 (ER_WARN_FIELD_RESOLVED) Field or reference '%s%s%s%s%s' of SELECT #%d was resolved in SELECT #%d
1277	SQLSTATE: HY000 (ER_BAD_SLAVE_UNTIL_COND) Incorrect parameter or combination of parameters for START SLAVE UNTIL
1278	SQLSTATE: HY000 (ER_MISSING_SKIP_SLAVE) It is recommended to use --skip-slave-start when doing step-by-step replication with START SLAVE UNTIL; otherwise, you will get problems if you get an unexpected slave's mysqld restart
1279	SQLSTATE: HY000 (ER_UNTIL_COND_IGNORED) SQL thread is not to be started so UNTIL options are ignored
1280	SQLSTATE: 42000 (ER_WRONG_NAME_FOR_INDEX) Incorrect index name '%s'
1281	SQLSTATE: 42000 (ER_WRONG_NAME_FOR_CATALOG) Incorrect catalog name '%s'
1282	SQLSTATE: HY000 (ER_WARN_QC_RESIZE) Query cache failed to set size %lu; new query cache size is %lu
1283	SQLSTATE: HY000 (ER_BAD_FT_COLUMN) Column '%s' cannot be part of FULLTEXT index
1284	SQLSTATE: HY000 (ER_UNKNOWN_KEY_CACHE) Unknown key cache '%s'
1285	SQLSTATE: HY000 (ER_WARN_HOSTNAME_WONT_WORK) MySQL is started in --skip-name-resolve mode; you must restart it without this switch for this grant to work
1286	SQLSTATE: 42000 (ER_UNKNOWN_STORAGE_ENGINE) Unknown table engine '%s'
1287	SQLSTATE: HY000 (ER_WARN_DEPRECATED_SYNTAX) '%s' is deprecated; use '%s' instead
1288	SQLSTATE: HY000 (ER_NON_UPDATABLE_TABLE) The target table %s of the %s is not updatable
1289	SQLSTATE: HY000 (ER_FEATURE_DISABLED) The '%s' feature is disabled; you need MySQL built with '%s' to have it working
1290	SQLSTATE: HY000 (ER_OPTION_PREVENTS_STATEMENT) The MySQL server is running with the %s option so it cannot execute this statement
1291	SQLSTATE: HY000 (ER_DUPLICATED_VALUE_IN_TYPE) Column '%s' has duplicated value '%s' in %s
1292	SQLSTATE: HY000 (ER_TRUNCATED_WRONG_VALUE) Truncated incorrect %s value: '%s'
1293	SQLSTATE: HY000 (ER_TOO_MUCH_AUTO_TIMESTAMP_COLS) Incorrect table definition; there can be only one TIMESTAMP column with CURRENT_TIMESTAMP in DEFAULT or ON UPDATE clause
1294	SQLSTATE: HY000 (ER_INVALID_ON_UPDATE) Invalid ON UPDATE clause for '%s' column
1295	SQLSTATE: HY000 (ER_UNSUPPORTED_PS) This command is not supported in the prepared statement protocol yet
1296	SQLSTATE: HY000 (ER_GET_ERRMSG) Got error %d '%s' from %s
1297	SQLSTATE: HY000 (ER_GET_TEMPORARY_ERRMSG) Got temporary error %d '%s' from %s
1298	SQLSTATE: HY000 (ER_UNKNOWN_TIME_ZONE) Unknown or incorrect time zone: '%s'
1299	SQLSTATE: HY000 (ER_WARN_INVALID_TIMESTAMP) Invalid TIMESTAMP value in column '%s' at row %ld
1300	SQLSTATE: HY000 (ER_INVALID_CHARACTER_STRING) Invalid %s character string: '%s'
1301	SQLSTATE: HY000 (ER_WARN_ALLOWED_PACKET_OVERFLOWED) Result of %s() was larger than max_allowed_packet (%d) - truncated
1302	SQLSTATE: 2F003 (ER_SP_NO_RECURSIVE_CREATE) Can't create a %s from within another stored routine
1303	SQLSTATE: 42000 (ER_SP_ALREADY_EXISTS) %s %s already exists
1304	SQLSTATE: 42000 (ER_SP_DOES_NOT_EXIST) %s %s does not exist
1305	SQLSTATE: HY000 (ER_SP_DROP_FAILED) Failed to DROP %s %s
1306	SQLSTATE: HY000 (ER_SP_STORE_FAILED) Failed to CREATE %s %s
1307	SQLSTATE: 42000 (ER_SP_LILABEL_MISMATCH) %s with no matching label: %s
1308	SQLSTATE: 42000 (ER_SP_LABEL_REDEFINE) Redefining label %s
1309	SQLSTATE: 42000 (ER_SP_LABEL_MISMATCH) End-label %s without match
1310	SQLSTATE: 01000 (ER_SP_UNINIT_VAR) Referring to uninitialized variable %s
1311	SQLSTATE: 0A000 (ER_SP_BADSELECT) SELECT in a stored procedure must have INTO
1312	SQLSTATE: 42000 (ER_SP_BADRETURN) RETURN is only allowed in a FUNCTION
1313	SQLSTATE: 0A000 (ER_SP_BADSTATEMENT) Statements like SELECT, INSERT, UPDATE (and others) are not allowed in a FUNCTION
1314	SQLSTATE: 42000 (ER_UPDATE_LOG_DEPRECATED_IGNORED) The update log is deprecated and replaced by the binary log; SET SQL_LOG_UPDATE has been ignored
1315	SQLSTATE: 42000 (ER_UPDATE_LOG_DEPRECATED_TRANSLATED) The update log is deprecated and replaced by the binary log; SET SQL_LOG_UPDATE has been translated to SET SQL_LOG_BIN
1316	SQLSTATE: 70100 (ER_QUERY_INTERRUPTED) Query execution was interrupted
1317	SQLSTATE: 42000 (ER_SP_WRONG_NO_OF_ARGS) Incorrect number of arguments for %s %s; expected %u, got %u
1318	SQLSTATE: 42000 (ER_SP_COND_MISMATCH) Undefined CONDITION: %s
1319	SQLSTATE: 42000 (ER_SP_NORETURN) No RETURN found in FUNCTION %s
1320	SQLSTATE: 2F005 (ER_SP_NORETURNEND) FUNCTION %s ended without RETURN
1321	SQLSTATE: 42000 (ER_SP_BAD_CURSOR_QUERY) Cursor statement must be a SELECT
1322	SQLSTATE: 42000 (ER_SP_BAD_CURSOR_SELECT) Cursor SELECT must not have INTO
1323	SQLSTATE: 42000 (ER_SP_CURSOR_MISMATCH) Undefined CURSOR: %s
1324	SQLSTATE: 24000 (ER_SP_CURSOR_ALREADY_OPEN) Cursor is already open
1325	SQLSTATE: 24000 (ER_SP_CURSOR_NOT_OPEN) Cursor is not open
1326	SQLSTATE: 42000 (ER_SP_UNDECLARED_VAR) Undeclared variable: %s
1327	SQLSTATE: HY000 (ER_SP_WRONG_NO_OF_FETCH_ARGS) Incorrect number of FETCH variables
1328	SQLSTATE: 02000 (ER_SP_FETCH_NO_DATA) No data to FETCH
1329	SQLSTATE: 42000 (ER_SP_DUP_PARAM) Duplicate parameter: %s
1330	SQLSTATE: 42000 (ER_SP_DUP_VAR) Duplicate variable: %s
1331	SQLSTATE: 42000 (ER_SP_DUP_COND) Duplicate condition: %s
1332	SQLSTATE: 42000 (ER_SP_DUP_CURS) Duplicate cursor: %s
1333	SQLSTATE: HY000 (ER_SP_CANT_ALTER) Failed to ALTER %s %s
1334	SQLSTATE: 0A000 (ER_SP_SUBSELECT_NYI) Subselect value not supported
1335	SQLSTATE: 42000 (ER_SP_NO_USE) USE is not allowed in a stored procedure
1336	SQLSTATE: 42000 (ER_SP_VARCOND_AFTER_CURSHNDLR) Variable or condition declaration after cursor or handler declaration
1337	SQLSTATE: 42000 (ER_SP_CURSOR_AFTER_HANDLER) Cursor declaration after handler declaration
1338	SQLSTATE: 20000 (ER_SP_CASE_NOT_FOUND) Case not found for CASE statement
1339	SQLSTATE: HY000 (ER_FPARSER_TOO_BIG_FILE) Configuration file '%s' is too big
1340	SQLSTATE: HY000 (ER_FPARSER_BAD_HEADER) Malformed file type header in file '%s'
1341	SQLSTATE: HY000 (ER_FPARSER_EOF_IN_COMMENT) Unexpected end of file while parsing comment '%s'
1342	SQLSTATE: HY000 (ER_FPARSER_ERROR_IN_PARAMETER) Error while parsing parameter '%s' (line: '%s')
1343	SQLSTATE: HY000 (ER_FPARSER_EOF_IN_UNKNOWN_PARAMETER) Unexpected end of file while skipping unknown parameter '%s'
1344	SQLSTATE: HY000 (ER_VIEW_NO_EXPLAIN) EXPLAIN/SHOW can not be issued; lacking privileges for underlying table
1345	SQLSTATE: HY000 (ER_FRM_UNKNOWN_TYPE) File '%s' has unknown type '%s' in its header
1346	SQLSTATE: HY000 (ER_WRONG_OBJECT) '%s.%s' is not %s
1347	SQLSTATE: HY000 (ER_NONUPDATEABLE_COLUMN) Column '%s' is not updatable
1348	SQLSTATE: HY000 (ER_VIEW_SELECT_DERIVED) View's SELECT contains a subquery in the FROM clause
1349	SQLSTATE: HY000 (ER_VIEW_SELECT_PROCEDURE) View's SELECT contains a PROCEDURE clause
1350	SQLSTATE: HY000 (ER_VIEW_SELECT_VARIABLE) View's SELECT contains a variable or parameter
1351	SQLSTATE: HY000 (ER_VIEW_SELECT_TMPTABLE) View's SELECT contains a temporary table '%s'
1352	SQLSTATE: HY000 (ER_VIEW_WRONG_LIST) View's SELECT and view's field list have different column counts
1353	SQLSTATE: HY000 (ER_WARN_VIEW_MERGE) View merge algorithm can't be used here for now (assumed undefined algorithm)
1354	SQLSTATE: HY000 (ER_WARN_VIEW_WITHOUT_KEY) View being updated does not have complete key of underlying table in it
1355	SQLSTATE: HY000 (ER_VIEW_INVALID) View '%s.%s' references invalid table(s) or column(s)
1356	SQLSTATE: HY000 (ER_SP_NO_DROP_SP) Can't drop a %s from within another stored routine
1357	SQLSTATE: HY000 (ER_SP_GOTO_IN_HNDLR) GOTO is not allowed in a stored procedure handler
2000	(CR_UNKNOWN_ERROR) Unknown MySQL error
2001	(CR_SOCKET_CREATE_ERROR) Can't create UNIX socket (%d)
2002	(CR_CONNECTION_ERROR) Can't connect to local MySQL server through socket '%s' (%d)
2003	(CR_CONN_HOST_ERROR) Can't connect to MySQL server on '%s' (%d)
2004	(CR_IPSOCK_ERROR) Can't create TCP/IP socket (%d)
2005	(CR_UNKNOWN_HOST) Unknown MySQL server host '%s' (%d)
2006	(CR_SERVER_GONE_ERROR) MySQL server has gone away
2007	(CR_VERSION_ERROR) Protocol mismatch; server version = %d, client version = %d
2008	(CR_OUT_OF_MEMORY) MySQL client ran out of memory
2009	(CR_WRONG_HOST_INFO) Wrong host info
2010	(CR_LOCALHOST_CONNECTION) Localhost via UNIX socket
2011	(CR_TCP_CONNECTION) %s via TCP/IP
2012	(CR_SERVER_HANDSHAKE_ERR) Error in server handshake
2013	(CR_SERVER_LOST) Lost connection to MySQL server during query
2014	(CR_COMMANDS_OUT_OF_SYNC) Commands out of sync; you can't run this command now
2015	(CR_NAMEDPIPE_CONNECTION) %s via named pipe
2016	(CR_NAMEDPIPEWAIT_ERROR) Can't wait for named pipe to host: %s pipe: %s (%lu)
2017	(CR_NAMEDPIPEOPEN_ERROR) Can't open named pipe to host: %s pipe: %s (%lu)
2018	(CR_NAMEDPIPESETSTATE_ERROR) Can't set state of named pipe to host: %s pipe: %s (%lu)
2019	(CR_CANT_READ_CHARSET) Can't initialize character set %s (path: %s)
2020	(CR_NET_PACKET_TOO_LARGE) Got packet bigger than 'max_allowed_packet' bytes
2021	(CR_EMBEDDED_CONNECTION) Embedded server
2022	(CR_PROBE_SLAVE_STATUS) Error on SHOW SLAVE STATUS:
2023	(CR_PROBE_SLAVE_HOSTS) Error on SHOW SLAVE HOSTS:
2024	(CR_PROBE_SLAVE_CONNECT) Error connecting to slave:
2025	(CR_PROBE_MASTER_CONNECT) Error connecting to master:
2026	(CR_SSL_CONNECTION_ERROR) SSL connection error
2027	(CR_MALFORMED_PACKET) Malformed packet
2028	(CR_WRONG_LICENSE) This client library is licensed only for use with MySQL servers having '%s' license
2029	(CR_NULL_POINTER) Invalid use of null pointer
2030	(CR_NO_PREPARE_STMT) Statement not prepared
2031	(CR_PARAMS_NOT_BOUND) No data supplied for parameters in prepared statement
2032	(CR_DATA_TRUNCATED) Data truncated
2033	(CR_NO_PARAMETERS_EXISTS) No parameters exist in the statement
2034	(CR_INVALID_PARAMETER_NO) Invalid parameter number
2035	(CR_INVALID_BUFFER_USE) Can't send long data for non-string/non-binary data types (parameter: %d)
2036	(CR_UNSUPPORTED_PARAM_TYPE) Using unsupported buffer type: %d (parameter: %d)
2037	(CR_SHARED_MEMORY_CONNECTION) Shared memory (%lu)
2038	(CR_SHARED_MEMORY_CONNECT_REQUEST_ERROR) Can't open shared memory; client could not create request event (%lu)
2039	(CR_SHARED_MEMORY_CONNECT_ANSWER_ERROR) Can't open shared memory; no answer event received from server (%lu)
2040	(CR_SHARED_MEMORY_CONNECT_FILE_MAP_ERROR) Can't open shared memory; server could not allocate file mapping (%lu)
2041	(CR_SHARED_MEMORY_CONNECT_MAP_ERROR) Can't open shared memory; server could not get pointer to file mapping (%lu)
2042	(CR_SHARED_MEMORY_FILE_MAP_ERROR) Can't open shared memory; client could not allocate file mapping (%lu)
2043	(CR_SHARED_MEMORY_MAP_ERROR) Can't open shared memory; client could not get pointer to file mapping (%lu)
2044	(CR_SHARED_MEMORY_EVENT_ERROR) Can't open shared memory; client could not create %s event (%lu)
2045	(CR_SHARED_MEMORY_CONNECT_ABANDONED_ERROR) Can't open shared memory; no answer from server (%lu)
2046	(CR_SHARED_MEMORY_CONNECT_SET_ERROR) Can't open shared memory; cannot send request event to server (%lu)
2047	(CR_CONN_UNKNOW_PROTOCOL) Wrong or unknown protocol
2048	(CR_INVALID_CONN_HANDLE) Invalid connection handle
2049	(CR_SECURE_AUTH) Connection using old (pre-4.1.1) authentication protocol refused (client option 'secure_auth' enabled)
2050	(CR_FETCH_CANCELED) Row retrieval was canceled by mysql_stmt_close() call
2051	(CR_NO_DATA) Attempt to read column without prior row fetch
 	 