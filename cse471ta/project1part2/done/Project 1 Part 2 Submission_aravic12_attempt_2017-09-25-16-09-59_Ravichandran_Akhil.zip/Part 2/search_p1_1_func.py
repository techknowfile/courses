# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
#
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util
import logging,sys

logger = logging.getLogger('search')
# logger.setLevel(logging.DEBUG)
# logger.setLevel(logging.INFO)

ch = logging.StreamHandler()
# formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
formatter = logging.Formatter('%(levelname)s - %(message)s')
ch.setFormatter(formatter)
logger.addHandler(ch)

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return [s, s, w, s, w, w, s, w]

def sortsuccessors(successors):
    sorted_successors = sorted(successors, key=lambda tup: tup[1])
    return sorted_successors


def depthFirstSearch(problem):
    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches the
    goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:

    print "Start:", problem.getStartState()
    print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    print "Start's successors:", problem.getSuccessors(problem.getStartState())
    """
    "*** YOUR CODE HERE ***"
    # util.raiseNotDefined()

    priority_queue = util.PriorityQueue()
    locations_visited = util.Counter()

    start_state = problem.getStartState()

    logger.debug('Start State = %s', start_state)
    
    start_priority = sys.maxint
    state_object = {
        "state": start_state,
        "action_list": [],
        "priority": start_priority
    }

    priority_queue.push(state_object, start_priority)

    while not priority_queue.isEmpty():

        state_object = priority_queue.pop()

        state = state_object["state"]
        action_list = state_object["action_list"]
        priority = state_object["priority"]

        if problem.isGoalState(state):
            return action_list
        elif locations_visited[state] == 0:

            logger.debug("\n")
            logger.debug("~" * 30)

            locations_visited[state] = locations_visited[state] + 1

            logger.debug("!" * 10)
            logger.debug("Current State Object = %s", state_object)
            logger.debug("Prioirty = %s | State = %s", priority, state)
            logger.debug("Action List = %s", action_list)
            logger.debug("!" * 10)

            children = problem.getSuccessors(state)
        #     children = sortsuccessors(children)

            for child_index, child in enumerate(children):

                logger.debug("@" * 20)
                logger.debug("Child Considered = %s", child)

                child_state = child[0]

                if locations_visited[child_state] <= 0:

                    child_action = child[1]
                    child_cost = child[2]

                    child_action_list = list(action_list)
                    child_action_list.append(child_action)

                    child_priority = (priority - 1)

                    child_state_object = {
                        "state": child_state,
                        "action_list": child_action_list,
                        "priority": child_priority
                    }
                    logger.debug("#" * 10)
                    logger.debug("Child Pushed = %s", child_state)
                    logger.debug("Child Pushed | Action = %s | Priority = %s", child_action, child_priority)
                    logger.debug("Child Pushed | Action List = %s ", child_action_list)
                    logger.debug("#" * 10)

                    priority_queue.push(child_state_object, child_priority)
                logger.debug("@" * 20)
            logger.debug("~" * 30)
    return []

def breadthFirstSearch(problem):
    """Search the shallowest nodes in the search tree first."""
    "*** YOUR CODE HERE ***"
    # util.raiseNotDefined()

    priority_queue = util.PriorityQueue()
    locations_visited = util.Counter()

    start_state = problem.getStartState()

    logger.debug('Start State = %s', start_state)

    start_priority = 1
    state_object = {
        "state": start_state,
        "action_list": [],
        "priority": start_priority
    }

    priority_queue.push(state_object, start_priority)

    while not priority_queue.isEmpty():

        state_object = priority_queue.pop()

        state = state_object["state"]
        action_list = state_object["action_list"]
        priority = state_object["priority"]

        if problem.isGoalState(state):
            return action_list
        elif locations_visited[state] == 0:

            logger.debug("\n")
            logger.debug("~" * 30)

            locations_visited[state] = locations_visited[state] + 1

            logger.debug("!" * 10)
            logger.debug("Current State Object = %s", state_object)
            logger.debug("Prioirty = %s | State = %s", priority, state)
            logger.debug("Action List = %s", action_list)
            logger.debug("!" * 10)

            children = problem.getSuccessors(state)
        #     children = sortsuccessors(children)

            for child_index, child in enumerate(children):

                logger.debug("@" * 20)
                logger.debug("Child Considered = %s", child)

                child_state = child[0]

                if locations_visited[child_state] <= 0:

                    child_action = child[1]
                    child_cost = child[2]

                    child_action_list = list(action_list)
                    child_action_list.append(child_action)

                    child_priority = (2 * priority) + child_index

                    child_state_object = {
                        "state": child_state,
                        "action_list": child_action_list,
                        "priority": child_priority
                    }
                    logger.debug("#" * 10)
                    logger.debug("Child Pushed = %s", child_state)
                    logger.debug("Child Pushed | Action = %s | Priority = %s", child_action, child_priority)
                    logger.debug("Child Pushed | Action List = %s ", child_action_list)
                    logger.debug("#" * 10)

                    priority_queue.push(child_state_object, child_priority)
                logger.debug("@" * 20)
            logger.debug("~" * 30)
    return []


def uniformCostSearch(problem):
    """Search the node of least total cost first."""
    "*** YOUR CODE HERE ***"
    # util.raiseNotDefined()

    priority_queue = util.PriorityQueue()
    locations_visited = util.Counter()

    start_state = problem.getStartState()

    logger.debug('Start State = %s', start_state)

    start_priority = 1
    state_object = {
        "state": start_state,
        "action_list": [],
        "priority": start_priority
    }

    priority_queue.push(state_object, start_priority)

    while not priority_queue.isEmpty():

        state_object = priority_queue.pop()

        state = state_object["state"]
        action_list = state_object["action_list"]
        priority = state_object["priority"]

        if problem.isGoalState(state):
            return action_list
        elif locations_visited[state] == 0:

            logger.debug("\n")
            logger.debug("~" * 30)

            locations_visited[state] = locations_visited[state] + 1

            logger.debug("!" * 10)
            logger.debug("Current State Object = %s", state_object)
            logger.debug("Prioirty = %s | State = %s", priority, state)
            logger.debug("Action List = %s", action_list)
            logger.debug("!" * 10)

            children = problem.getSuccessors(state)
        #     children = sortsuccessors(children)

            for child_index, child in enumerate(children):

                logger.debug("@" * 20)
                logger.debug("Child Considered = %s", child)

                child_state = child[0]

                if locations_visited[child_state] <= 0:

                    child_action = child[1]
                    child_cost = child[2]

                    child_action_list = list(action_list)
                    child_action_list.append(child_action)

                    child_priority = priority + child_cost

                    child_state_object = {
                        "state": child_state,
                        "action_list": child_action_list,
                        "priority": child_priority
                    }
                    logger.debug("#" * 10)
                    logger.debug("Child Pushed = %s", child_state)
                    logger.debug("Child Pushed | Action = %s | Priority = %s", child_action, child_priority)
                    logger.debug("Child Pushed | Action List = %s ", child_action_list)
                    logger.debug("#" * 10)

                    priority_queue.push(child_state_object, child_priority)
                logger.debug("@" * 20)
            logger.debug("~" * 30)
    return []

def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0


def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""
    "*** YOUR CODE HERE ***"
    # util.raiseNotDefined()

    priority_queue = util.PriorityQueue()
    locations_visited = util.Counter()

    start_state = problem.getStartState()

    logger.debug('Start State = %s', start_state)

    start_priority = 0
    state_object = {
        "state": start_state,
        "action_list": [],
        "priority": start_priority
    }

    priority_queue.push(state_object, start_priority)

    while not priority_queue.isEmpty():

        state_object = priority_queue.pop()

        state = state_object["state"]
        action_list = state_object["action_list"]
        priority = state_object["priority"]

        if problem.isGoalState(state):
            return action_list
        elif locations_visited[state] == 0:

            logger.debug("\n")
            logger.debug("~" * 30)

            locations_visited[state] = locations_visited[state] + 1

            logger.debug("!" * 10)
            logger.debug("Current State Object = %s", state_object)
            logger.debug("Prioirty = %s | State = %s", priority, state)
            logger.debug("Action List = %s", action_list)
            logger.debug("!" * 10)

            children = problem.getSuccessors(state)
        #     children = sortsuccessors(children)

            for child_index, child in enumerate(children):

                logger.debug("@" * 20)
                logger.debug("Child Considered = %s", child)

                child_state = child[0]

                if locations_visited[child_state] <= 0:

                    child_action = child[1]
                    child_cost = child[2]

                    child_action_list = list(action_list)
                    child_action_list.append(child_action)

                    child_g_cost = priority + child_cost
                    child_h_cost = heuristic(child_state, problem)
                    child_priority = child_g_cost + child_h_cost


                    child_state_object = {
                        "state": child_state,
                        "action_list": child_action_list,
                        "priority": child_g_cost
                    }
                    logger.debug("#" * 10)
                    logger.debug("Child Pushed = %s", child_state)
                    logger.debug("Child Pushed | Action = %s | Priority = %s", child_action, child_priority)
                    logger.debug("Child Pushed | Action List = %s ", child_action_list)
                    logger.debug("#" * 10)

                    priority_queue.push(child_state_object, child_priority)
                logger.debug("@" * 20)
            logger.debug("~" * 30)
    return []
    

# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
