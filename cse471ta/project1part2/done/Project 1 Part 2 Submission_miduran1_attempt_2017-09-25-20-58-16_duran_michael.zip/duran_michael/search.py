# Michael Duran
# CSE 471
# M W 9:40a
# Project 1 Part 2

# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

def depthFirstSearch(problem):
    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches the
    goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:
    
    print "Start:", problem.getStartState()
    print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    print "Start's successors:", problem.getSuccessors(problem.getStartState())
    """

    # initialize start state
    start = problem.getStartState()
    # use a stack for DFS
    stack = util.Stack()
    # use dictionaries to keep track of parents and moves taken
    pathOf = {}
    parentOf = {}
    # use arrays to track visited nodes and return desired moves
    visited = []
    moves = []

    # establish stack container (node, parent, action) 
    stack.push((start, None, None))

    while not stack.isEmpty():
        # unpack stack container
        node, parent, action = stack.pop()
        # check the state is not already visited
        if node not in visited:
            visited.append(node)
            # if node is goal state, create move list
            if problem.isGoalState(node):
                node = parent
                moves.append(action)
                # the moves array will insert paths taken from the previous states parents to beginning of list
                while node != start:
                    moves = [pathOf.get(node)] + moves
                    node = parentOf.get(node)
                
                return moves

            # create dictionary of parents to state and path from parent
            if node != start:
                parentOf[node] = parent
                pathOf[node] = action

            # find the successor states and push them on the stack and track the parent state
            children = problem.getSuccessors(node)
            for state, move, cost in children:
                if state not in visited:
                    stack.push((state, node, move))

    return moves


def breadthFirstSearch(problem):
    """Search the shallowest nodes in the search tree first."""
    
    # I had to rewrite BFS because my initial implementation used dictionaries to track
    # the moves and wasn't hashable with lists. SO here is a new algorithm.

    # initialize start state
    start = problem.getStartState()
    # use a queue for BFS
    q = util.Queue()
    # initialize lists
    visited = []
    moves = []

    # establish queue container (node, list of moves) 
    q.push((start, moves))

    while not q.isEmpty():
        # unpack queue container
        node, movelist = q.pop()
        # check the state is not already visited
        if node not in visited:
            visited.append(node)
            # if node is goal state, return move list
            if problem.isGoalState(node):

                return movelist

            # find the successor states and push them on the queue with an updated list of actions taken.
            children = problem.getSuccessors(node)
            for state, action, cost in children:
                if state not in visited:
                    q.push((state, movelist + [action]))
                    
    return moves


def uniformCostSearch(problem):
    """Search the node of least total cost first."""

    # initialize start state
    start = problem.getStartState()
    # use a priority queue for UCS
    pq = util.PriorityQueue()
    # use dictionaries to keep track of parents and moves taken
    pathOf = {}
    parentOf = {}
    costOf = {}
    # use arrays to track visited nodes and return desired moves
    visited = []
    moves = []

    # establish stack container (node, parent, action, cost) 
    pq.push((start, None, None, 0), 0)
    # if the priority queue is empty, return failure (empty moves)
    while not pq.isEmpty():
        # unpack priority queue items
        node, parent, action, storedcost = pq.pop()
        # check the state is not already visited
        if node not in visited:
            visited.append(node)
            # if node is goal state, create move list
            if problem.isGoalState(node):
                node = parent
                moves.append(action)
                # the moves array will append with paths taken from the previous states parents
                while node != start:
                    moves = [pathOf.get(node)] + moves
                    node = parentOf.get(node)
                
                return moves

            # create dictionary of parents to state and path from parent and cost of
            if node != start:
                parentOf[node] = parent
                pathOf[node] = action
                costOf[node] = storedcost
            # find the successor states and push them on the stack and track the parent state
            children = problem.getSuccessors(node)
            for state, move, cost in children:
                if state not in visited:
                    # the cost of the state is now the cost to get to state, and cost to get to parent
                    newcost = cost + storedcost
                    pq.update((state, node, move, newcost), newcost)

    return moves

def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""
    
    # Similar to BFS, I had to rewrite astar search because my initial implementation used dictionaries 
    # to track the moves and wasn't hashable with lists. SO here is a new algorithm.

    # initialize start state
    start = problem.getStartState()
    # use a queue for BFS
    pq = util.PriorityQueue()
    # initialize lists
    visited = []
    moves = []
    startcost = 0

    # establish queue container (node, list of moves, cummulative cost)
    pq.push((start, moves, startcost), 0)

    while not pq.isEmpty():
        # unpack queue container
        node, movelist, storedcost = pq.pop()
        # check the state is not already visited
        if node not in visited:
            visited.append(node)
            # if node is goal state, return move list
            if problem.isGoalState(node):

                return movelist

            # find the successor states and push them on the queue with an updated list of actions taken.
            children = problem.getSuccessors(node)
            for state, action, cost in children:
                if state not in visited:
                    h = heuristic(state, problem)
                    newcost = cost + storedcost + h
                    pq.update((state, movelist + [action], cost + storedcost), newcost)
                    
    return moves
    

# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
