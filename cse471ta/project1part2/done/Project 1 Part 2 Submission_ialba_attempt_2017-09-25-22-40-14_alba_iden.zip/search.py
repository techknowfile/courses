# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
#
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()

# used in DFS
class Node:

    def __init__(self, action_list, visited_set, successor, cost):
        self.actions = action_list
        self.visited = visited_set
        self.successor = successor
        self.cost = cost

# used in BFS
class Node1:

    def __init__(self, state, parent, path_cost, action):
        self.state = state
        self.parent = parent
        self.path_cost = path_cost
        self.action = action


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]


def depthFirstSearch(problem):
    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches the
    goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:

    print "Start:", problem.getStartState()
    print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    print "Start's successors:", problem.getSuccessors(problem.getStartState())
    """
    from util import Stack

    # Initialize problem:
    # - Create node from start state
    # - Push ^ onto data structure
    # - Create closed/visited set
    node = Node1(problem.getStartState(), None, 0, '')
    if problem.isGoalState(node.state):
        return Solution(node)

    stack = Stack()
    stack.push(node)

    closed_set = set()

    # Search logic
    while True:
        # IF DS empty (and no goal found) -> return
        if stack.isEmpty():
            print "Failure"
            return []

        # Node expansion logic: pop node, add to closed set
        curr_node = stack.pop()
        closed_set.add(curr_node.state)

        # Check if expansion is goal state
        if problem.isGoalState(curr_node.state):
            return Solution(curr_node)

        # Process successors
        successors = problem.getSuccessors(curr_node.state)
        for succ in successors:
            child = Node1(succ[0], curr_node, 0, succ[1])
            if child.state not in closed_set:
                stack.push(child)


def getPriority(problem, node):
    actions = Solution(node)
    return problem.getCostOfActions(actions)


def Solution(node):
    action_list = []
    while node is not None:
        move = node.action
        if move != '':
            action_list.insert(0, node.action)

        node = node.parent

    return action_list


# BFS altered
def breadthFirstSearch(problem):
    """Search the shallowest nodes in the search tree first."""
    from util import Queue

    # Initialize problem:
    # - Create node from start state
    # - Push ^ onto data structure
    # - Create closed/visited set
    node = Node1(problem.getStartState(), None, 0, '')
    if problem.isGoalState(node.state):
        return Solution(node)

    queue = Queue()
    queue.push(node)

    closed_set = set()

    # Search logic
    while True:
        # IF DS empty (and no goal found) -> return
        if queue.isEmpty():
            print "Failure"
            return []

        # Node expansion logic: pop node, add to closed set
        curr_node = queue.pop()
        closed_set.add(curr_node.state)

        # Check if expansion is goal state
        if problem.isGoalState(curr_node.state):
            return Solution(curr_node)

        # Process successors
        successors = problem.getSuccessors(curr_node.state)
        for succ in successors:
            child = Node1(succ[0], curr_node, 0, succ[1])
            if child.state not in closed_set:
                queue.push(child)
                closed_set.add(child.state)


def uniformCostSearch(problem):
    """Search the node of least total cost first."""
    from util import PriorityQueue
    import heapq

    # Initialize problem:
    # - Create node from start state
    # - Push ^ onto data structure
    # - Create closed/visited set
    node = Node1(problem.getStartState(), None, 0, '')
    if problem.isGoalState(node.state):
        return Solution(node)

    pri_queue = PriorityQueue()
    pri_queue.push(node, getPriority(problem, node))

    closed_set = set()

    # Search logic
    while True:
        # IF DS empty (and no goal found) -> return
        if pri_queue.isEmpty():
            print "Failure"
            return []

        # Node expansion logic: pop node, add to closed set
        curr_node = pri_queue.pop()
        closed_set.add(curr_node.state)

        # Check if expansion is goal state
        if problem.isGoalState(curr_node.state):
            return Solution(curr_node)

        # Process successors
        successors = problem.getSuccessors(curr_node.state)
        for succ in successors:
            child = Node1(succ[0], curr_node, curr_node.path_cost + succ[2], succ[1])
            if child.state not in closed_set:
                pri_queue.update(child, getPriority(problem, child))
                closed_set.add(child.state)
            # child state exists in closed_set
            else:
                # Checking to see if node exists in PRIqueue with same state
                # --> IF yes, and it's priority is higher than child, update value
                for index, (p, c, i) in enumerate(pri_queue.heap):
                    if i.state == child.state:
                        if p <= getPriority(problem, child):
                            break
                        del pri_queue.heap[index]
                        pri_queue.heap.append((getPriority(problem, child), c, child))
                        heapq.heapify(pri_queue.heap)
                        break


def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""
    from util import PriorityQueue

    # Initialize problem:
    # - Create node from start state
    # - Push ^ onto data structure
    # - Create closed/visited set
    node = Node1(problem.getStartState(), None, 0, '')
    # if problem.isGoalState(node.state):
    #     return Solution(node)

    # Node expansion logic: pop node, add to closed set
    pri_queue = PriorityQueue()
    closed_set = set()


    pri_queue.push(node, getPriority(problem, node) + heuristic(problem.getStartState(), problem))

    # Search logic
    while True:
        # IF DS empty (and no goal found) -> return
        if pri_queue.isEmpty():
            print "Failure"
            return []

        # Node expansion logic: pop node, add to closed set
        curr_node = pri_queue.pop()

        # Check if expansion is goal state
        if problem.isGoalState(curr_node.state):
            return Solution(curr_node)

        if curr_node.state in closed_set:
            continue

        closed_set.add(curr_node.state)

        # process successors
        successors = problem.getSuccessors(curr_node.state)
        for succ in successors:
            child = Node1(succ[0], curr_node, curr_node.path_cost + succ[2], succ[1])

            if child.state in closed_set:
                continue

            pri_queue.push(child, getPriority(problem, child) + heuristic(child.state, problem))


# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
