# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

def depthFirstSearch(problem):
    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches the
    goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:

    print "Start:", problem.getStartState()
    print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    print "Start's successors:", problem.getSuccessors(problem.getStartState())
    """
    #"*** YOUR CODE HERE ***"
    #print "Start:", problem.getStartState()
    #print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    #print "Start's successors:", problem.getSuccessors(problem.getStartState())

    #first, I need some variables to keep track of where I've been and where I'm going.
    visited = []
    directions = []
    stack = util.Stack() #the stack structure works best with DFS.

    #next, I need to initialize my stack.
    stack.push((problem.getStartState(), directions))

    while not stack.isEmpty():
        top = stack.pop()
        state, dir = top
        #state is the current state, and dir is the current set of directions to state.

        if not visited.__contains__(state): #if we haven't visited the current state
            visited.append(state) #now we've visited it!

            if problem.isGoalState(state):
                return dir
            #if we've found the goal state, we return the directions to the goal state, which is the current one.

            successors = problem.getSuccessors(state) #we'll expand the state and see what's here.

            for successor in successors:
                succ_state, succ_directions, cost = successor
                if not visited.__contains__(succ_state):
                    directions = dir + [succ_directions] #the directions are only to current node, not every direction.
                    stack.push((succ_state, directions))

    return [] #this is for if there is no goal state.


def breadthFirstSearch(problem):
    """Search the shallowest nodes in the search tree first."""
    #first, I need some variables to keep track of where I've been and where I'm going.
    visited = []
    directions = []
    queue = util.Queue() #the queue structure works best with BFS.

    #next, I need to initialize my stack.
    queue.push((problem.getStartState(), directions))

    while not queue.isEmpty():
        top = queue.pop()
        state, dir = top
        #state is the current state, and dir is the current set of directions to state.

        if not visited.__contains__(state): #if we haven't visited the current state
            visited.append(state) #now we've visited it!

            if problem.isGoalState(state):
                return dir
            # if we've found the goal state, we return the directions to the goal state, which is the current state.

            successors = problem.getSuccessors(state) #we'll expand the state and see what's here.

            for successor in successors:
                succ_state, succ_directions, cost = successor
                if not visited.__contains__(succ_state):
                    directions = dir + [succ_directions] #the directions are only to current node, not every direction.
                    queue.push((succ_state, directions))

    return [] #if there is no goal state, there are no directions to it.

def uniformCostSearch(problem):
    """Search the node of least total cost first."""
    visited = []
    directions = []
    queue = util.PriorityQueue() #the Priority Queue works best with UCS.

    #next, I need to initialize my stack.
    queue.push((problem.getStartState(), directions), 0)
    #I've pushed a cost of 0 because there is no special heuristic for UCS, so 0 works just fine.

    while not queue.isEmpty():
        state, dir = queue.pop()
        #state is the current state, and dir is the current set of directions to state.

        if not visited.__contains__(state): #if we haven't visited the current state
            visited.append(state) #now we've visited it!

            if problem.isGoalState(state):
                return dir
            # if we've found the goal state, we return the directions to the goal state, which is the current state.

            successors = problem.getSuccessors(state) #we'll expand the state and see what's here.

            for successor in successors:
                succ_state, succ_directions, succ_cost = successor
                if not visited.__contains__(succ_state):
                    directions = dir + [succ_directions] #the directions are only to current state, not every direction.
                    new_cost = problem.getCostOfActions(directions)
                    # the cost is the total cost of all the directions taken so far to the state, plus its own
                    # heuristic value. But UCS only goes by path cost, so there is no heuristic value.
                    queue.push((succ_state, directions), new_cost)

    return []

def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""
    visited = []
    directions = []
    queue = util.PriorityQueue() #the Priority Queue works best with A* search.

    #next, I need to initialize my stack.
    queue.push((problem.getStartState(), directions), heuristic(problem.getStartState(), problem))

    while not queue.isEmpty():
        state, dir = queue.pop()
        #state is the current state, and dir is the current set of directions to state.

        if not visited.__contains__(state): #if we haven't visited the current state
            visited.append(state) #now we've visited it!

            if problem.isGoalState(state):
                return dir
            # if we've found the goal state, we return the directions to the goal state, which is the current state.

            successors = problem.getSuccessors(state) #we'll expand the state and see what's here.

            for successor in successors:
                succ_state, succ_directions, succ_cost = successor
                if not visited.__contains__(succ_state):
                    directions = dir + [succ_directions] #the directions are only to current state, not every direction.
                    cost = heuristic(succ_state, problem) + problem.getCostOfActions(directions)
                    #the cost is the total cost of all the directions taken so far to the state, plus its own
                    #heuristic value.
                    queue.push((succ_state, directions), cost)

    return []


# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
