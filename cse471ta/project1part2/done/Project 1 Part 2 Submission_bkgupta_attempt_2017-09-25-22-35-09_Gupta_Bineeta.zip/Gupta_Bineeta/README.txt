Name: Bineeta Gupta
ID: 1211257447
Project: Project Part 2

IDE: Visual Studios Code
Language: Python 3

POINTS: 

1. I followed TAs instructions a LOT for finishing this project. 
3. I used MazeDistance function as sub-process (Hint by a TA on Piazza)