# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).

Darcy Hughes
1211674318
CSE 471, Project 1 Part 1
9-15-17

"""

import util

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

def graphSearch( problem, frontier):

    # check if start state is a goal state
    state = problem.getStartState()
    if problem.isGoalState(state):
        return []

    # Set up
    explored = []

    # Create node and push it onto the frontier
    rootNode = Node(state)
    frontier.push(rootNode)

    # while frontier is not empty
    while frontier:

        # pop top node
        currentNode = frontier.pop()

        if currentNode.state not in explored:
            # check if successor is goal state
            if problem.isGoalState(currentNode.state):
                # if it is return solution
                return currentNode.path

            # add successor to explored list
            explored.append(currentNode.state)

            # add successor's children to frontier
            for child in problem.getSuccessors(currentNode.state):

                # create child node with info from getSuccessors
                (successor, action, stepCost) = child
                cost = currentNode.cost + stepCost
                path = currentNode.path + [action]
                childNode = Node(successor, cost, path)

                # push childNode onto frontier
                frontier.push(childNode)

    return []

    util.raiseNotDefined()


def depthFirstSearch(problem):
    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches the
    goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:

    print "Start:", problem.getStartState()
    print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    print "Start's successors:", problem.getSuccessors(problem.getStartState())
    """
    "*** YOUR CODE HERE ***"

    frontier = util.Stack()
    return graphSearch( problem, frontier)
    
    util.raiseNotDefined()

def breadthFirstSearch(problem):
    """Search the shallowest nodes in the search tree first."""
    """
        Pseudocode from textbook:
        function BREADTH-FIRST-SEARCH(problem) returns a solution, or failure
        node <- a node with STATE = problem.INITIAL-STATE, PATH-COST = 0
        if problem.GOAL-TEST(node.STATE) then return SOLUTION(node) frontier <- a FIFO queue with node as the only element explored <- an empty set
        loop do
            if EMPTY?(frontier) then return failure
            node<-POP(frontier) /*choosestheshallowestnodeinfrontier */
            add node.STATE to explored
            for each action in problem.ACTIONS(node.STATE) do
                child <-CHILD-NODE(problem,node,action)
                if child.STATE is not in explored or frontier then
                    if problem.GOAL-TEST(child.STATE) then return SOLUTION(child) frontier <-INSERT(child,frontier)"""
    "*** YOUR CODE HERE ***"
    frontier = util.Queue()
    return graphSearch( problem, frontier)

    util.raiseNotDefined()

def uniformCostSearch(problem):
    """Search the node of least total cost first."""
    """ 
    Pseudocode from textbook:
    function UNIFORM-COST-SEARCH(problem) returns a solution, or failure
        node <- a node with STATE = problem.INITIAL-STATE, PATH-COST = 0
        frontier <- a priority queue ordered by PATH-COST, with node as the only element explored <- an empty set
        loop do
            if EMPTY?(frontier) then return failure
            node<-POP(frontier) /*choosesthelowest-costnodeinfrontier */
            if problem.GOAL-TEST(node.STATE) then return SOLUTION(node) 
            add node.STATE to explored
                for each action in problem.ACTIONS(node.STATE) do
                    child <-CHILD-NODE(problem,node,action)
                    if child.STATE is not in explored or frontier then
                        frontier <-INSERT(child,frontier)
                    else if child.STATE is in frontier with higher PATH-COST then
                        replace that frontier node with child"""
    "*** YOUR CODE HERE ***"

    # check if start state is a goal state
    state = problem.getStartState()
    if problem.isGoalState(state):
        return []

    # Set up
    explored = []
    frontier = util.PriorityQueue()

    # Create node and push it onto the frontier
    rootNode = Node(state)
    frontier.push(rootNode, rootNode.cost)  # <- totalCost of path

    # while frontier is not empty
    while frontier:

        # pop top node
        currentNode = frontier.pop()

        if currentNode.state not in explored:
            if problem.isGoalState(currentNode.state):
                # if it is return solution
                return currentNode.path

            # add state to explored list
            explored.append(currentNode.state)

            for child in problem.getSuccessors(currentNode.state):

                # Create child node
                (successor, action, stepCost) = child
                cost = stepCost
                path = currentNode.path + [action]
                childNode = Node(successor, cost, path)

                # update either pushes new node or updates an existing node with new totalCost
                frontier.update(childNode, problem.getCostOfActions(path))

    return []

    util.raiseNotDefined()

def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""
    "*** YOUR CODE HERE ***"

    # check if start state is a goal state
    state = problem.getStartState()
    if problem.isGoalState(state):
        return []

    # Set up
    explored = []
    frontier = util.PriorityQueue()

    # Create node and push it onto the frontier
    rootNode = Node( state)
    frontier.push( rootNode, rootNode.cost) #<- totalCost of path

    # while frontier is not empty
    # issue while is an infinite loop
    while not frontier.isEmpty():
        # pop top node
        currentNode = frontier.pop()

        if currentNode.state not in explored:
            if problem.isGoalState(currentNode.state):
                # if it is return solution
                return currentNode.path

            # add state to explored list
            explored.append(currentNode.state)

            for child in problem.getSuccessors(currentNode.state):
                # create a new node
                (successor, action, stepCost) = child
                cost = stepCost
                path = currentNode.path + [action]
                childNode = Node(successor, cost, path)

                # either updates or pushes a new childNode with a new priority = totalCost + heuristic
                priority = problem.getCostOfActions(path) + heuristic(childNode.state, problem)
                frontier.update( childNode, priority)

    return []

    util.raiseNotDefined()


# A class to hold the contents of a node.
class Node:
    def __init__(self, state, cost=0, path=[]):
        self.state = state      # state
        self.cost = cost        # incremental cost of node
        self.path = path        # path to get to this node from rootNode


# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
