# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

def depthFirstSearch(problem):

    # initializing the start state and placing it into stack
    stack = util.Stack()
    placeholderNode = (problem.getStartState(), 'startState', 0)
    stack.push(placeholderNode)

    # lists and dictionaries used to track goal back to start state
    reversePath = []
    path = []
    nodesVisited = []
    parent = dict()

    # while stack is populated
    while stack:
        node = stack.pop()
        goalChecker = node[0]


        if problem.isGoalState(goalChecker):
            # append all nodes to list, starting from goal to start
            reversePath.append(node)
            node = parent[node]
            while node[1] != "startState":
                reversePath.append(node)
                node = parent[node]

            # reverse list of nodes in order to have start->goal path
            regularPath = reversePath[::-1]

            # extract only directions from path in order to return
            for item in [index[1] for index in regularPath]:
                path.append(item)

            return path


        if node not in nodesVisited:
            # for unvisited nodes, append to visited list
           nodesVisited.append(node)
           for adjacent in problem.getSuccessors(node[0]):
               # for all successors of current node, if they have not been visited
               if adjacent[0] not in [index[0] for index in nodesVisited]:
                   # push onto stack and set successors parent to be node
                    stack.push(adjacent)
                    parent[adjacent] = node

    util.raiseNotDefined()

def breadthFirstSearch(problem):

    # initializing the start state and placing it into queue
    queue = util.Queue()
    placeholderNode = (problem.getStartState(), [])
    queue.push(placeholderNode)

    # lists and dictionaries used to track goal back to start state
    nodesVisited = []

    # while the queue is populated
    while queue.isEmpty() == False:
        node, directionsList = queue.pop()

        nodesVisited.append(node[0])

        if problem.isGoalState(node):
            return directionsList

        for successors in problem.getSuccessors(node):
            if successors[0] not in nodesVisited:
                newDirections = directionsList + [successors[1]]
                queue.push( (successors[0], newDirections) )
                nodesVisited.append(successors[0])

def uniformCostSearch(problem):

    priorityQueue = util.PriorityQueue()
    priorityQueue.push((problem.getStartState(), []), 0)

    # lists and dictionaries used to track goal back to start state
    nodesVisited = []

    # while the priority queue is populated
    while priorityQueue.isEmpty() == False:
        node, directionsList = priorityQueue.pop()

        # checking if node is a goal state
        if problem.isGoalState(node):
            return directionsList

        # if node has not been visited
        if node not in nodesVisited:
            nodesVisited.append(node)

            # for each successor of the node
            for successors in problem.getSuccessors(node):
                # updating the directions for that successor
                newDirections = directionsList + [successors[1]]

                # getting the total path cost + heuristic estimation to get f(n)
                heuristicCost = problem.getCostOfActions(newDirections)

                # updating the priority queue with newDirections and new priority cost based on heuristic
                priorityQueue.update((successors[0], newDirections), heuristicCost)

    "*** YOUR CODE HERE ***"
    util.raiseNotDefined()

def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""
    priorityQueue = util.PriorityQueue()
    priorityQueue.push((problem.getStartState(), []), 0)

    # lists and dictionaries used to track goal back to start state
    nodesVisited = []

    # while the priority queue is populated
    while priorityQueue.isEmpty() == False:
        node, directionsList = priorityQueue.pop()

        # checking if node is a goal state
        if problem.isGoalState(node):
            return directionsList

        # if node has not been visited
        if node not in nodesVisited:
            nodesVisited.append(node)

            # for each successor of the node
            for successors in problem.getSuccessors(node):
                # updating the directions for that successor
                newDirections = directionsList + [successors[1]]

                # getting the total path cost + heuristic estimation to get f(n)
                heuristicCost = problem.getCostOfActions(newDirections)
                heuristicCost += heuristic(successors[0], problem)

                # updating the priority queue with newDirections and new priority cost based on heuristic
                priorityQueue.update((successors[0], newDirections), heuristicCost)


# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
