# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
#
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util
import sys
import operator


class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return [s, s, w, s, w, w, s, w]


def getDirection(direction):
    from game import Directions
    n = Directions.NORTH
    s = Directions.SOUTH
    w = Directions.WEST
    e = Directions.EAST
    if direction == 'South':
        return s
    elif direction == 'North':
        return n
    elif direction == 'West':
        return w
    elif direction == 'East':
        return e


def sortsuccessors(successors):
    sorted_successors = sorted(successors, key=lambda tup: tup[1])
    return sorted_successors


def depthFirstSearch(problem):
    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches the
    goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:

    print "Start:", problem.getStartState()
    print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    print "Start's successors:", problem.getSuccessors(problem.getStartState())
    """
    "*** YOUR CODE HERE ***"
    # util.raiseNotDefined()

    pq = util.PriorityQueue()
    loc_hash = util.Counter()

    priority = sys.maxint

    start_state = problem.getStartState()

    loc_hash[start_state] = 1

    successors = problem.getSuccessors(start_state)

    for state in reversed(successors):

        position = state[0]
        action = state[1]

        pq.push([[action, ], priority, position], priority)

    while not pq.isEmpty():

        current_item = pq.pop()

        current_action_list = current_item[0]
        current_priority = current_item[1]
        current_position = current_item[2]

        if problem.isGoalState(current_position):
            return current_action_list
        elif loc_hash[current_position] <= 0:

            loc_hash[current_position] = loc_hash[current_position] + 1
            next_priority = current_priority - 1

            # print "Current Item = ", current_item
            # print "Prioirty = ", current_priority, " , Position = ", current_position
            # print "Current Action List = ", current_action_list

            children = problem.getSuccessors(current_position)

            for child_state in reversed(children):

                # print "Child Considered = ", child_state, " | ",
                # next_priority

                child_successor = child_state[0]

                if loc_hash[child_successor] <= 0:

                    child_action = child_state[1]
                    child_action_list = list(current_action_list)
                    child_action_list.append(child_action)

                    # print "Child Pushed = ", child_state, " | ", next_priority
                    # print "Child Pushed Action List = ", child_action_list

                    pq.push([child_action_list, next_priority,
                             child_successor], next_priority)


def breadthFirstSearch(problem):
    """Search the shallowest nodes in the search tree first."""
    "*** YOUR CODE HERE ***"
    # util.raiseNotDefined()
    pq = util.PriorityQueue()
    loc_hash = util.Counter()

    priority = 1
    index = 1

    start_state = problem.getStartState()

    loc_hash[start_state] = 1

    successors = problem.getSuccessors(start_state)

    for state in successors:

        position = state[0]
        action = state[1]

        current_priority = (2 * priority) + index
        index = index + 1

        pq.push([[action, ], current_priority,
                 position], current_priority)

    while not pq.isEmpty():

        current_item = pq.pop()

        current_action_list = current_item[0]
        current_priority = current_item[1]
        current_position = current_item[2]

        if problem.isGoalState(current_position):
            return current_action_list
        elif loc_hash[current_position] <= 0:

            loc_hash[current_position] = loc_hash[current_position] + 1
            current_index = 1

            # print "Current Item = ", current_item
            # print "Prioirty = ", current_priority, " , Position = ", current_position
            # print "Current Action List = ", current_action_list

            children = problem.getSuccessors(current_position)
            children = sortsuccessors(children)

            for child_state in children:

                # print "Child Considered = ", child_state

                child_successor = child_state[0]

                if loc_hash[child_successor] <= 0:

                    child_action = child_state[1]
                    child_action_list = list(current_action_list)
                    child_action_list.append(child_action)

                    next_priority = (2 * current_priority) + current_index
                    current_index = current_index + 1

                    # print "Child Pushed = ", child_state, " | ", next_priority
                    # print "Child Pushed Action List = ", child_action_list

                    pq.push([child_action_list, next_priority,
                             child_successor], next_priority)


def uniformCostSearch(problem):
    """Search the node of least total cost first."""
    "*** YOUR CODE HERE ***"
    # util.raiseNotDefined()

    pq = util.PriorityQueue()
    loc_hash = util.Counter()

    start_state = problem.getStartState()

    loc_hash[start_state] = 1

    successors = problem.getSuccessors(start_state)
    # successors = sortsuccessors(successors)

    for state in successors:

        position = state[0]
        action = state[1]
        cost = state[2]

        pq.push([[action, ], cost, position], cost)

    while not pq.isEmpty():

        current_item = pq.pop()

        current_action_list = current_item[0]
        current_priority = current_item[1]
        current_position = current_item[2]

        if problem.isGoalState(current_position):
            return current_action_list
        elif loc_hash[current_position] <= 0:

            loc_hash[current_position] = loc_hash[current_position] + 1

            # print "Current Item = ", current_item
            # print "Prioirty = ", current_priority, " , Position = ", current_position
            # print "Current Action List = ", current_action_list

            children = problem.getSuccessors(current_position)
            # children = sortsuccessors(children)

            for child_state in children:

                # print "Child Considered = ", child_state

                child_position = child_state[0]

                if loc_hash[child_position] <= 0:

                    child_action = child_state[1]
                    child_action_list = list(current_action_list)
                    child_action_list.append(child_action)
                    child_cost = child_state[2]

                    next_priority = child_cost + current_priority

                    # print "Child Pushed = ", child_state, " | ", next_priority
                    # print "Child Pushed Action List = ", child_action_list

                    pq.push([child_action_list, next_priority,
                             child_position], next_priority)


def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0


def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""
    "*** YOUR CODE HERE ***"
    # util.raiseNotDefined()

    pq = util.PriorityQueue()
    loc_hash = util.Counter()

    start_state = problem.getStartState()

    loc_hash[start_state] = 1
    start_g_cost = 0

    successors = problem.getSuccessors(start_state)
    # successors = sortsuccessors(successors)

    for state in successors:

        position = state[0]
        action = state[1]
        cost = state[2]

        g_cost = start_g_cost + cost
        h_cost = heuristic(position, problem)
        f_cost = g_cost + h_cost

        pq.push([[action, ],  g_cost,
                 position],  f_cost)

    while not pq.isEmpty():

        current_item = pq.pop()

        current_action_list = current_item[0]
        current_g_cost = current_item[1]
        current_position = current_item[2]

        if problem.isGoalState(current_position):
            return current_action_list
        elif loc_hash[current_position] <= 0:

            loc_hash[current_position] = loc_hash[current_position] + 1

            # print "Current Item = ", current_item
            # print "Prioirty = ", current_g_cost, " , Position = ", current_position
            # print "Current Action List = ", current_action_list

            children = problem.getSuccessors(current_position)

            for child_state in children:

                # print "Child Considered = ", child_state

                child_position = child_state[0]

                if loc_hash[child_position] <= 0:

                    child_action = child_state[1]
                    child_action_list = list(current_action_list)
                    child_action_list.append(child_action)
                    child_cost = child_state[2]

                    child_g_cost = current_g_cost + child_cost
                    child_h_cost = heuristic(child_position, problem)
                    child_f_cost = child_g_cost + child_h_cost

                    # print "Child Pushed = ", child_state, " | ", child_cost, " | ", child_g_cost, " | ", child_h_cost, " | ", child_f_cost
                    # print "Child Pushed Action List = ",
                    # child_action_list

                    pq.push([child_action_list,  child_g_cost,
                             child_position],  child_f_cost)


# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
