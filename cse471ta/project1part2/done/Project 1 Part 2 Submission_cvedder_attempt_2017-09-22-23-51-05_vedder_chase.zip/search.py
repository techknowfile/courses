# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

def depthFirstSearch(problem):
    """Search the deepest nodes in the search tree first."""

    #Call a method that will do DFS recursively
    return dfsRecursive(problem, problem.getStartState(), [problem.getStartState()], [])

def dfsRecursive(problem, state, visited, path):
    #If we're at the goal, return how we got here
    if problem.isGoalState(state):
        return path

    #Traverse each branch coming from this node
    for s, direction, cost in problem.getSuccessors(state):

        #Only check things we haven't seen yet
        if s not in visited:
            visited.append(s)

            #Traverse from this child, and return a path to the goal if one is found
            directions = dfsRecursive(problem, s, visited, path + [direction])
            if directions:
                return directions

    return []


def breadthFirstSearch(problem):
    """Search the shallowest nodes in the search tree first."""

    #A Queue will hold the nodes to visit
    q = util.Queue()
    q.push((problem.getStartState(), []))

    visited = []
    visited.append(problem.getStartState())

    while not q.isEmpty():
        curr, directions = q.pop()

        #If we're at the goal, return how we got here
        if problem.isGoalState(curr):
            return directions

        #For each unvisited child, add it to the queue so it will get traversed
        for coord, direction, cost in problem.getSuccessors(curr):
            if coord not in visited:
                q.push((coord, directions + [direction]))
                visited.append(coord)
    return []

def uniformCostSearch(problem):
    """Search the node of least total cost first."""

    #Use a priority queue so the least cost path will be considered first
    q = util.PriorityQueue()
    q.push((problem.getStartState(), [], 0), 0)

    #Keep a map of the cheapest cost to a node so far
    visited = {problem.getStartState(): 0}

    while not q.isEmpty():
        curr, directions, costSoFar = q.pop()

        #If we're at the goal, return how we got here
        if problem.isGoalState(curr):
            return directions

        #Add each child to the priority queue with the cost to get to it
        for coord, direction, cost in problem.getSuccessors(curr):
            totalCost = costSoFar + cost

            #Even if the node is visited, traverse it if it's less cost than the current
            #cheapest cost to get there
            if coord not in visited or totalCost < visited[coord]:
                q.push((coord, directions + [direction], totalCost), totalCost)
                visited[coord] = totalCost

    return []

def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""

    #Create lists and dictionaries to store things that still need to be searched,
    #the current g and f scores of a node, and the directions to get to a given state
    closedSet = []
    openSet = [problem.getStartState()]
    
    gScores = {}
    gScores[problem.getStartState()] = 0

    fScores = util.PriorityQueue()
    fScores.push(problem.getStartState(), heuristic(problem.getStartState(), problem))

    directions = {problem.getStartState(): []}

    while openSet:
        curr = fScores.pop()

        #If we're at the goal, return how we got here
        if problem.isGoalState(curr):
            return directions[curr]

        #Remove the node we're at  from the open set, and add it to the closed set
        if curr in openSet:
            openSet.remove(curr)
        closedSet.append(curr)

        #Traverse each child node if it's not in the closedSet
        for coord, direction, cost in problem.getSuccessors(curr):
            if coord not in closedSet:
                if coord not in openSet:
                    openSet.append(coord)

                score = gScores[curr] + cost

                #If this g score is higher than the current g score, skip since its a worse path
                if coord in gScores and score >= gScores[coord]:
                    continue

                #Update the directions to this node and the g and f scores
                directions[coord] = directions[curr] + [direction]
                gScores[coord] = score
                fScores.push(coord, gScores[coord] + heuristic(coord, problem))



# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
