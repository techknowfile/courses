# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

def depthFirstSearch(problem):
    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches the
    goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:
    """  

    fringe = util.Stack()                               # Start with an empty stack
    visited = set()                                     # Create an empty visited set 
    if problem.isGoalState(problem.getStartState()):    # Push the starting node into the stack
        return visited                                  # ...and mark it as visited
    fringe.push((problem.getStartState(), [], 0))       # I push everything in the tuple: state, direction, and cost
    
    while not fringe.isEmpty():                         # While the stack is not empty, visit each node 
        currentNode = fringe.pop()                      # Return the top node in the stack
        node, direction, cost = currentNode             # ...and assign variable names to them
        if problem.isGoalState(node):                   # If we reach the goal state, return direction
            return direction
        visited.add(node)                               # Else, add the node to the visited set
        neighbors = problem.getSuccessors(node)         # ...and check all the neighboring nodes
        for neighbor, direct, cos in neighbors:         # Extract everything from the neighbor
            if neighbor not in visited:                 # If the neighbor hasn't been visited, push to stack
                fringe.push((neighbor, direction + [direct], cos))
    return []

def breadthFirstSearch(problem):
    fringe = util.Queue()                               # Start with an empty queue
    visited = []                                        # Create an empty visited set 
    if problem.isGoalState(problem.getStartState()):    # Push the starting node into the stack
        return visited                                  # ...and mark it as visited
    fringe.push((problem.getStartState(), [], 0))       # I push everything in the tuple: state, direction, and cost
    
    while not fringe.isEmpty():                         # While the queue is not empty, visit each node 
        currentNode = fringe.pop()                      # Return the first node in the queue
        node, direction, cost = currentNode             # ...and assign variable names to them
        if problem.isGoalState(node):                   # If we reach the goal state, return direction
            return direction
        visited.append(node)                               # Else, add the node to the visited set
        neighbors = problem.getSuccessors(node)         # ...and check all the neighboring nodes
        for neighbor, direct, cos in neighbors:         # Extract everything from the neighbor
            if neighbor not in visited:                 # If the neighbor hasn't been visited, push to queue
                visited.append(neighbor)                   # ...and add the node to the visited set
                fringe.push((neighbor, direction + [direct], cos))
    return []

def uniformCostSearch(problem):
    fringe = util.PriorityQueue()                       # Start with an empty queue
    visited = set()                                     # Create an empty visited set 
    if problem.isGoalState(problem.getStartState()):    # Push the starting node into the stack
        return visited                                  # ...and mark it as visited
    fringe.push((problem.getStartState(), [], 0), 0)    # I push everything in the tuple and set that as the 'item', and then 'cost'
    
    while not fringe.isEmpty():                         # While the queue is not empty, visit each node 
        currentNode = fringe.pop()                      # Return the first node in the queue
        node, direction, cost = currentNode             # ...and assign variable names to them
        visited.add(node)                               # Add node to visited set
        if problem.isGoalState(node):                   # If we reach the goal state, return direction
            return direction
        neighbors = problem.getSuccessors(node)         # Check all the neighboring nodes
        for neighbor, direct, cos in neighbors:         # Extract everything from the neighbor
            if neighbor not in visited:                 # If the neighbor hasn't been visited,  
                if not problem.isGoalState(neighbor):   # ...and the next node isn't the goal state, (used if there are multiple paths to the goal node) 
                    visited.add(neighbor)               # Add the node to the visited set
                fringe.update((neighbor, direction + [direct], cost + cos),cos + cost)
    return []

def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""
    # Start with an empty priority queue
    fringe = util.PriorityQueue()                       # Start with an empty queue
    visited = set()                                     # Create an empty visited set 
    if problem.isGoalState(problem.getStartState()):    # Push the starting node into the stack
        return visited                                  # ...and mark it as visited
    fringe.push((problem.getStartState(), [], 0), nullHeuristic(problem.getStartState, problem))
    
    while not fringe.isEmpty():                         # While the queue is not empty, visit each node 
        currentNode = fringe.pop()                      # Return the first node in the queue
        node, direction, cost = currentNode             # ...and assign variable names to them
        visited.add(node)                               # Add node to visited set
        if problem.isGoalState(node):                   # If we reach the goal state, return direction
            return direction
        neighbors = problem.getSuccessors(node)         # Check all the neighboring nodes
        for neighbor, direct, cos in neighbors:         # Extract everything from the neighbor
            if neighbor not in visited:                 # If the neighbor hasn't been visited,  
                if not problem.isGoalState(neighbor):   # ...and the next node isn't the goal state, (used if there are multiple paths to the goal node) 
                    visited.add(neighbor)               # Add the node to the visited set
                newCost = problem.getCostOfActions(direction + [direct]) + heuristic(neighbor,problem)
                fringe.update((neighbor, direction + [direct], newCost),newCost)
    return []


# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
