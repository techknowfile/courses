# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

def depthFirstSearch(problem):
    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches the
    goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:

    print "Start:", problem.getStartState()
    print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    print "Start's successors:", problem.getSuccessors(problem.getStartState())
    """
    "*** YOUR CODE HERE ***"
    # print "Start:", problem.getStartState()
    # print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    # print "Start's successors:", problem.getSuccessors(problem.getStartState())

    # helper recursive function

    def DFS_helper(state, visited, path):
        # check whether goal has been reached
        if problem.isGoalState(state):
            return path, True

        # iterate over child and if child has not been visited then call the DFS helper function recursively
        for next_successor in problem.getSuccessors(state):
            # check whether the current node has been visited
            if next_successor[0] not in visited:
                visited.append(next_successor[0])
                path_found, path_found_flag = DFS_helper(state=next_successor[0], visited=visited, path=path + [next_successor[1]])
                # if the path has been found propagate it backwards
                if path_found_flag:
                    return path_found, True
        return [], False

    # intialize variables, get initial state and call recursive DFS helper function for the first time.
    initial_state = problem.getStartState()
    visited_list = [initial_state]
    result = DFS_helper(state=initial_state, visited=visited_list, path=[])
    return result[0]
    # util.raiseNotDefined()


def breadthFirstSearch(problem):
    """Search the shallowest nodes in the search tree first."""
    "*** YOUR CODE HERE ***"

    # we use queue because bfs traverses level by level and doesn't proceed to next level before covering all nodes in the current level
    bfs_queue = util.Queue()

    # initialize variables, get initial state and push root node in the  Queue.
    initial_state = problem.getStartState()
    visited_list = set()
    bfs_queue.push((initial_state, []))

    # iterate until there are no more nodes in the queue
    while not bfs_queue.isEmpty():
        # pop from the start of the  queue
        current_state, path = bfs_queue.pop()
        # check whether the current node has been visited
        if current_state not in visited_list:
            # check whether the current node is the Goal node
            if problem.isGoalState(current_state):
                return path
            visited_list.add(current_state)
            # iterate over the child nodes and add them & the path until them to the queue
            for single_state, child_path, cost in problem.getSuccessors(current_state):
                bfs_queue.push((single_state, path + [child_path]))
    # util.raiseNotDefined()


def uniformCostSearch(problem):
    """Search the node of least total cost first."""
    "*** YOUR CODE HERE ***"

    # here we use Priority Queue because UCS involves choice of next node to be traversed based on the cost of the path.
    ucs_pqueue = util.PriorityQueue()

    # initialize variables, get initial state and push root node in the  Priority Queue.
    initial_state = problem.getStartState()
    visited_list = set()
    ucs_pqueue.push((initial_state, [], 0), 0)

    # iterate until there are no more nodes in the priority queue
    while not ucs_pqueue.isEmpty():
        # pop from the start of the priority queue
        current_state, path, current_cost = ucs_pqueue.pop()
        # check whether the current node has been visited
        if current_state not in visited_list:
            if problem.isGoalState(current_state):
                return path
            visited_list.add(current_state)
            # iterate over the child nodes and add them, the path until them and the cost of the path to the queue
            for single_state, child_path, cost in problem.getSuccessors(current_state):
                ucs_pqueue.push((single_state, path + [child_path], current_cost + cost), current_cost + cost)
    # util.raiseNotDefined()


def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0


def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""
    "*** YOUR CODE HERE ***"

    # here we use Priority Queue because A* search involves choice of next node to be traversed based on the cost of the path.
    astar_pqueue = util.PriorityQueue()

    # initialize variables, get initial state and push root node in the  Priority Queue.
    initial_state = problem.getStartState()
    visited_list = set()
    astar_pqueue.push((initial_state, [], 0), 0)

    # iterate until there are no more nodes in the priority queue
    while not astar_pqueue.isEmpty():
        # pop from the start of the priority queue
        current_state, path, current_cost = astar_pqueue.pop()
        # check whether the current node has been visited
        if current_state not in visited_list:
            if problem.isGoalState(current_state):
                return path
            visited_list.add(current_state)
            # iterate over the child nodes and add them, the path until them and the cost of the path to the queue, the priority is decided based on the heuristics
            for single_state, child_path, cost in problem.getSuccessors(current_state):
                astar_pqueue.push((single_state, path + [child_path], current_cost + cost), current_cost + cost + heuristic(single_state, problem))
    util.raiseNotDefined()


# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
