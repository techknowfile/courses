# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
#
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

def depthFirstSearch(problem):
    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches the
    goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:

    print "Start:", problem.getStartState()
    print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    print "Start's successors:", problem.getSuccessors(problem.getStartState())
    """
    "*** YOUR CODE HERE ***"
    from util import Stack
    frontier = Stack()              #nodes which will be expanded next are stored in stack
    explored = set()                #already explored nodes will be stored in this set
    current_state = problem.getStartState()
    temp_tuple = (current_state, "", 0, []) #tuple to hold successor node data plus path from root to current node
    frontier.push(temp_tuple)

    if (problem.isGoalState(current_state)):
        return []
    else:
        while (frontier.isEmpty() == False):

            #nodes will be popped from queue in LIFO sequence
            temp_node = frontier.pop()
            current_state = temp_node[0]

            if (current_state not in explored):
                explored.add(current_state)
            else:
                continue

            #if current state is the Goal state then return path from root to current state
            if (problem.isGoalState(current_state)):
                return temp_node[3]

            #get successor of current state and add them to frontier if not yet explored
            successor_list = problem.getSuccessors(current_state)
            for i in successor_list:
                ii = i[0]
                solution = temp_node[3]

                if (ii not in explored):
                    path = []
                    path = solution + [i[1]]
                    #node pushed onto frontier will have current state, action, cost of successor, path from root to current node
                    temp_tuple1 = (i[0], i[1], i[2], path)

                    frontier.push(temp_tuple1)
        return []


def breadthFirstSearch(problem):
    """Search the shallowest nodes in the search tree first."""
    "*** YOUR CODE HERE ***"
    from util import Queue
    frontier = Queue()                      #nodes which will be expanded next are stored in queue
    explored = []                           #already explored nodes will be stored in this set
    current_state = problem.getStartState()
    temp_tuple = (current_state, "", 0, []) #tuple to hold successor node data plus path from root to current node
    frontier.push(temp_tuple)

    if (problem.isGoalState(current_state)):
        return []
    else:
        while (frontier.isEmpty() == False):

            #nodes will be popped from queue in FIFO sequence
            temp_node = frontier.pop()
            current_state = temp_node[0]

            if (current_state not in explored):
                explored.append(current_state)
            else:
                continue

            #if current state is the Goal state then return path from root to current state

            if (problem.isGoalState(current_state)):
                return temp_node[3]

            #get successor of current state and add them to frontier if not yet explored
            successor_list = problem.getSuccessors(current_state)

            for i in successor_list:
                ii = i[0]
                solution = temp_node[3]
                # path = temp_node[3]
                temp_list = []
                for j in frontier.list:
                    temp_list.append(j[0])
                if (ii not in temp_list or ii not in explored):
                    path = []
                    path = solution + [i[1]]
                    #node pushed onto frontier will have current state, action, cost of successor, path from root to current node

                    temp_tuple1 = (i[0], i[1], i[2], path)
                    frontier.push(temp_tuple1)
        return []

def uniformCostSearch(problem):
    """Search the node of least total cost first."""
    "*** YOUR CODE HERE ***"
    from util import PriorityQueue
    frontier = PriorityQueue()              #nodes which will be expanded next are stored in priority queue
    explored = set()                        #already explored nodes will be stored in this set
    current_state = problem.getStartState()
    temp_tuple = (current_state,[],0)       #tuple to hold current state, path from root to current node, total cost from root to current node
    frontier.push(temp_tuple,0)

    if (problem.isGoalState(current_state)):
        return []
    else:
        while (frontier.isEmpty() == False):

            #nodes will be popped from priority queue in ascending order of total cost from root to the node
            temp_node = frontier.pop()
            current_state = temp_node[0]


            if (current_state not in explored):
                explored.add(current_state)
            else:
                continue

            #if current state is the Goal state then return path from root to current state
            if (problem.isGoalState(current_state)):
                return temp_node[1]


            #get successor of current state and add them to frontier if not yet explored
            successor_list = problem.getSuccessors(current_state)

            for successor_i in successor_list:
                successor_state = successor_i[0]
                solution = temp_node[1]
                parent_cost = temp_node[2]


                #checking if above fetched successor state exists in frontier

                temp_list = [item[2] for item in frontier.heap if item[2][0] == successor_state]
                successor_exist_in_frontier = successor_i[0] in [i[0] for i in temp_list]

                if (not successor_exist_in_frontier or successor_state not in explored):

                    path = []
                    successor_path_cost = 0

                    path = solution + [successor_i[1]]
                    successor_path_cost = parent_cost + successor_i[2]

                    temp_tuple1 = (successor_i[0], path,successor_path_cost)

                    #node pushed onto frontier will have current state, path from root to current node, total cost from root to
                    #current node

                    frontier.push(temp_tuple1,successor_path_cost)

                elif(successor_exist_in_frontier):
                    for i in temp_list:

                        frontier.update(i,successor_path_cost)

        return []

def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""
    "*** YOUR CODE HERE ***"
    from util import PriorityQueue
    frontier = PriorityQueue()              #nodes which will be expanded next are stored in priority queue
    explored = []                           #already explored nodes will be stored in this list
    current_state = problem.getStartState()
    temp_tuple = (current_state,[],0)        #tuple to hold current state, path from root to current node, total cost from root to current node
    #nodes will be pushed with priority of g(total cost from root to current state) + h (heuristic cost from current state to goal state
    frontier.push(temp_tuple,0 + heuristic(current_state,problem))


    if (problem.isGoalState(current_state)):
        return []
    else:
        while (frontier.isEmpty() == False):
            #nodes will be popped from priority queue in ascending order of g + h

            temp_node = frontier.pop()
            current_state = temp_node[0]


            if (current_state not in explored):
                explored.append(current_state)
            else:
                continue
            #if current state is the Goal state then return path from root to current state

            if (problem.isGoalState(current_state)):
                return temp_node[1]

            #get successor of current state and add them to frontier if not yet explored

            successor_list = problem.getSuccessors(current_state)

            for successor_i in successor_list:
                successor_state = successor_i[0]
                solution = temp_node[1]
                parent_cost = temp_node[2]

                if (successor_state not in explored):

                    path = []
                    successor_path_cost = 0

                    path = solution + [successor_i[1]]
                    successor_path_cost = parent_cost + successor_i[2]

                    #node pushed onto frontier will have current state, path from root to current node, total cost from root to
                    #current node(g) + heuristic cost from current state to goal state

                    temp_tuple1 = (successor_i[0], path,successor_path_cost)
                    frontier.push(temp_tuple1,successor_path_cost + heuristic(successor_state,problem))

        return []


# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
