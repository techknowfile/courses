# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

def depthFirstSearch(problem):
    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches the
    goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:

    print "Start:", problem.getStartState()
    print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    print "Start's successors:", problem.getSuccessors(problem.getStartState())
    """
    "*** YOUR CODE HERE ***"
    dfs = util.Stack()                                              #Declare a stack dfs
    explored = []                                                   #Empty list explored[] to store all the nodes that have been visited
    action = []                                                     #Empty list actions to store the list of all directions traversed by nodes    
    dic = {'state1': problem.getStartState(), 'act' : action }      #Dictionary dic to push/pop multiple elements in the stack
    dfs.push(dic)                                                   #Push the start state along with an empty action list

    while dfs.isEmpty() is not True:
        Node = dfs.pop()
        cState = Node['state1']                                     #Extract the current state from the popped element of the stack
        cMoves = Node['act']                                        #Extract the current moves from the popped element of the stack
        

        if cState not in explored:                                  
            
        
            explored.append(cState)                                 #As long as the current state is not visited add it to the explored list        

            if problem.isGoalState(cState) is True:
                
                return cMoves                                       #If the current state is the goal state, return the actions used to reach the goal state
                

            successor = problem.getSuccessors(cState)               #Store the successor state 
            for state2, direc, cost in successor:                   #Extract the triples of successor using a for loop
                if not cMoves:                                         

                    nMoves= [direc]                                 #If the current moves for a node are empty, add the directions of the successor node to the empty list
                    tups = {'state1' : state2, 'act' : nMoves}      #Store the elements in a new dictionary tups which can then be pushed in the stack

                else: 
                    mMoves = cMoves + [direc]                       #If the current moves already has a list of directions, add the successor's directions to the current moves and store thm in a new list
                    tups= {'state1' : state2, 'act' : mMoves}       
                    
                dfs.push(tups)                                      #Push the dictionary tups into the list


    util.raiseNotDefined()

def breadthFirstSearch(problem):
    """Search the shallowest nodes in the search tree first."""

    """The breadth first search algorithm is implemented using a queue data structure"""
    "*** YOUR CODE HERE ***"
    bfs = util.Queue()                                              #Declare a queue bfs
    explored = []                                                   #Empty list explored[] to store all the nodes that have been visited
    action = []                                                     #Empty list actions to store the list of all directions traversed by nodes
    dic = {'state1': problem.getStartState(), 'act' : action }      #Dictionary dic to push/pop multiple elements in the stack
    bfs.push(dic)                                                   #Push the start state along with an empty action list

    while bfs.isEmpty() is not True:
        Node = bfs.pop()
        cState = Node['state1']                                     #Extract the current state from the popped element of the stack
        cMoves = Node['act']                                        #Extract the current moves from the popped element of the stack
        

        if hash(cState)  not in explored:
            
            
            explored.append(hash(cState))                                 #As long as the current state is not visited add it to the explored list 

            if problem.isGoalState(cState) is True:
                
                return cMoves                                       #If the current state is the goal state, return the actions used to reach the goal state
                

            successor = problem.getSuccessors(cState)               #Store the successor state 
            for state2, direc, cost in successor:                   #Extract the triples of successor using a for loop
                if not cMoves:

                    tups = {'state1' : state2, 'act' : [direc]}     #If the current moves for a node are empty, add the directions of the successor node to the empty list

                else: 
                    Moves = cMoves + [direc]                        #If the current moves already has a list of directions, add the successor's directions to the current moves and store thm in a new list
                    tups= {'state1' : state2, 'act' : Moves}
                    
                bfs.push(tups)                                      #Push the dictionary tups into the list




    util.raiseNotDefined()

def uniformCostSearch(problem):
    """Search the node of least total cost first."""
    "*** YOUR CODE HERE ***"
    ucs = util.PriorityQueue()                                      #Declare a priority queue ucs
    explored = []                                                   #Empty list explored[] to store all the nodes that have been visited    
    action = []                                                     #Empty list actions to store the list of all directions traversed by nodes
    cost = 0                                                        #Declare innitial cost of reach a node as zero
    dic = {'state1': problem.getStartState(), 'act' : action, 'cst' : cost} #Dictionary dic to push/pop multiple elements in the stack
    ucs.push(dic, 0)                                                #Push the dictionary and the initial priority as zero

    while ucs.isEmpty() is not True:
        Node = ucs.pop()
        cState = Node['state1']                                     #Extract the current state from the popped element of the stack
        cMoves = Node['act']                                        #Extract the current state from the popped element of the stack
        curcost = Node['cst']                                       #Extract the current cost from the popped element of the stack
        

        if cState  not in explored:
            
            
            explored.append(cState)                                 #As long as the current state is not visited add it to the explored list

            if problem.isGoalState(cState) is True:
                
                return cMoves                                       #If the current state is the goal state, return the actions used to reach the goal state
                

            successor = problem.getSuccessors(cState)               #Store the successor state 
            for state2, direc, scost in successor:                  #Extract the triples of successor using a for loop
                tcost = curcost + scost                             #Add the cost to reach the successor node from the previous node to the total cost, this will give the cost to reach that node from the start
                if not cMoves:                                      #If the current moves for a node are empty, add the directions of the successor node to the empty list
                    
                    tups = {'state1' : state2, 'act' : [direc], 'cst' : tcost}

                else:                                               #If the current moves already has a list of directions, add the successor's directions to the current moves and store thm in a new list        
                    Moves = cMoves + [direc]

                    tups= {'state1' : state2, 'act' : Moves, 'cst': tcost}
                
                fcost = curcost + scost 

                ucs.push(tups, fcost)                               #Push the dictionary tups into the list




    

    util.raiseNotDefined()

def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):                  
    """Search the node that has the lowest combined cost and heuristic first."""
    "*** YOUR CODE HERE ***"
    astar = util.PriorityQueue()                                    #Declare a priority queue astar\
    explored = dict()                                                   #Empty list explored[] to store all the nodes that have been visited
    action = []                                                     #Empty list actions to store the list of all directions traversed by nodes
    cost = 0                                                        #Declare innitial cost of reach a node as zero
    dic = {'state1': problem.getStartState(), 'act' : action, 'cst' : cost} #Dictionary dic to push/pop multiple elements in the stack
    astar.push(dic, heuristic(problem.getStartState(), problem))    #Push the dictionary and the initial priority as the heuristic of the start state

    while astar.isEmpty() is not True:
        Node = astar.pop()                      
        cState = Node['state1']                                     #Extract the current state from the popped element of the stack
        cMoves = Node['act']                                        #Extract the current state from the popped element of the stack
        curcost = Node['cst']                                       #Extract the current cost from the popped element of the stack
        

        if hash((cState)) not in explored:
            
            if problem.isGoalState(cState) is True:
                
                return cMoves

            explored[hash(cState)] = True                                 #As long as the current state is not visited add it to the explored list
    

            successor = problem.getSuccessors(cState)               #Store the successor state
                          
            for state2, direc, scost in successor:                  #Extract the triples of successor using a for loop
                
                if not cMoves:                                      #If the current moves for a node are empty, add the directions of the successor node to the empty list

                    tups = {'state1' : state2, 'act' : [direc], 'cst' : curcost + scost}

                else:                                               #If the current moves already has a list of directions, add the successor's directions to the current moves and store thm in a new list
                    Moves = cMoves + [direc]
                    tups= {'state1' : state2, 'act' : Moves, 'cst': curcost + scost}
                
                tcost = curcost + scost                             #Update the total cost from the start state to the successor state
                
                 #Add the total cost the G value to the heuristic H value to push the combined cost in the stack
                
                astar.push(tups, tcost + heuristic(state2, problem))
                
        


# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
