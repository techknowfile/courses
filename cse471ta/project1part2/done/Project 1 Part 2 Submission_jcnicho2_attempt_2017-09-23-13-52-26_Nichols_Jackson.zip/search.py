# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util
#all search algorithms assume the starting node is not the goal node

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
	"""
	Returns a sequence of moves that solves tinyMaze.  For any other maze, the
	sequence of moves will be incorrect, so only use this for tinyMaze.
	"""
	from game import Directions
	s = Directions.SOUTH
	w = Directions.WEST
	return  [s, s, w, s, w, w, s, w]

def depthFirstSearch(problem):
	"""
	Search the deepest nodes in the search tree first.
	
	Your search algorithm needs to return a list of actions that reaches the
	goal. Make sure to implement a graph search algorithm.
	
	To get started, you might want to try some of these simple commands to
	understand the search problem that is being passed in:
	
	print "Start:", problem.getStartState()
	print "Is the start a goal?", problem.isGoalState(problem.getStartState())
	print "Start's successors:", problem.getSuccessors(problem.getStartState())
	"""
	
	"*** YOUR CODE HERE ***"
	from game import Directions
	n = Directions.NORTH
	s = Directions.SOUTH
	w = Directions.WEST
	e = Directions.EAST
	
	#create list of directions
	direc = []
	
	#find the path via algorithm
	storage = util.Stack() #stores successors until used
	starts = []
	actions = []
	stops = []
	visited = []
	
	tmpHold = [] #this holds successors before processing
	completeNode = [] #this is a node w/ fields & additonal parent field
	parentHold = []
	starts.append((0,0)) #parent of start is out of bounds
	actions.append("None") #no path to this parent
	stops.append(problem.getStartState()) #ends at the origin of pacman
	parentXY = problem.getStartState()
	visited.append(problem.getStartState())
	tmpHold = problem.getSuccessors(problem.getStartState())
	for node in tmpHold:
		nextXY, action, cost = node
		node = nextXY, action, cost, parentXY
		storage.push(node)
	nextXY, action, cost, parentXY = storage.pop()
	starts.append(parentXY)
	actions.append(action)
	stops.append(nextXY)
	visited.append(nextXY)
	
	
	while not problem.isGoalState(nextXY):
		parentXY = nextXY # get the parent for these nodes
		tmpHold = problem.getSuccessors(nextXY)
		for node in tmpHold:
			nextXY, action, cost = node
			node = nextXY, action, cost, parentXY
			storage.push(node)
		nextXY, action, cost, parentXY = storage.pop()
		
		notVisited = 1 #this node has not been visited yet
		for node in visited: #ensure the node is unvisited
			if( nextXY == node):
				notVisited = 0 #it has been visited, we need a different node
		
		if notVisited == 0: #find next valid node
			while notVisited == 0:
				nextXY, action, cost, parentXY = storage.pop() #get next node in storage
				notVisited = 1
				for node in visited:
					if( nextXY == node):
						notVisited = 0
					
		
		#print (parentXY, action, nextXY, cost)
		starts.append(parentXY)
		actions.append(action)
		stops.append(nextXY)
		visited.append(nextXY)
	
	#back track to find path from solution to origin
	node = nextXY
	while node != (0, 0):
		for x in range(0, len(starts)):
			if stops[x] == node:
				node = starts[x]
				move = actions[x]
				if move != 'None':
					direc.insert(0, move)
	
	return direc

	#---------------------------------------------------------------------------------------
	#---------------------------------------------------------------------------------------
	#---------------------------------------------------------------------------------------
	
def breadthFirstSearch(problem):
	"""Search the shallowest nodes in the search tree first."""
	"*** YOUR CODE HERE ***"
	#initialize directions available
	from game import Directions
	n = Directions.NORTH
	s = Directions.SOUTH
	w = Directions.WEST
	e = Directions.EAST
	
	direc = []
	visited = []
	parentX = 0
	parentY = 0
	starts = []
	actions = []
	stops = []
	transfer = util.Queue()
	storage = util.Queue()
	
	tmpHold = [] #this holds successors before processing
	completeNode = [] #this is a node w/ fields & additonal parent field
	parentHold = []
	starts.append((0,0)) #parent of start is out of bounds
	actions.append("None") #no path to this parent
	stops.append(problem.getStartState()) #ends at the origin of pacman
	parentXY = problem.getStartState()
	visited.append(problem.getStartState())
	tmpHold = problem.getSuccessors(problem.getStartState())
	for node in tmpHold:
		transfer.push(node) #get the node temporarily
		nextXY, action, cost = transfer.pop() #pop it
		completeNode = nextXY, action, cost, parentXY #create a new node w/ the parent field
		storage.push(completeNode) #push it into long term storage w/ its parent node
	nextXY, action, cost, parentXY = storage.pop()
	starts.append(parentXY)
	actions.append(action)
	stops.append(nextXY)
	visited.append(nextXY)
	
	
	while not problem.isGoalState(nextXY):
		parentXY = nextXY # get the parent for these nodes
		tmpHold = problem.getSuccessors(nextXY)
		for node in tmpHold:
			transfer.push(node)
			nextXY, action, cost = transfer.pop()
			completeNode = nextXY, action, cost, parentXY #push all successors found w/ their parent (even if it is a visited node)
			storage.push(completeNode)
		nextXY, action, cost, parentXY = storage.pop()
		
		notVisited = 1 #this node has not been visited yet
		for node in visited: #ensure the node is unvisited
			if( nextXY == node):
				notVisited = 0 #it has been visited, we need a different node
		
		if notVisited == 0: #find next valid node
			while notVisited == 0:
				nextXY, action, cost, parentXY = storage.pop() #get next node in storage
				notVisited = 1
				for node in visited:
					if( nextXY == node):
						notVisited = 0
					
		
		#print (parentXY, action, nextXY, cost)
		starts.append(parentXY)
		actions.append(action)
		stops.append(nextXY)
		visited.append(nextXY)
	
	#back track to find path from solution to origin
	startNode = nextXY
	node = nextXY
	direc = []
	while node != (0, 0):
		for x in range(0, len(starts)):
			if stops[x] == node:
				node = starts[x]
				move = actions[x]
				if move != 'None':
					direc.insert(0, move)
	
	return direc

	#---------------------------------------------------------------------------------------
	#---------------------------------------------------------------------------------------
	#---------------------------------------------------------------------------------------
	
def uniformCostSearch(problem):
	"""Search the node of least total cost first."""
	"*** YOUR CODE HERE ***"
	from game import Directions
	n = Directions.NORTH
	s = Directions.SOUTH
	w = Directions.WEST
	e = Directions.EAST
	
	direc = []
	visited = []
	starts = []
	tmpActions = []
	stops = []
	storage = util.PriorityQueue()
	parentXY = (0,0)
	gN = 0
	
	starts.append(parentXY) #parent of start is out of bounds
	tmpActions.append("None") #no path to this parent
	stops.append(problem.getStartState()) #ends at the origin of pacman
	tmpHold = []
	tmpHold = problem.getSuccessors(problem.getStartState())
	for node in tmpHold:
		nextXY, action, cost = node
		cost += gN
		node = nextXY, action, cost, parentXY
		storage.push(node, cost)
	visited.append(problem.getStartState()) #append node to list of visited locations
	nextXY, action, cost, parentXY = storage.pop()
	starts.append(parentXY)
	tmpActions.append(action)
	stops.append(nextXY)
	visited.append(nextXY)
	
	while not problem.isGoalState(nextXY):
		parentXY = nextXY # get the parent for these nodes
		gN = cost
		tmpHold = problem.getSuccessors(nextXY)
		for node in tmpHold:
			nextXY, action, cost = node
			cost += gN
			node = nextXY, action, cost, parentXY
			storage.push(node, cost)
		nextXY, action, cost, parentXY = storage.pop()
		
		notVisited = 1 #this node has not been visited yet
		for node in visited: #ensure the node is unvisited
			if( nextXY == node):
				notVisited = 0 #it has been visited, we need a different node
		
		if notVisited == 0: #find next valid node
			while notVisited == 0:
				nextXY, action, cost, parentXY = storage.pop() #get next node in storage
				notVisited = 1
				for node in visited:
					if( nextXY == node):
						notVisited = 0
			
		
		starts.append(parentXY)
		tmpActions.append(action)
		stops.append(nextXY)
		visited.append(nextXY)
	
	#back track to find path from solution to origin
	startNode = nextXY
	node = nextXY
	direc = []
	while node != (0, 0):
		for x in range(0, len(starts)):
			if stops[x] == node:
				node = starts[x]
				move = tmpActions[x]
				if move != 'None':
					direc.insert(0, move)
		
	return direc

	#---------------------------------------------------------------------------------------
	#---------------------------------------------------------------------------------------
	#---------------------------------------------------------------------------------------
	
def nullHeuristic(state, problem=None):
	"""
	A heuristic function estimates the cost from the current state to the nearest
	goal in the provided SearchProblem.  This heuristic is trivial.
	"""
	return 0

	#---------------------------------------------------------------------------------------
	#---------------------------------------------------------------------------------------
	#---------------------------------------------------------------------------------------
	
def aStarSearch(problem, heuristic=nullHeuristic):
	"""Search the node that has the lowest combined cost and heuristic first."""
	"*** YOUR CODE HERE ***"
	import searchAgents
	from game import Directions
	n = Directions.NORTH
	s = Directions.SOUTH
	w = Directions.WEST
	e = Directions.EAST
	
	direc = []
	visited = []
	starts = []
	tmpActions = []
	stops = []
	storage = util.PriorityQueue()
	parentXY = (0,0)
	gN = 0
	
	starts.append(parentXY) #parent of start is out of bounds
	tmpActions.append("None") #no path to this parent
	stops.append(problem.getStartState()) #ends at the origin of pacman
	tmpHold = []
	tmpHold = problem.getSuccessors(problem.getStartState())
	for node in tmpHold:
		nextXY, action, cost = node
		cost += gN
		node = nextXY, action, cost, parentXY
		cost += heuristic(nextXY, problem)
		storage.push(node, cost)
	visited.append(problem.getStartState()) #append node to list of visited locations
	nextXY, action, cost, parentXY = storage.pop()
	starts.append(parentXY)
	tmpActions.append(action)
	stops.append(nextXY)
	visited.append(nextXY)
	
	while not problem.isGoalState(nextXY):
		parentXY = nextXY # get the parent for these nodes
		gN = cost
		tmpHold = problem.getSuccessors(nextXY)
		for node in tmpHold:
			nextXY, action, cost = node
			cost += gN
			node = nextXY, action, cost, parentXY
			cost += heuristic(nextXY, problem)
			storage.push(node, cost)
		nextXY, action, cost, parentXY = storage.pop()
		
		notVisited = 1 #this node has not been visited yet
		for node in visited: #ensure the node is unvisited
			if( nextXY == node):
				notVisited = 0 #it has been visited, we need a different node
		
		if notVisited == 0: #find next valid node
			while notVisited == 0:
				nextXY, action, cost, parentXY = storage.pop() #get next node in storage
				notVisited = 1
				for node in visited:
					if( nextXY == node):
						notVisited = 0
			
		
		starts.append(parentXY)
		tmpActions.append(action)
		stops.append(nextXY)
		visited.append(nextXY)
	
	#back track to find path from solution to origin
	startNode = nextXY
	node = nextXY
	direc = []
	while node != (0, 0):
		for x in range(0, len(starts)):
			if stops[x] == node:
				node = starts[x]
				move = tmpActions[x]
				if move != 'None':
					direc.insert(0, move)
		
		
	return direc


# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
