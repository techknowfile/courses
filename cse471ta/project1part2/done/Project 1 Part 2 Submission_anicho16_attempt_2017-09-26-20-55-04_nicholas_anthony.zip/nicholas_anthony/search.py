# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util
from game import Directions

class searchNode():
       
    """
    searchNode store information needed for search (ie to allow path to be found once goal is popped off stack).  I have followed Berkeley lectures 
    which suggest that nodes are conceptually paths, but better to represent with a state, cost, last action, and reference to the parent node   
    """

    def __init__(self, state, lastAction, parent, cost, heuristic=0):
        self.state = state
        self.cost = cost
        self.parent = parent
        self.lastAction = lastAction
        self.heuristic = heuristic

    def getPath(self):
        path = list()
        curr = self
        while curr.lastAction != None:
            path.append(curr.lastAction)
            curr = curr.parent
        path.reverse()
        return path
    
    def printPath(self):
        path = list()
        curr = self
        while curr.lastAction != None:
            path.append(curr)
            curr = curr.parent
        path.reverse()
        i = 0
        for node in path:
            costPlusH = node.cost + node.heuristic
            print("Node {} state: {}, cost: {}, heuristic: {}, costPlusH: {}".format(i, node.state, node.cost, node.heuristic, costPlusH))
            i += 1
        return


class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    
    s = Directions.SOUTH
    w = Directions.WEST
    print "Start:", problem.getStartState()
    print "Start's successors:", problem.getSuccessors(problem.getStartState())
    
    return  [s, s, w, s, w, w, s, w]

def depthFirstSearch(problem):
    """
    Search the deepest nodes in the search tree first.  
    @param problem: a search problem (eg tinyMaze etc) 
    @returns: a list of actions that reaches the goal. These are in form returned by getSuccessor function.

    """
    stack = util.Stack() #stores nodes on fringe of search in LIFO order
    discovered = set() #created list of discovered states

    #begin depth first search
    startNode = searchNode(problem.getStartState(), None, None, 1) #place first node on the stack 
    stack.push(startNode)
    currentNode = startNode

    #continue DFS until we reach the goal state and pop it off the stack.
    while not problem.isGoalState(currentNode.state):     

        discovered.add(currentNode.state)
        
        #add undiscovered successors to the stack
        for successor in problem.getSuccessors(currentNode.state): 
            if not successor[0] in discovered: 
                successorNode = searchNode(successor[0], successor[1], currentNode, 1)
                stack.push(successorNode)  
        
        currentNode = stack.pop()   #pop the next node off the stack
    
    return currentNode.getPath()

def breadthFirstSearch(problem):
    """Search the shallowest nodes in the search tree first.
    @param problem: a search problem (eg tinyMaze etc)  
    @returns: a list of actions that reaches the goal. These are in form returned by getSuccessor function.
    """

    queue = util.Queue() #stores nodes on fringe of search in FIFO order
    discovered = set()    

    #begin breadth first search
    startNode = searchNode(problem.getStartState(), None, None, 1) #place first node on the stack 
    discovered.add(startNode.state)
    currentNode = startNode
    
    # import pdb; pdb.set_trace()

    #continue BFS until we reach the goal state and pop it off the queue.
    while not problem.isGoalState(currentNode.state):    
        
        #add undiscovered successors to the queue
        # state = successor[0], direction (as a string) = successor[1] and cost = successor[2]
        for successor in problem.getSuccessors(currentNode.state):
            if not successor[0] in discovered: 
                successorNode = searchNode(successor[0], successor[1], currentNode, 1)
                queue.push(successorNode)
                discovered.add(successorNode.state)
        
        currentNode = queue.pop()   #pop the next node off the queue
        #print(currentNode.state)        


    return currentNode.getPath()


def uniformCostSearch(problem):
    """Search the node of least total cost first.
    @param problem: a search problem (eg tinyMaze etc)     
    @returns: a list of actions that reaches the goal. These are in form returned by getSuccessor function.
    """

    print("starting UCS")

    pQueue = util.PriorityQueue() #stores nodes on fringe of search and pop according to priority
    discovered = dict()
    startNode = searchNode(problem.getStartState(), None, None, 1.0)  
    discovered[startNode.state] = startNode  #keep a dict of discovered nodes   

    #begin uniform cost search
    currentNode = startNode

    #continue UCS until we reach the goal state and pop it off the queue.
    while not problem.isGoalState(currentNode.state):   
        #add successors to the queue; 
        # state = successor[0], direction (as a string) = successor[1] and cost = successor[2]
        for successor in problem.getSuccessors(currentNode.state):
            newCost = successor[2] + currentNode.cost
            newDirection = successor[1]
            newState = successor[0]
            successorNode = searchNode(newState, newDirection, currentNode, newCost)

            #if a cheaper path has already been found, disregard
            if (newState in discovered) and (discovered[newState].cost <= newCost):
                continue
            #otherwise, update discovered dict and priority Queue
            else:
                discovered[newState] = successorNode
                pQueue.update(newState, newCost)
        
        currentState = pQueue.pop()   #pop the next node off the queue
        currentNode = discovered[currentState]

    return currentNode.getPath()


def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first.
    @param problem: a search problem (eg tinyMaze etc)     
    @returns: a list of actions that reaches the goal. These are in form returned by getSuccessor function.
    """

    pQueue = util.PriorityQueue() #stores nodes on fringe of search and pop according to priority
    discovered = dict()
    startNode = searchNode(problem.getStartState(), None, None, 0.0)  
    discovered[startNode.state] = startNode  #keep a dict of discovered nodes   

    #begin a*search search
    currentNode = startNode

    #continue a*search until we reach the goal state and pop it off the queue.
    while not problem.isGoalState(currentNode.state):   
        # add successors to the queue; 
        # state = successor[0], direction (as a string) = successor[1] and cost = successor[2]
        for successor in problem.getSuccessors(currentNode.state):
            newCost = successor[2] + currentNode.cost
            newDirection = successor[1]
            newState = successor[0]
            newXyPosition = successor[0][0]
            hValue = heuristic(newState, problem)
            successorNode = searchNode(newState, newDirection, currentNode, newCost, hValue)

            #if a cheaper path has already been found, disregard
            if (newState in discovered) and (discovered[newState].cost <= newCost):
                continue
            #otherwise, update discovered dict and priority Queue
            else:
                discovered[newState] = successorNode
                pQueue.update(newState, newCost + heuristic(newState, problem))
        
        currentState = pQueue.pop()   #pop the next node off the queue
        currentNode = discovered[currentState]

    currentNode.printPath()

    return currentNode.getPath()


# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
