# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

def depthFirstSearch(problem):
    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches the
    goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:
    """

    #print "Start:", problem.getStartState()
    #print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    #print "Start's successors:", problem.getSuccessors(problem.getStartState())

    # initialize open list as LIFO stack for DFS
    # open stores all the nodes available to be expanded
    open = util.Stack()

    # Stack contains nodes which are pairs composed of
    #   state (ex: 'A', 'B', 'C', etc.)
    #   an array representing the path to the node's state (ex: ['A -> B', 'B -> C'])

    open.push((problem.getStartState(), []))

    # initialize closed list of nodes that have already been expanded
    closed = []

    # run this loop until the Stack is empty
    while not open.isEmpty():
        # pop a node from the Stack and set variables for its state and path
        node = open.pop()
        # yeah I don't have to make these their own variables but it's easier for when I study this code
        state = node[0]
        path = node[1]

        # if we're at a goal state then return the path
        if problem.isGoalState(state):
            return path

        # ONLY EXPAND NODES THAT HAVEN'T ALREADY BEEN EXPANDED
        if state not in closed:
            # expand the state so you can access its successors
            for child in problem.getSuccessors(state):
                # construct a path to the child
                childpath = []
                for step in path:
                    childpath.append(step)
                childpath.append(child[1])
                open.push((child[0], childpath))

            # now that the state has been expanded, add it to closed list
        closed.append(state)

    # if exited loop without returning a solution, then you failed and return nothing
    return []

def breadthFirstSearch(problem):
    # initialize open list as FIFO queue for BFS
    # open stores all the nodes available to be expanded
    open = util.Queue()

    # Queue contains nodes which are pairs composed of
    #   state (ex: 'A', 'B', 'C', etc.)
    #   an array representing the path to the node's state (ex: ['A -> B', 'B -> C'])

    open.push((problem.getStartState(), []))

    # initialize closed list of nodes that have already been expanded
    closed = []

    # run this loop until the Queue is empty
    while not open.isEmpty():
        # pop a node from the Queue and set variables for its state and path
        node = open.pop()
        # yeah I don't have to make these their own variables but it's easier for when I study this code
        state = node[0]

        path = node[1]

        # if we're at a goal state then return the path
        if problem.isGoalState(state):
            return path

        # ONLY EXPAND NODES THAT HAVEN'T ALREADY BEEN EXPANDED
        if state not in closed:
            #print "expanding state: ", state
            # expand the state so you can access its successors
            for child in problem.getSuccessors(state):
                #print "    ", child
                # construct a path to the child and add push it onto the Queue
                childpath = []
                for step in path:
                    childpath.append(step)
                childpath.append(child[1])
                open.push((child[0], childpath))

        # now that the state has been expanded, add it to closed list
        closed.append(state)

    # if exited loop without returning a solution, then you failed and return nothing
    print "failed"
    return []

def uniformCostSearch(problem):
    """Search the node of least total cost first."""
    # initialize open list as FIFO PriorityQueue for UCS
    # Priority determined by problem.getCostOfActions(path to state)
    # open stores all the nodes available to be expanded
    open = util.PriorityQueue()

    # PriorityQueue contains nodes which are pairs composed of
    #   state (ex: 'A', 'B', 'C', etc.)
    #   an array representing the path to the node's state (ex: ['A -> B', 'B -> C'])

    open.push((problem.getStartState(), []), 0)

    # initialize closed list of nodes that have already been expanded
    closed = []

    # run this loop until the PriorityQueue is empty
    while not open.isEmpty():
        # pop a node from the PriorityQueue and set variables for its state and path
        node = open.pop()
        # yeah I don't have to make these their own variables but it's easier for when I study this code
        state = node[0]
        path = node[1]

        # if we're at a goal state then return the path
        if problem.isGoalState(state):
            return path

        # ONLY EXPAND NODES THAT HAVEN'T ALREADY BEEN EXPANDED
        if state not in closed:
            # expand the state so you can access its successors
            for child in problem.getSuccessors(state):
                # construct a path to the child and add push it onto the Queue
                childpath = []
                for step in path:
                    childpath.append(step)
                childpath.append(child[1])
                # here we see the benefit of making my own nodes than using their triplets, I can access the path as one unit easier
                open.push((child[0], childpath), problem.getCostOfActions(childpath))

        # now that the state has been expanded, add it to closed list
        closed.append(state)

    # if exited loop without returning a solution, then you failed and return nothing
    return []


def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    # initialize open list as FIFO PriorityQueue for A* Search
    # Priority determined by problem.getCostOfActions(path to state) + heuristic(state, problem)
    # heuristic estimates the remaining path to go
    # open stores all the nodes available to be expanded
    open = util.PriorityQueue()

    # PriorityQueue contains nodes which are pairs composed of
    #   state (ex: 'A', 'B', 'C', etc.)
    #   an array representing the path to the node's state (ex: ['A -> B', 'B -> C'])

    open.push((problem.getStartState(), []), 0 + heuristic(problem.getStartState(), problem))

    # initialize closed list of nodes that have already been expanded
    closed = []

    # run this loop until the PriorityQueue is empty
    while not open.isEmpty():
        # pop a node from the PriorityQueue and set variables for its state and path
        node = open.pop()
        # yeah I don't have to make these their own variables but it's easier for when I study this code
        state = node[0]
        path = node[1]

        # if we're at a goal state then return the path
        if problem.isGoalState(state):
            return path

        # ONLY EXPAND NODES THAT HAVEN'T ALREADY BEEN EXPANDED
        if state not in closed:
            # expand the state so you can access its successors
            for child in problem.getSuccessors(state):
                # construct a path to the child and add push it onto the Queue
                childpath = []
                # probably don't have to do this through a for loop, but again this is easier to study
                for step in path:
                    childpath.append(step)
                childpath.append(child[1])
                # here we see the benefit of making my own nodes than using their triplets, I can access the path as one unit easier
                open.push((child[0], childpath), problem.getCostOfActions(childpath) + heuristic(child[0], problem))
                #open.push((child[0], childpath), problem.getCostOfActions(childpath))

        # now that the state has been expanded, add it to closed list
        closed.append(state)

    # if exited loop without returning a solution, then you failed and return nothing
    return []


# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
