# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()

def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

def depthFirstSearch(problem):

    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches the
    goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:

    print "Start:", problem.getStartState()
    print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    print "Start's successors:", problem.getSuccessors(problem.getStartState())
    """
    "*** YOUR CODE HERE ***"
    ''' ## 1st method
    print "Start:", problem.getStartState()
    print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    print "Start's successors:", problem.getSuccessors(problem.getStartState())
    pathAct = []
    glFnd = False

    st = util.Stack()
    l = problem.getStartState()
    print 'l', l
    visited = set()
    path = []
    add = [l, path]
    visited.add(l)
    st.push(add)
    i = 0
    while (not (st.isEmpty()) and not (glFnd)):
        StrtState = st.pop()
        # print 'in while',StrtState
        SucesState = problem.getSuccessors(StrtState[0])
        for state in SucesState:
            # print state[0],'--',state[1],'##',StrtState[1]
            if state[0] not in visited:
                path = []
                path = StrtState[1]

                path.append(state[1])
                pckg = [state[0], path]
                st.push(pckg)
                visited.add(state[0])
        glFnd = problem.isGoalState(StrtState[0])
        # print glFnd

        # print '############'
    print path
    ret = list(traverse(path))
    # print ret
    # return ret
    '''
    # I have made two stack one store path one to store node
    st = util.Stack()
    pathSt=util.Stack()
    l = problem.getStartState()
    visited = set()
    path = []
    #pushed empty path and first node
    pathSt.push(path)
    st.push(l)
    ## BOTH STACK ARE WORKING TOGETHER AND SHARING SAME NODE INFORMATION AT THE SAME INDEX
    while not st.isEmpty():
        #pop the state that we want to expand
        node = st.pop()
        # pop the path stack if not empty
        if not pathSt.isEmpty():
            path=pathSt.pop()
        # if the node we want to expand is goal node then no need to expand
        # and return path calculated till now
        if problem.isGoalState(node):
            return path
        # we dont want to traverse the node which we already visited otherwise we will go into
        #infinite loop
        if node not in visited:
            #we add this node to visited set
            visited.add(node)
            # get the successors of the current expanding state
            SucesState = problem.getSuccessors(node)
            #loop in one by one into all the successors
            for state,dir,cst in SucesState:
                #add the path to the node into path stack
                newpath = path+[dir]
                pathSt.push(newpath)
                #add successor node to node stack
                st.push(state)
    "util.raiseNotDefined()"

def traverse(o, tree_types=(list, tuple)):
    if isinstance(o, tree_types):
        for value in o:
            for subvalue in traverse(value, tree_types):
                yield subvalue
    else:
        yield o

def  helper(problem,state,li,i):
    ## DFS backtracking solution
     if(i>200):return False
     i+=1
     if(problem.isGoalState(state)):
         return True;
     node=problem.getSuccessors(state)
     for stat in node:
        if(helper(problem,stat[0],li,i)):
            li+=stat[1]
            return True
        else:
            return False

def printStack(st):
    while(not st.isEmpty()):
        print st.pop()

def breadthFirstSearch(problem):
    """Search the shallowest nodes in the search tree first."""
    "*** YOUR CODE HERE ***"
    # this same method except we are using only one queue to store path and node
    st = util.Queue()
    l = problem.getStartState()
    visited = set()
    path = []
    add = (l, path)
    st.push(add)
    while not st.isEmpty():
        (node, path) = st.pop()
        # print 'in while',StrtState
        if problem.isGoalState(node):
            return path
        if node not in visited:
            visited.add(node)
            SucesState = problem.getSuccessors(node)
            for state, dir, cst in SucesState:
                newpath = path + [dir]
                pckg = (state, newpath)
                st.push(pckg)
    util.raiseNotDefined()

def uniformCostSearch(problem):
    """Search the node of least total cost first."""
    "*** YOUR CODE HERE ***"
    # this same method except we are using only one priority queue to store path and node
    # the priority is equal to the cost of reaching a node
    st = util.PriorityQueue()
    l = problem.getStartState()
    visited = set()
    path = []
    add = (l, path,0)
    st.push(add,0)
    while not st.isEmpty():
        (node, path,cost) = st.pop()
        # print 'in while',StrtState
        if problem.isGoalState(node):
            return path
        if node not in visited:
            visited.add(node)
            SucesState = problem.getSuccessors(node)
            for state, dir, cst in SucesState:
                newcst=cst+cost
                newpath = path + [dir]
                pckg = (state, newpath,newcst)
                st.push(pckg,newcst)

    util.raiseNotDefined()

def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""
    "*** YOUR CODE HERE ***"
    # this same method except we are using only one priority queue to store path and node
    # the priority is equal to the heuristic function
    st = util.PriorityQueue()
    l = problem.getStartState()
    visited = set()
    path = []
    add = (l, path,0)
    st.push(add,heuristic(l,problem))
    while not st.isEmpty():
        (node, path,cost) = st.pop()
        # print 'in while',StrtState
        if problem.isGoalState(node):
            return path
        if node not in visited:
            visited.add(node)
            SucesState = problem.getSuccessors(node)
            for state, dir, cst in SucesState:
                newcst=cst+cost
                newpath = path + [dir]
                pckg = (state, newpath,newcst)
                newcst=newcst+heuristic(state,problem)
                st.push(pckg,newcst)


# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
