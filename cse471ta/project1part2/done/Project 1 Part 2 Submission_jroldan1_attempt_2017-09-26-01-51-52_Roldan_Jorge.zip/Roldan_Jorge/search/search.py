# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

""" Jorge Roldan 
    ID: 1207193334
"""

import util

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

def depthFirstSearch(problem):
    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches the
    goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:

    """

    # print "Start:", problem.getStartState()
    # print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    # print "Start's successors:", problem.getSuccessors(problem.getStartState())
    
    "*** YOUR CODE HERE ***"
    # Make stack to keep track of graph
    path = util.Stack()

    # Initialize the graph with the start position, and empty lists for the actions and visited nodes
    path.push((problem.getStartState(), [], []))

    # While there's still somewhere to go, the solution has not been found
    while path:
        # Update graph
        (state, actions, marked) = path.pop();
        # Check if goal reached
        if problem.isGoalState(state):
            return map
        # Otherwise, analyze successors for path decisions
        for leaf, direction, none in problem.getSuccessors(state):
            # Assure we have not already visited this node
            if not leaf in marked:
                # Update the new node, the latest directions, and the visited nodes to pass onto the graph
                updatedDirections = actions + [direction]
                updatedFollowing = marked + [state] 
                path.push((leaf, updatedDirections, updatedFollowing))
                # Update list of actions that we will return once the goal is reached
                map = updatedDirections
    return []



    util.raiseNotDefined()

def breadthFirstSearch(problem):
    """Search the shallowest nodes in the search tree first."""
    "*** YOUR CODE HERE ***"
    # Make expanded nodes list to ensure we expand breadth first
    found = []
    # Make queue to keep track of graph
    path = util.Queue()

    # Initialize the graph with the start position, and empty lists for the actions and visited ndes
    path.push((problem.getStartState(), [], []))

    # While there's still somewhere to go, the solution has not been found
    while path:
        # Update graph
        (state, actions, marked) = path.pop();
        # Assure we have not already visited this node
        if not state in found:
            found.append(state)

            # Check if goal reached
            if problem.isGoalState(state):
                return actions

            # Otherwise, analyze successors for path decisions
            for leaf, direction, none in problem.getSuccessors(state):
                # Update to the new node, the latest movement, and the visited nodes list then push onto graph
                updatedDirections = actions + [direction]
                path.push((leaf, updatedDirections, none))
    return []


    util.raiseNotDefined()

def uniformCostSearch(problem):
    """Search the node of least total cost first."""
    "*** YOUR CODE HERE ***"

    # Make list to ensure we expand correclty, like used in BFS above
    found = []
    # Make priority queue to keep track of graph
    path = util.PriorityQueue()

    # Initialize the graph with the start position, plus an added parameter for the cost value
    path.push((problem.getStartState(), [], 0), 0)

    # While there's still somewhere to go, solution isn't found
    while path:
        # Update path
        (state, actions, marked) = path.pop();
        # Assure we have not already visited this node
        if not state in found:
            found.append(state)

            # Check if goal reached
            if problem.isGoalState(state):
                return actions

            # Otherwise, analyze successors for path decisions
            for leaf, direction, weight in problem.getSuccessors(state):
                # Update to the new node, the latest movement, and the visited nodes list then update graph
                updatedDirections = actions + [direction]
                updatedFollowing = marked + weight
                path.push((leaf, updatedDirections, updatedFollowing), updatedFollowing)
    return []

    util.raiseNotDefined()

def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""
    "*** YOUR CODE HERE ***"

    # Make list to ensure we expand correclty, like used in UCS above
    found = []
    # Make priority queue to keep track of graph
    path = util.PriorityQueue()

    # Initialize the graph with the start position, with an added parameter for the heuristics
    path.push((problem.getStartState(), [], 0), heuristic(problem.getStartState(), problem))

    # While there's still somewhere to go, solution is not found
    while path:
        # Update path
        (state, actions, marked) = path.pop();
        # Assure we have not already visited this node
        if not state in found:
            found.append(state)

            # Check if goal reached
            if problem.isGoalState(state):
                return actions

            # Otherwise, analyze successors for path decisions
            for leaf, direction, weight in problem.getSuccessors(state):
                # Update to the new node, the latest movement, and the visited nodes list then update graph
                updatedDirections = actions + [direction]
                updatedFollowing = marked + weight
                path.push((leaf, updatedDirections, updatedFollowing), updatedFollowing + heuristic(leaf, problem))
    return []

    util.raiseNotDefined()


# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
