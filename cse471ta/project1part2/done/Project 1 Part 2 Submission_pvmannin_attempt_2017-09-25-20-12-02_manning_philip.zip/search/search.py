# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

def depthFirstSearch(problem):
    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches the
    goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:

    print "Start:", problem.getStartState()
    print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    print "Start's successors:", problem.getSuccessors(problem.getStartState())
    """
    "*** YOUR CODE HERE ***"
    DFSstack = util.Stack()
#   Will add to list tuple (state, actions, visited list)

    # Philip Manning
    #CSE 471 project 1
#   Initialize all variables
    StartState = problem.getStartState()
    movementList = []
    visitedList = []
    SolutionList = []

#   Put the start element into the stack and variables to alter throughout the search
    DFSstack.push((StartState, movementList, visitedList))
    solutionfound = False
    while(not DFSstack.isEmpty() and not solutionfound):
        currentState,movementList,visitedList = DFSstack.pop()
#       This will conclude that we found our goal
        if(problem.isGoalState(currentState)):
            solutionfound = True
            SolutionList = movementList
        #only executes openning of successors if the solution still needs to be sought
        if (not solutionfound):
            # gets successors
            SuccessorList = problem.getSuccessors(currentState)
            for i in range((len(SuccessorList)-1), -1, -1):
                if(visitedList.count(SuccessorList[i][0]) < 1 and not solutionfound):
                    #stores new successors in correct order from left to right
                    newmovementList = movementList + [SuccessorList[i][1]]
                    newvisitedList = visitedList + [currentState]
                    DFSstack.push((SuccessorList[i][0], newmovementList, newvisitedList))
    return SolutionList
    util.raiseNotDefined()

def breadthFirstSearch(problem):
    """Search the shallowest nodes in the search tree first."""
    "*** YOUR CODE HERE ***"
    # Philip Manning
    #initialization
    BFSqueue = util.Queue()
    StartState = problem.getStartState()
    movementList = []
    visitedList = []
    visitedList2 = []
    visitedList3 = []
    visitedList4 = []
    visitedList5 = []
    visitedList6 = []
    visitedList7 = []
    visitedList8 = []
    visitedList9 = []
    visitedList10 = []
    visitedList11 = []
    visitedList12 = []
    visitedList13 = []
    used1 = False
    used2 = False
    used3 = False
    used4 = False
    used5 = False
    used6 = False
    used7 = False
    used8 = False
    privateList = []
    SolutionList = []
    solutionfound = False
    multipleCorners = []

    #every seen node needs to be added to the visited list to avoid multiple expantions
    if isinstance(StartState[0], tuple):
        visitedList = visitedList + [StartState[0]]
    else:
        visitedList = visitedList + [StartState]
    found = 0
    newfound = 0

    BFSqueue.push((StartState, movementList, found))
    while(not BFSqueue.isEmpty() and not solutionfound):
        #gets where you are and where you've been
        currentState,movementList,found = BFSqueue.pop()
        #concludes that we found the goal node but doesnt expand it
        if(problem.isGoalState(currentState)):
            solutionfound = True
            SolutionList = movementList
            #Honestly I had to check multiple pathways to make sure the multiple lists didnt intersect because that was giving me an error so this is my workaround,  it ends up being superoptimal 
        if (not solutionfound):
            #gets the successors
            SuccessorList = problem.getSuccessors(currentState)
            if isinstance(StartState[0], tuple):
                for i in range(0, len(SuccessorList)):
                    if(found == 0):
                        if (visitedList.count(SuccessorList[i][0][0]) < 1 and not solutionfound):
                            if len(SuccessorList[i][0][1]) == (len(currentState[1])):
                                newmovementList = movementList + [SuccessorList[i][1]]
                                visitedList = visitedList + [SuccessorList[i][0][0]]
                                BFSqueue.push((SuccessorList[i][0], newmovementList,found))
                            elif len(SuccessorList[i][0][1]) > len(currentState[1]):
                                visitedList = visitedList + [SuccessorList[i][0][0]]
                                newmovementList = movementList + [SuccessorList[i][1]]
                                newfound = newfound + 1
                                BFSqueue.push((SuccessorList[i][0], newmovementList,newfound))
                                if(newfound == 1):
                                    visitedList2.append(SuccessorList[i][0][0])
                                elif(newfound == 2):
                                    visitedList3.append(SuccessorList[i][0][0])
                                elif(newfound == 3):
                                    visitedList4.append(SuccessorList[i][0][0])
                                elif(newfound == 4):
                                    visitedList5.append(SuccessorList[i][0][0])
                    elif(found == 1):
                        if (visitedList2.count(SuccessorList[i][0][0]) < 1 and not solutionfound and used1 == False):
                            newmovementList = movementList + [SuccessorList[i][1]]
                            visitedList2 = visitedList2 + [SuccessorList[i][0][0]]
                            if len(SuccessorList[i][0][1]) > len(currentState[1]) and used1 == False:
                                visitedList6 = []
                                used1 = True
                                visitedList6.append(SuccessorList[i][0][0])
                                refound = 5
                                BFSqueue.push((SuccessorList[i][0],newmovementList,refound))
                            else:
                                BFSqueue.push((SuccessorList[i][0],newmovementList,found))
                    elif(found == 2):
                        if (visitedList3.count(SuccessorList[i][0][0]) < 1 and not solutionfound) and used2 == False:
                            newmovementList = movementList + [SuccessorList[i][1]]
                            visitedList3 = visitedList3 + [SuccessorList[i][0][0]]
                            if len(SuccessorList[i][0][1]) > len(currentState[1]) and used2 == False:
                                visitedList7 = []
                                used2 = True
                                visitedList7.append(SuccessorList[i][0][0])
                                refound = 6
                                BFSqueue.push((SuccessorList[i][0],newmovementList,refound))
                            else:
                                BFSqueue.push((SuccessorList[i][0],newmovementList,found))
                    elif(found == 3):
                        if (visitedList4.count(SuccessorList[i][0][0]) < 1 and not solutionfound) and used3 == False:
                            newmovementList = movementList + [SuccessorList[i][1]]
                            visitedList4 = visitedList4 + [SuccessorList[i][0][0]]
                            if len(SuccessorList[i][0][1]) > len(currentState[1]) and used3 == False:
                                visitedList8 = []
                                used3 = True
                                visitedList8.append(SuccessorList[i][0][0])
                                refound = 7
                                BFSqueue.push((SuccessorList[i][0], newmovementList,refound))
                            else:
                                BFSqueue.push((SuccessorList[i][0],newmovementList,found))
                    elif(found == 4):
                        if (visitedList5.count(SuccessorList[i][0][0]) < 1 and not solutionfound) and used4 == False:
                            newmovementList = movementList + [SuccessorList[i][1]]
                            visitedList5 = visitedList5 + [SuccessorList[i][0][0]]
                            if len(SuccessorList[i][0][1]) > len(currentState[1]) and used4 == False:
                                visitedList9 = []
                                used4 = True
                                visitedList9.append(SuccessorList[i][0][0])
                                refound = 8
                                BFSqueue.push((SuccessorList[i][0],newmovementList,refound))
                            else:
                                BFSqueue.push((SuccessorList[i][0],newmovementList,found))
                    elif (found == 5):
                        if (visitedList6.count(SuccessorList[i][0][0]) < 1 and not solutionfound) and used5 == False:
                            newmovementList = movementList + [SuccessorList[i][1]]
                            visitedList6 = visitedList6 + [SuccessorList[i][0][0]]
                            if len(SuccessorList[i][0][1]) > len(currentState[1]) and used5 == False:
                                visitedList10 = []
                                visitedList10.append(SuccessorList[i][0][0])
                                used5 = True
                                refound = 9
                                BFSqueue.push((SuccessorList[i][0], newmovementList, refound))
                            else:
                                BFSqueue.push((SuccessorList[i][0],newmovementList,found))
                    elif (found == 6):
                        if (visitedList7.count(SuccessorList[i][0][0]) < 1 and not solutionfound) and used6 == False:
                            newmovementList = movementList + [SuccessorList[i][1]]
                            visitedList7 = visitedList7 + [SuccessorList[i][0][0]]
                            if len(SuccessorList[i][0][1]) > len(currentState[1]) and used6 == False:
                                visitedList11 = []
                                used6 = True
                                visitedList11.append(SuccessorList[i][0][0])
                                refound = 10
                                BFSqueue.push((SuccessorList[i][0], newmovementList, refound))
                            else:
                                BFSqueue.push((SuccessorList[i][0],newmovementList,found))
                    elif (found == 7):
                        if (visitedList8.count(SuccessorList[i][0][0]) < 1 and not solutionfound) and used7 == False:
                            newmovementList = movementList + [SuccessorList[i][1]]
                            visitedList8 = visitedList8 + [SuccessorList[i][0][0]]
                            if len(SuccessorList[i][0][1]) > len(currentState[1]) and used7 == False:
                                visitedList12 = []
                                used7 = True
                                visitedList12.append(SuccessorList[i][0][0])
                                refound = 11
                                BFSqueue.push((SuccessorList[i][0], newmovementList, refound))
                            else:
                                BFSqueue.push((SuccessorList[i][0],newmovementList,found))
                    elif (found == 8):
                        if (visitedList9.count(SuccessorList[i][0][0]) < 1 and not solutionfound) and used8 == False:
                            newmovementList = movementList + [SuccessorList[i][1]]
                            visitedList9 = visitedList9 + [SuccessorList[i][0][0]]
                            if len(SuccessorList[i][0][1]) > len(currentState[1]) and used8 == False:
                                visitedList13 = []
                                used8 = True
                                visitedList13.append(SuccessorList[i][0][0])
                                refound = 12
                                BFSqueue.push((SuccessorList[i][0], newmovementList, refound))
                            else:
                                BFSqueue.push((SuccessorList[i][0],newmovementList,found))
                    elif (found == 9):
                        if (visitedList10.count(SuccessorList[i][0][0]) < 1 and not solutionfound):
                            newmovementList = movementList + [SuccessorList[i][1]]
                            visitedList10 = visitedList10 + [SuccessorList[i][0][0]]
                            BFSqueue.push((SuccessorList[i][0],newmovementList,found))
                    elif (found == 10):
                        if (visitedList11.count(SuccessorList[i][0][0]) < 1 and not solutionfound):
                            newmovementList = movementList + [SuccessorList[i][1]]
                            visitedList11 = visitedList11 + [SuccessorList[i][0][0]]
                            BFSqueue.push((SuccessorList[i][0],newmovementList,found))
                    elif (found == 11):
                        if (visitedList12.count(SuccessorList[i][0][0]) < 1 and not solutionfound):
                            newmovementList = movementList + [SuccessorList[i][1]]
                            visitedList12 = visitedList12 + [SuccessorList[i][0][0]]
                            BFSqueue.push((SuccessorList[i][0],newmovementList,found))
                    elif (found == 12):
                        if (visitedList13.count(SuccessorList[i][0][0]) < 1 and not solutionfound):
                            newmovementList = movementList + [SuccessorList[i][1]]
                            visitedList13 = visitedList13 + [SuccessorList[i][0][0]]
                            BFSqueue.push((SuccessorList[i][0],newmovementList,found))
            else:
                for i in range(0, len(SuccessorList)):
                    #adds all unfound successors to the queue and gives each their own stored path
                    if(visitedList.count(SuccessorList[i][0]) < 1 and not solutionfound):
                        newmovementList = movementList + [SuccessorList[i][1]]
                        visitedList = visitedList + [SuccessorList[i][0]]
                        BFSqueue.push((SuccessorList[i][0], newmovementList, found))
    return SolutionList
    util.raiseNotDefined()

def uniformCostSearch(problem):
    """Search the node of least total cost first."""
    "*** YOUR CODE HERE ***"
    # Philip Manning
    #initialization
    UCPriorityQueue = util.PriorityQueue()
    StartState = problem.getStartState()
    movementList = []
    visitedList = []
    SolutionList = []
    solutionfound = False
    #works like BFS but with a cost attribute to each element in the queue
    visitedList = visitedList + [StartState]

    UCPriorityQueue.push((StartState,movementList),0)
    while(not UCPriorityQueue.isEmpty() and not solutionfound):
        #exactly as BFS algorithm above but we add the cost as each priority in the priority queue so the shortest cost path is found to the goal
        currentState,movementList = UCPriorityQueue.pop()
        #goal state is found but not expanded
        if(problem.isGoalState(currentState)):
            solutionfound = True
            SolutionList = movementList
        if (not solutionfound):
            #successors are expanded
            SuccessorList = problem.getSuccessors(currentState)
            for i in range(0, len(SuccessorList)):
                if(visitedList.count(SuccessorList[i][0]) < 1 and not solutionfound):
                    newmovementList = movementList + [SuccessorList[i][1]]
                    movementcost = problem.getCostOfActions(newmovementList)
                    #this does not expand the goal state in visited in case we find a shorter cost or something like that
                    if(not problem.isGoalState(SuccessorList[i][0])):
                        visitedList = visitedList + [SuccessorList[i][0]]
                    UCPriorityQueue.push((SuccessorList[i][0],newmovementList),movementcost)
    return SolutionList


    util.raiseNotDefined()

def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""
    "*** YOUR CODE HERE ***"
    #Philip Manning
    #initialization of the queue and start state and such
    AstarQueue = util.PriorityQueue()
    StartState = problem.getStartState()
    movementList = []
    visitedList = []
    SolutionList = []
    solutionfound = False
    #each element has a heuristic to add to its current cost for the f(n) function
    AstarQueue.push((StartState,movementList),heuristic(StartState,problem))
    while(not AstarQueue.isEmpty() and not solutionfound):
        currentState,movementList = AstarQueue.pop()
        #solution is found and returned
        if(problem.isGoalState(currentState)):
            solutionfound = True
            SolutionList = movementList
    #we expand successors if no solution is found
        if not currentState in visitedList:
            visitedList.append(currentState)
        if(not solutionfound):
            SuccessorList = problem.getSuccessors(currentState)
            for i in range(0, len(SuccessorList)):
            #if we havent seen a node we should add it to our priority queue
                if(len(SuccessorList[i]) == 2):
                    SuccessorList[i] = [SuccessorList[i]]
                if(visitedList.count(SuccessorList[i][0]) < 1 and not solutionfound):
                    newmovementList = movementList + [SuccessorList[i][1]]
                    movementcost = problem.getCostOfActions(newmovementList) + heuristic(SuccessorList[i][0],problem)
                    if(not problem.isGoalState(SuccessorList[i][0])):
                    #this prevents adding the goal before finding the shortest path and not allowing it to be added to the correct path
                        visitedList = visitedList + [SuccessorList[i][0]]
                #This adds the element and its movement list of actions and its cost is f(n) = g(n) + h(n) both are given and calculated
                    AstarQueue.push((SuccessorList[i][0], newmovementList), movementcost)
    return SolutionList

    util.raiseNotDefined()


# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
