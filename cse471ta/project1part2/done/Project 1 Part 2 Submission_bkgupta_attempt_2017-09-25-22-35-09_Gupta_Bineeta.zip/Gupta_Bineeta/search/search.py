# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

def depthFirstSearch(problem):
    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches the
    goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:

    print "Start:", problem.getStartState()
    print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    print "Start's successors:", problem.getSuccessors(problem.getStartState())

    Strategy: 
    DFS traverses a graph in a depthward motion and uses a stack to remember to get the next vertex to 
    start a search, when a dead end occurs.

    Rules:
    1. Take a root: mark it as visited. 
    2. Visit the adjacent vertex; mark it as visited; push in the stack
    3. If no adjacent vertex is ofund; pop from stack; mark it as visited
    4. repeat rule 2 and 3 untill the stack is empty  
    
    REFERENCES: 
    https://medium.com/@lennyboyatzis/ 
    https://www.tutorialspoint.com/data_structures_algorithms/depth_first_traversal.htm"""
    
    # find the shallowest node in the search tree
    from game import Directions
    
    #initialization
    start_state = problem.getStartState()
    if problem.isGoalState(start_state): return []
    
    #declare variables
    visited_nodes= {} #visited nodes track
    states = [] # list of nodes to be explored
    states_iter = []
    state_neighbours = {}
    actions_take = []  # for reconstructing the path  
    
    visited_nodes[start_state] = True #make the visited node as TRUE
    states.append(start_state) #put the start_state for exploration
    states_iter.append(0)
    state_neighbours[start_state] = problem.getSuccessors(start_state) #get state, direction and cost to reach child nodes
    
    while len(states) > 0: #if there are nodes in stack
        state = states[-1] #get a state node
        neignbours = state_neighbours[state] #get properties
        neighbour_visited = False        
        for z in range(states_iter[-1], len(neignbours)):
            neighbour = neignbours[z]
            states_iter[-1] = states_iter[-1] + 1
            if visited_nodes.has_key(neighbour[0]): continue #if node is already visited, then go to loop
            visited_nodes[neighbour[0]] = True #if not, make the node visited
            states.append(neighbour[0])#add the node to be explored
            states_iter.append(0)
            actions_take.append(neighbour[1]) #keep track of direction
            if problem.isGoalState(neighbour[0]): return actions_take #Done!
            state_neighbours[neighbour[0]] = problem.getSuccessors(neighbour[0])
            neighbour_visited = True #make the visited node True
            break
        
        if neighbour_visited == False:
            states.pop()
            states_iter.pop()
            if len(actions_take) > 0: actions_take.pop() # if 'state' is the start state then actions is empty
    
    return actions_take

def breadthFirstSearch(problem):
    """Search the shallowest nodes in the search tree first."""
    """
    Strategy:
    It is similar to Djikstra's algorithm to find the shortest path, with every edge of same length 
    Consider it as directed graph. BFS requirement is:
    Given state S, and you need to reach state V
    1. V should be reachable from S and V should not be equal to S, length to visit V is length(V)
    2.  If there's any node U, between S and V, such that length(U) < length(V) from S, then U must be 
    visited prior V
    3. Using queue of the vertices

    REFERENCES: 
    https://pythoninwonderland.wordpress.com/2017/03/18/how-to-implement-breadth-first-search-in-python/
    """

    #import directions
    from game import Directions    

    visited_node = {} #keep track of visited node
    previous_node = {} #keep track of previous node for backtracking

    #returns the start state of the search problem
    start_state = problem.getStartState()  
    states = util.Queue() #calling queue class from util.py
    
    visited_node[start_state] = True #make the start_node as visited and include in the dict: visited_node
    states.push(start_state) #push the visited node in the queue

    while not states.isEmpty():
        queued_state = states.pop() #pop the visited node from the queue
        #if the state of the node in queue is goal, i.e just one node in graph
        if (problem.isGoalState(queued_state)): break
        #if not the goal state, get the child nodes of the queued node
        successor_nodes = problem.getSuccessors(queued_state) #get the next node, action to reach and cost involved to reach
        for successor_node in successor_nodes:
            if visited_node.has_key(successor_node[0]): continue #the node is already visited, exit loop 
            visited_node[successor_node[0]] = True #if not, make the node visit TRUE
            states.push(successor_node[0]) #push it into the queue (util.py)
            previous_node[successor_node[0]] = (queued_state,successor_node[1]) #track of prior node, i.e parent and the direction
    
    action_reverse_track = [] #for reconstructing the path
    current_node = queued_state
    while current_node != start_state: 
        action_reverse_track.append(previous_node[current_node][1]) #track a node to its parent node and the direction
        current_node = previous_node[current_node][0] #back tracking
    
    #return the re-constructed path from goal to the start
    return action_reverse_track[::-1]

def uniformCostSearch(problem):
    """Search the node of least total cost first."""
    
    """UCS is like A* with null Heuristic.
    Its mentioned in Berkeley AI page to try to re-use the functions to make it generic.
    """
    return aStarSearch(problem, nullHeuristic)

def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""

    """
    Strategy:
    Astar Search performs: at each step it picks the node according to a value-f which is a parameter equal to the sum of two other parameters, g and h. 
    At each step it picks the node having the lowest f, and process that node.
    We define g and h as simply as possible below.
    g = movement cost to move from the start to a given node following the path generated to get there.
    h = estimated movement cost to move from the node to goal. Referred as Heuristic. 
    f = g + h
  
    1. Intialize the search tree
    2. Loop DO:
        if there are no candidate for expansion, return failure
        choose leaf node for expansion accordingly "Strategy"
        if the node ocntains the goal state then return corresponding solution
        else
        expand the node and the resulting nodes to the search tree
   
    REFERENCES: 
        1. https://en.wikipedia.org/wiki/A*_search_algorithm
        2. http://www.geeksforgeeks.org/a-search-algorithm/ """

    ##import directions
    from game import Directions
      
    previous_state = {} #keep track
    visited_nodes = {}
    minimum_gscore = {} #minimum cost function to that state from the start
    minimum_state_goal = (0, 0)    
    minimum_gscore_goal = None
    states = util.PriorityQueue() #using util.py here

    #get start state
    start_state = problem.getStartState()
    
    #cost of going from start to start is 0
    minimum_gscore[start_state] = 0
    states.push(start_state, 0)
    
    while not states.isEmpty():
        queued_state = states.pop() #pop the state for computation
        queued_state_g = minimum_gscore[queued_state] # get the g value of that node
        if visited_nodes.has_key(queued_state): continue #if the node is visited already, continue
        visited_nodes[queued_state] = True #otherwise make it TRUE
        if problem.isGoalState(queued_state): #updation for minimum gScore
            if minimum_gscore_goal == None or queued_state_g < minimum_gscore_goal:
                minimum_gscore_goal =queued_state_g
                minimum_state_goal = queued_state
            break  # assumption: only single goal
        
        neighbours = problem.getSuccessors(queued_state) #get sucessors of the queued state: state, direction and cost of 1
        
        for neighbour in neighbours:
            neighbour_g = queued_state_g + neighbour[2] #the distance from start to the neighbour 
            neighbour_h = heuristic(neighbour[0], problem) #get the heuristic value
            #if neighbour_g >= minimum_gscore[neighbour[0]]: continue, as this is not the better path 
            
            if minimum_gscore.has_key(neighbour[0]) == False or neighbour_g < minimum_gscore[neighbour[0]]: 
                minimum_gscore[neighbour[0]] = neighbour_g
                states.push(neighbour[0], neighbour_g + neighbour_h) #if the node not in queue, push it then
                previous_state[neighbour[0]] = (queued_state, neighbour[1]) #parent of the node and which direction to take from parent to reach the node
    
    action_reverse_track = []
    state = minimum_state_goal #back track from the reached goal to get the path
    while state != start_state:
        action_reverse_track.append(previous_state[state][1])
        state = previous_state[state][0]
    
    #reconstructed path
    return action_reverse_track[::-1]


# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
