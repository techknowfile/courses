# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

def depthFirstSearch(problem):
    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches the
    goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:
    """

    """

    print "Start:", problem.getStartState()
    print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    print "Start's successors:", problem.getSuccessors(problem.getStartState())
    """"""
    """
    "*** YOUR CODE HERE ***"

    # stack: contains nodes to explore
    #stack = util.Stack()
    stack = []

    # adding placeholders for direction and distance for first iteration
    firstNode = ( problem.getStartState(), 'start', 0 )
    stack.append(firstNode)

    # visited: contains visited node coordinates and directions
    visited = []

    # backwardsPath to map child nodes to parents
    backwardsPath = dict()

    while stack:
        # store vertex from stack
        vertex = stack.pop()

        # check if at goal state
        if problem.isGoalState(vertex[0]):
            list = []   # used to store path
            list.append(vertex) # push in goal node

            # while there are still parent nodes left
            while vertex:
                # stores parent node in list, sets traversal node to 
                # be parent for next iteration
                if problem.getStartState() != backwardsPath[vertex][0]:
                    parent = backwardsPath[vertex]
                    list.append(parent)
                    vertex = backwardsPath[vertex]
                else:
                    break # reached start node

            # returnList used to filter out anything but directions
            returnList = []
            for directions in list:
                returnList.append(directions[1])

            # actualReturnList used to hold correct order of directions
            actualReturnList = []
            for directions in reversed(returnList):
                actualReturnList.append(directions)

            # return directions
            return actualReturnList

        if vertex not in visited:   # check for coordinates to not already be visited
            visited.append((vertex[0], vertex[1]))  # add visited node to list of visited
            successors = problem.getSuccessors(vertex[0])   # stored successors for easier debugging
            
            # each node in the frontier
            for node in successors:
                if node[0] not in [v[0] for v in visited]:  # making sure that coordinates not already in visited
                    stack.append(node)  # discovered, add to stack to be visited
                    backwardsPath[node] = vertex   # create key value pair for child to parent
                    

def breadthFirstSearch(problem):
    """Search the shallowest nodes in the search tree first."""
    "*** YOUR CODE HERE ***"

    set = []
    queue = util.Queue()
    
    # backwardsPath to map child nodes to parents
    backwardsPath = dict()

    startState = (problem.getStartState(), ['start'], 0)
    set.append(startState[0])
    queue.push(startState)


    # re-wrote bfs to not make use of dictionary to chain back up to start state from goal
    # for corners problem

    # while queue is not empty
    while len(queue.list) > 0:
        vertex = queue.pop()    # pop into vertex
        if problem.isGoalState(vertex[0]):  # check if goal state
            vertex[1].remove('start')   # remove junk placeholder value from directions
            return vertex[1]    # directions are contained in index 1 of vertex tuple

        successors = problem.getSuccessors(vertex[0])   # store result of get successors into successors var
        for node in successors: # for each successor:
            coordinates, directions, cost = node    # split tuple into accessors
            appendedActions = vertex[1] + [directions]  # build actions list
            if coordinates not in set:  # check that coordinates have not already been visited
                set.append(coordinates) # add to the set of visited nodes
                queue.push((coordinates, appendedActions))  # push coordinates into queue of (coordinate, action) tuples


def uniformCostSearch(problem):
    """Search the node of least total cost first."""
    "*** YOUR CODE HERE ***" 

    # had to re-write to not use dictionary to trace path back up
    # which would break functionality for four corners search

    explored = []

    startState = (problem.getStartState(), [], 0)
    frontier = util.PriorityQueue()

    frontier.push(startState, startState[2])

    while len(frontier.heap) > 0:
        # pop into node, based on priority
        node = frontier.pop()

        if node[0] not in explored:

            # add to explored
            explored.append(node[0])

            if problem.isGoalState(node[0]):

                # return directions
                return node[1]

            # populate successors for iteration
            successors = problem.getSuccessors(node[0])

            # iterate through successors
            for successor in successors:

                coordinates, action, cost = successor    # split tuple into accessors

                appendedActions = node[1] + [action]  # build actions list

                # calculation for cost
                tempCost = problem.getCostOfActions(appendedActions)    # don't add heurisitc, ucs
                newNode = (coordinates, appendedActions)
                frontier.push(newNode, tempCost)

    return list()
            

def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""
    "*** YOUR CODE HERE ***"
    
    """Search the node of least total cost first."""
    "*** YOUR CODE HERE ***"

    # had to re-write to not use dictionary to trace path back up
    # which would break functionality for four corners search

    explored = []

    startState = (problem.getStartState(), [], 0)
    frontier = util.PriorityQueue()

    frontier.push(startState, startState[2])

    while len(frontier.heap) > 0:
        # pop into node, based on priority
        node = frontier.pop()

        if node[0] not in explored:

            # add to explored
            explored.append(node[0])

            if problem.isGoalState(node[0]):

                # return directions
                return node[1]

            # populate successors for iteration
            successors = problem.getSuccessors(node[0])

            # iterate through successors
            for successor in successors:

                coordinates, action, cost = successor    # split tuple into accessors

                appendedActions = node[1] + [action]  # build actions list

                # calculation for cost
                tempCost = problem.getCostOfActions(appendedActions) + heuristic(coordinates, problem)  # a lot like UCS but with heuristic added
                newNode = (coordinates, appendedActions)
                frontier.push(newNode, tempCost)

    return list()
        

# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
