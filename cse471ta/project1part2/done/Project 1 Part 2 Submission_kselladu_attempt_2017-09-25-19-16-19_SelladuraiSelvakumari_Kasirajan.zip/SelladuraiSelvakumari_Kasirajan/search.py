# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
#
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

def depthFirstSearch(problem):
    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches the
    goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:

    print "Start:", problem.getStartState()
    print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    print "Start's successors:", problem.getSuccessors(problem.getStartState())


    -   For DFS, stack from the util class has been used to traverse
    -   For each node all its adjacent elements is added to the stack and the last nodes pop first
        and it goes on to add its adjacent element to the stack
    -   The result for of this functions has to return a list of actions that took place during the 
        search for which a path dictionary data structure is used
    -   When the goal state is reached the path dictionary in iterated and the action list is constructed


    """
    "*** YOUR CODE HERE ***"
    #print "Start:", problem.getStartState()
    # print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    # print "Start's successors:", problem.getSuccessors(problem.getStartState())
    stack = util.Stack()
    stack.push(problem.getStartState())
    visited = {}
    path = {}
    count = 0
    while not stack.isEmpty():
        s = stack.pop()
        # print s
        if s in visited:
            continue
        else:
            visited[s] = True
            if problem.isGoalState(s):
                node = path[s]
                result = []
                while node is not None:
                    parent = node[0]
                    action = node[1]
                    result.insert(0, action)
                    if parent not in path:
                        break
                    else:
                        node = path[parent]
                return result

            successor = problem.getSuccessors(s)
            for suc in successor:
                if suc[0] not in visited:
                    path[suc[0]] = (s, suc[1])
                    # print path
                stack.push(suc[0])
    return []
    #util.raiseNotDefined()

def breadthFirstSearch(problem):
    """Search the shallowest nodes in the search tree first.
        
    -   For BFS, the queue from the util class is used
    -   Since queue is used the first adjacent node added will be poped first and then the next
        adjacent node
    -   As similar to DFS a path dictinary is used to store the state actions and the value is updated
        only when the parent cost + child cost is less than the existing value. Since BFS will choose the
        optimal value this is necessary
    -   Atlast the path dictionary is iterated to get the actions
    """
    "*** YOUR CODE HERE ***"
    # print "Start:", problem.getStartState()
    # print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    # print "Start's successors:", problem.getSuccessors(problem.getStartState())
    queue=util.Queue()
    queue.push(problem.getStartState())
    visited= {}
    path= {}
    count=0
    while not queue.isEmpty():
        s=queue.pop()
        #print s
        if s not in visited:
            visited[s]=True
            if problem.isGoalState(s):
                node = path[s]
                result=[]
                while node is not None:
                    parent = node[0]
                    action = node[1]
                    result.insert(0,action)
                    if parent not in path:
                        break
                    else:
                        node=path[parent]
                return result
            successor=problem.getSuccessors(s)
            for suc in successor:
                if suc[0] not in visited:
                    if suc[0] not in path:
                        if s in path:
                            parent = path[s]
                            path[suc[0]] = (s, suc[1], parent[2] + suc[2])
                        else:
                            path[suc[0]] = (s, suc[1], suc[2])
                    else:
                        parent = path[s]
                        current = path[suc[0]]
                        if parent[2] + suc[2] < current[2]:
                            path[suc[0]] = (s, suc[1], parent[2] + suc[2])
                    #print path
                queue.push(suc[0])
    return []
    #util.raiseNotDefined()




def uniformCostSearch(problem):
    """Search the node of least total cost first.

       -    Uniform cost search uses priority queue from util instead of queues in BFS
       -    The priority value is nothing but the total cost till that particular node. This
            was during dequeue the node that has the minimum path to reach will get dequeued
       -    As similar to BFS the actions are stored in path which is a dictionary data structure.
            This is travered to obtain the actions when the goal is reached

    """
    "*** YOUR CODE HERE ***"
    queue = util.PriorityQueue()
    queue.push((problem.getStartState(),0),0)
    visited = {}
    path = {}
    count = 0
    while not queue.isEmpty():
        q = queue.pop()
        s=q[0]
        #print s[0]
        if s not in visited:
            visited[s] = True
            if problem.isGoalState(s):
                node = path[s]
                result = []
                while node is not None:
                    parent = node[0]
                    action = node[1]
                    result.insert(0, action)
                    if parent not in path:
                        break
                    else:
                        node = path[parent]
                return result

            successor = problem.getSuccessors(s)
            for suc in successor:
                if suc[0] not in visited:
                    if suc[0] not in path:
                        if s in path:
                            parent = path[s]
                            path[suc[0]] = (s, suc[1], parent[2] + suc[2])
                        else:
                            path[suc[0]] = (s, suc[1], suc[2])
                    else:
                        parent = path[s]
                        current = path[suc[0]]
                        if parent[2] + suc[2] < current[2]:
                            path[suc[0]] = (s, suc[1], parent[2] + suc[2])
                queue.push((suc[0],suc[2]+q[1]),q[1]+suc[2])
    return []


def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first.
        
        -   Astar search is very similar to UCS in terms of implementation instead it uses
            the heuristics plus the total cost till that point as priority value for the priority queue
        -   This also uses the path dictionary data structure to store the actions for where the node
            came from and once the goal state is reached it is iterated to form the list


    """
    "*** YOUR CODE HERE ***"
    queue = util.PriorityQueue()
    queue.push((problem.getStartState(), 0), heuristic(problem.getStartState(),problem))
    visited = {}
    path = {}
    count = 0
    while not queue.isEmpty():
        q = queue.pop()
        s = q[0]
        # print s[0]
        if s not in visited:
            visited[s] = True
            if problem.isGoalState(s):
                node = path[s]
                result = []
                while node is not None:
                    parent = node[0]
                    action = node[1]
                    result.insert(0, action)
                    if parent not in path:
                        break
                    else:
                        node = path[parent]
                return result
            successor = problem.getSuccessors(s)
            for suc in successor:
                heuristicValue = heuristic(suc[0], problem)
                if suc[0] not in visited:
                    if suc[0] not in path:
                        if s in path:
                            parent = path[s]
                            path[suc[0]] = (s, suc[1], parent[2] + suc[2])
                        else:
                            path[suc[0]] = (s, suc[1], suc[2])
                    else:
                        parent = path[s]
                        current = path[suc[0]]
                        if parent[2] + suc[2] < current[2]:
                            path[suc[0]] = (s, suc[1], parent[2] + suc[2])
                totalCost=q[1] + suc[2] + heuristicValue

                queue.push((suc[0], suc[2] + q[1]),totalCost )
    return []


# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch

