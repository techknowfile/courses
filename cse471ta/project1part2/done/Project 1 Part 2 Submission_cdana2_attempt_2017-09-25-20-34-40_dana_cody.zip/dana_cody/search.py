# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
#
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

def depthFirstSearch(problem):
    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches the
    goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:

    print "Start:", problem.getStartState()
    print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    print "Start's successors:", problem.getSuccessors(problem.getStartState())
    """

    depthStack = util.Stack()
    diction = dict()
    visited = []
    succs = []
    directions = []
    directHolder = []

    depthStack.push(problem.getStartState())

    startNode = (problem.getStartState(), 'startNode', 0)
    depthStack.push(startNode)

    # while the stack is not empty
    while depthStack.isEmpty() == False:

        # Get the first thing on the stack
        state = depthStack.pop()
        visited.append(state[0])

        # isGoalState only accepts coordinates and returns boolean
        if problem.isGoalState(state[0]):

            # Add the goal state's direction
            directHolder.append(state[1])

            # Then go backwards using its parents
            while state[2] != 0:
                # Store the parents starting from the Goal State
                parentNode = diction[state]
                state = parentNode
                if parentNode[1] != 'startNode':
                    directHolder.append(parentNode[1])

            # Reverse the information into directions structure
            for i in reversed(directHolder):
                directions.append(i)

            return directions

        # The getSuccessors method takes in coordinates as parameters
        # The very first state only has coordinates
        #if problem.isGoalState(state[0]):
        succs = problem.getSuccessors(state[0])

        # For all of the successors for the current state...
        for nodes in succs:

            # add the adjacent nodes that aren't already visited onto the top of stack
            if nodes[0] not in visited:
               depthStack.push(nodes)

               # Add the parent(nodes) of the succs
               diction[nodes] = state

    util.raiseNotDefined()

def breadthFirstSearch(problem):
    """Search the shallowest nodes in the search tree first."""

    queue = util.Queue()
    visited = []
    allActionsTaken = []
    directions = []
    directHolder = []
    diction = dict()
    startState = problem.getStartState()

    vertex = ((allActionsTaken, problem.getStartState()))
    queue.push(vertex)

    # While the queue is not empty
    while queue.isEmpty() != True:

        # Get the first thing in the stack
        actions, state = queue.pop()

        # isGoalState only accepts coordinates and returns boolean
        if state not in visited and problem.isGoalState(state):
                return actions

        if state not in visited:
            visited.append(state)

            # Get the successors of the current state
            succs = problem.getSuccessors(state)

             # For all of the successors for the current state...
            for nodes in succs:
                coord, getDirection, cost = nodes
                newPath = actions + [getDirection]
                queue.push((newPath, coord))

    util.raiseNotDefined()

def uniformCostSearch(problem):
    """Search the node of least total cost first."""

    priQueue = util.PriorityQueue()
    visited = []
    directHolder = []
    directions = []
    diction = dict()
    startNode = (problem.getStartState(), 'startNode', 0)
    priQueue.push(startNode, startNode[2])

    # While the queue is not empty
    while priQueue.isEmpty() != True:

        # Get the first thing in the stack, lowest val
        state = priQueue.pop()
        cost = state[2]

        # isGoalState only accepts coordinates and returns boolean
        if problem.isGoalState(state[0]):

            # Add the goal state's direction
            directHolder.append(state[1])

            # Then go backwards using its parents
            while state[2] != 0:
                # Store the parents starting from the Goal State
                parentNode = diction[state]
                state = parentNode
                if parentNode[1] != 'startNode':
                    directHolder.append(parentNode[1])

            # Reverse the information into directions structure
            for i in reversed(directHolder):
                directions.append(i)

            return directions

        if state[0] not in visited:
            visited.append(state[0])

        # Get the successors of the current state
        succs = problem.getSuccessors(state[0])

        # For all of the successors for the current state...
        for nodes in succs:

            # If the node was visited and is not present in the heap
            if nodes[0] not in visited and nodes[0] not in priQueue.heap:

                visited.append(nodes[0])
                diction[nodes] = state

                # Get the new distance by adding up from next potential successor to the start state
                # then add it to the totalCost and push it in respective to that potential successor
                tempNodes = nodes
                totalCost = tempNodes[2]
                while tempNodes[2] != 0:
                    parentNode = diction[tempNodes]
                    totalCost += parentNode[2]
                    tempNodes = parentNode

                priQueue.push(nodes, totalCost)

            elif nodes[0] in (item[2][0] for item in priQueue.heap):
                visited.append(nodes[0])
                diction[nodes] = state

                # Get the new distance by adding up from next potential successor to the start state
                # then add it to the totalCost and push it in respective to that potential successor
                tempNodes = nodes
                totalCost = tempNodes[2]
                while tempNodes[2] != 0:
                    parentNode = diction[tempNodes]
                    totalCost += parentNode[2]
                    tempNodes = parentNode

                tempQueue = priQueue
                checker = True
                priCost = 0

                for item in priQueue.heap:
                    if item[2][0] == nodes[0]:
                        priCost = item[0]

                if priCost > totalCost:
                   priQueue.update(nodes, totalCost)

    util.raiseNotDefined()

def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""

    priQueue = util.PriorityQueue()
    priFuncQueue = util.PriorityQueueWithFunction(priQueue)
    visited = []
    allActionsTaken = []
    directions = []
    directHolder = []
    diction = dict()
    startState = problem.getStartState()

    vertex = ((allActionsTaken, problem.getStartState()), heuristic(problem.getStartState(), problem))
    priQueue.push((allActionsTaken, problem.getStartState()), heuristic(problem.getStartState(), problem))

    # While the queue is not empty
    while priQueue.isEmpty() != True:

        # Get the first thing in the stack
        actions, state = priQueue.pop()

        # isGoalState only accepts coordinates and returns boolean
        if state not in visited and problem.isGoalState(state):
            return actions

        if state not in visited:
            visited.append(state)

            # Get the successors of the current state
            succs = problem.getSuccessors(state)

            # For all of the successors for the current state...
            for nodes in succs:
                coord, getDirection, cost = nodes
                newPath = actions + [getDirection]
                problemQuestion = problem.getCostOfActions(newPath)
                heuristicVal = heuristic(coord, problem)
                costSum = problemQuestion + heuristicVal
                priQueue.push((newPath, coord), costSum)

    util.raiseNotDefined()


# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
