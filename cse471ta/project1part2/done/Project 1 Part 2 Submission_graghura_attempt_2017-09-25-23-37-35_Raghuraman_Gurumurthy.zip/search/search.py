# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

def depthFirstSearch(problem):
    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches the
    goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:

    print "Start:", problem.getStartState()
    print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    print "Start's successors:", problem.getSuccessors(problem.getStartState())
    """
    "*** YOUR CODE HERE ***"
    from util import Stack 
    #Create set of visited nodes
    visited=set()
    startStack=Stack()
    #Get Startstate and push it into the stack. Store node and path to the node on the stack.
    startState=problem.getStartState()
    startStack.push((startState,[]))
    while not startStack.isEmpty():
	#Retrieve top most state from the stack	
	presentState=startStack.pop()
	if presentState[0] not in visited:
		visited.add(presentState[0])
		#Check whether we have reached goal state. If yes return path to goal state.
		if problem.isGoalState(presentState[0]):
			return presentState[1]
		#Get children of each node If it is not in visited add it to the stack.
		for eachSuccessor in problem.getSuccessors(presentState[0]):
			if eachSuccessor[0] not in visited:
				startStack.push((eachSuccessor[0],presentState[1]+[eachSuccessor[1]]))
    util.raiseNotDefined()

def breadthFirstSearch(problem):
    """Search the shallowest nodes in the search tree first."""
    "*** YOUR CODE HERE ***"
    from util import Queue
    #Create set of visited nodes
    visited=set()
    startQueue=Queue()
    #Get startstate and push it into the queue. Also push path to the node in queue.
    startState=problem.getStartState()
    startQueue.push((startState,[]))
    while not startQueue.isEmpty():
	#Get the first node in queue.
	presentState=startQueue.pop()
	#If not visited then go inside if condition
	if presentState[0] not in visited:
		visited.add(presentState[0])
		#Check whether its goal state. If yes return path to goal state.
		if problem.isGoalState(presentState[0]):
			return presentState[1]
		#Check for each child if it visited, if not add it to queue.		
		for eachSuccessor in problem.getSuccessors(presentState[0]):
			if eachSuccessor[0] not in visited:			
				startQueue.push((eachSuccessor[0],presentState[1]+[eachSuccessor[1]]))		
					
    util.raiseNotDefined()

def uniformCostSearch(problem):
    """Search the node of least total cost first."""
    "*** YOUR CODE HERE ***"
    from util import PriorityQueue
    #Instantiate a priority queue(heap).
    startPQueue=PriorityQueue()
    visited=set()
    #Get the start state, set its priority to 0 and push it onto the priority queue. Also push the path and the priority onto the queue along with the start state. 
    startState=problem.getStartState()
    startPQueue.push((startState,[],0),0)
    while not startPQueue.isEmpty():
	#Retrieve the node with least priority from the priority queue(heap).	
	presentState=startPQueue.pop()
	if presentState[0] not in visited:
		visited.add(presentState[0])	
		#Check whether its goal state. If yes return path(actions to reach goal) to goal state.		
		if problem.isGoalState(presentState[0]):
			return presentState[1]
		#For each child of the node check whether its in visited, if not add it to queue along with its path and the distace(priority).
		for eachSuccessor in problem.getSuccessors(presentState[0]):
			if eachSuccessor[0] not in visited:			
				startPQueue.update((eachSuccessor[0],presentState[1]+[eachSuccessor[1]],presentState[2]+eachSuccessor[2]),presentState[2]+eachSuccessor[2])
    
    util.raiseNotDefined()
    
	

def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""
    "*** YOUR CODE HERE ***"
    from util import PriorityQueue
    startPQueue=PriorityQueue()
    visited=set()
    #Retrieve start state, set its priority equal to the heuristic(approx dist to goal node) and push it onto priority queue. Along with state push path and distance.
    startState=problem.getStartState()
    startPQueue.push((startState,[],0),heuristic(startState,problem))
    while not startPQueue.isEmpty():
	#Retrieve the node with the least approximate distance to the goal node.
	presentState=startPQueue.pop()
	#Check if it is in visited
	if presentState[0] not in visited:
		visited.add(presentState[0])
		#Check if it is goal state, if yes add return path(actions to reach goal).		
		if problem.isGoalState(presentState[0]):
			return presentState[1]
		#For each child not visited push the state,path,distance with priority distance covered till now plus approx distance to reach goal(heuristic). 
		for eachSuccessor in problem.getSuccessors(presentState[0]):
			if eachSuccessor[0] not in visited:
				startPQueue.update((eachSuccessor[0],presentState[1]+[eachSuccessor[1]],presentState[2]+eachSuccessor[2]),presentState[2]+eachSuccessor[2]+heuristic(eachSuccessor[0],problem))
    util.raiseNotDefined()


# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
