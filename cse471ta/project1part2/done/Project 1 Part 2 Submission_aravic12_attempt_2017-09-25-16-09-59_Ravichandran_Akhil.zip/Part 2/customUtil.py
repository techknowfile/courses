import logging,sys

DISABLE_LOGGING = True

class Logger:
    def __init__(self,name):
        self.logger = logging.getLogger(name)
        self.logger.setLevel(logging.DEBUG)
        # self.logger.setLevel(logging.INFO)
        self.console_handler = logging.StreamHandler()
        # self.formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        self.formatter = logging.Formatter('%(levelname)s - %(message)s')
        self.console_handler.setFormatter(self.formatter)
        self.logger.addHandler(self.console_handler)
        if DISABLE_LOGGING:
            self.logger.disabled = True

    def getLogger(self):
        return self.logger

    def enableLogger(self):
        self.logger.disabled = False

    def disableLogger(self):
        self.logger.disabled = True