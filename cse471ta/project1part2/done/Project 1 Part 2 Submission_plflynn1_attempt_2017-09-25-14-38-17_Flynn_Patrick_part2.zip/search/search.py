# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util
import inspect

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

def depthFirstSearch(problem):
    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches the
    goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:

    print "Start:", problem.getStartState()
    print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    print "Start's successors:", problem.getSuccessors(problem.getStartState())
    """
	
    #following pseudocode and utilizing a stack as our DFS method
	

	
	#this is where current string of states will be held
    thePath = util.Stack()
	#to not reiterate, this houses previously traveled states
    expanded = []

	#to solely utilize the while loop, load up the start state to be spat out again
	### see util.py for StateInfo documentation
    currentState = util.StateInfo(problem.getStartState(), None, None, None)
    thePath.push(currentState)
	
	#primary while loop. iterates until goal is found or we run out of states
    while not thePath.isEmpty():
        currentState = thePath.pop()
		#check whether or not (topmost) state is goal.
        if problem.isGoalState(currentState.state):
			#see util.py -> StateInfo for more
            return currentState.PathIt()
		#if not goal, add to traveled states
        expanded.append(currentState.state)
		#push each successor of the current locale into the stack
        for x in problem.getSuccessors(currentState.state):
			#x[0] is the location tuple element. x[1] is the direction taken, Third member is the parent's StateInfo,
			#where member four will eventually be the path cost.
            successor = util.StateInfo(x[0], x[1], currentState, None)
			#only add to stack if it hasnt already been traversed
            if x[0] not in expanded:
                thePath.push(successor)

    return []
    util.raiseNotDefined()

def breadthFirstSearch(problem):
    """Search the shallowest nodes in the search tree first."""
	
	######### SEE DFS FOR MORE INFORMATION ###########
		
	#Swap to queue for BFS functionality
    thePath = util.Queue()

    expanded = []
	
    currentState = util.StateInfo(problem.getStartState(), None, None, None)
    thePath.push(currentState)
    expanded.append(currentState.state)
    while not thePath.isEmpty():
        currentState = thePath.pop()
        if problem.isGoalState(currentState.state):
            return currentState.PathIt()

        for x in problem.getSuccessors(currentState.state):
            successor = util.StateInfo(x[0], x[1], currentState, None)
            if x[0] not in expanded:
                thePath.push(successor)
				#BFS differs from DFS in that, given a manypatths situation, queue insertion would lead to unnecessary reiteration.
				# As such, adding successors to the exapnded list will prevent over adding a state to the "to be explored" list
                expanded.append(x[0])
    return []
    util.raiseNotDefined()

def uniformCostSearch(problem):
    """Search the node of least total cost first."""
    "*** YOUR CODE HERE ***"
	
    """Search the shallowest nodes in the search tree first."""
	
	######### SEE DFS FOR MORE INFORMATION ###########
	
	#swap to PriorityQueue for UCS functionality
    thePath = util.PriorityQueue()
    expanded = []	
	
    currentState = util.StateInfo(problem.getStartState(), None, None, 0)
    thePath.push(currentState, currentState.cost)
    expanded.append(currentState.state)
    while not thePath.isEmpty():
        currentState = thePath.pop()
        if problem.isGoalState(currentState.state):
            return currentState.PathIt()
		#retain DFS "marked as seen" functionality
        expanded.append(currentState.state)
        for x in problem.getSuccessors(currentState.state):
			#Fourth member is now utilized, and will be the sum of the current parent-to-child path cost, and the sum of all previous path costs to the parent
            successor = util.StateInfo(x[0], x[1], currentState, x[2]+currentState.cost)
            if x[0] not in expanded:
                thePath.push(successor, successor.cost)
				#for particular problems, the goal state is reachable by two separate paths, one of which at a lesser cost.
				# As such, we want to keep goal states off of the expanded list so that they may be
				# re-added and reevaluated for potential differences in cost.
                if not problem.isGoalState(successor.state):
                    expanded.append(successor.state)
    return []
    util.raiseNotDefined()

def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""
    thePath = util.PriorityQueue()
    expanded = []	
	
	######### SEE DFS AND UCS FOR MORE INFO ##############
	
    currentState = util.StateInfo(problem.getStartState(), None, None, 0)
    thePath.push(currentState, 0)
    expanded.append(currentState.state)
    while not thePath.isEmpty():
        currentState = thePath.pop()
        #print currentState
        if problem.isGoalState(currentState.state):
            return currentState.PathIt()
        expanded.append(currentState.state)
        for x in problem.getSuccessors(currentState.state):
            #print currentState.state
            successor = util.StateInfo(x[0], x[1], currentState, x[2]+currentState.cost)
            if x[0] not in expanded:
				#the only difference here is that we to give priority to a successor state based not 
				#only on its path cost but also to predicted distance to goal based on a given heuristic.
				#As such, it's priority in queue is decided by the sum of g(n), the path cast, and h(n), the potential
				#cost as per the heuristic, which constitiues f(n)
                thePath.push(successor, successor.cost+heuristic(successor.state, problem))
                if not problem.isGoalState(successor.state):
                    expanded.append(successor.state)

    return []

    util.raiseNotDefined()


# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
