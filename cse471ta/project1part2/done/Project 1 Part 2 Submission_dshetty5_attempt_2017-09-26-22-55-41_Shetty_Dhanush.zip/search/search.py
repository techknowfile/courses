# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    e = Directions.EAST
    #return [w]
    return  [s, s, w, s, w, w, s, w]

def depthFirstSearch(problem):
    from util import Stack
    s = Stack()
    path = []
    startState = problem.getStartState()
    cost = 0
    poppedState = startState
    visited = [startState]               #the visited list is initialised with the start state
                                         # keeps a track of all states that has been pushed on to the stack
    while not problem.isGoalState(poppedState):     #checks whether state that is popped from the stack is the goal state
        successorList = problem.getSuccessors(poppedState)   #creates a successor list for the states popped from the stack
        for successor in successorList:                      #for each successor of the popped state
            if not successor[0] in visited:   #condition to only push the state that has not been popped or visited before
                listToBePushed = [successor[0],path+[successor[1]], (cost + successor[2])]  #creates a list of states, its path and
                                                                                            #its cost combined with the cost
                                                                                            #until it from the start state
                s.push(listToBePushed)
        poppedState, path, cost = s.pop()
        visited.append(poppedState)          #marks the state visited if it has been popped from the list so as to keep track of the states
    return path

def breadthFirstSearch(problem):
    from util import Queue
    q = Queue()
    cost = 0
    path = []
    startState = problem.getStartState()
    #print "start state is" +str(startState)
    visited = [startState]                   #the visited list is initialised with the start state
    dequeuedState = startState
    #print "dequeued state"
    #while pathcount !=4:
    while not problem.isGoalState(dequeuedState):
        #print "is not a goal State" + str(dequeuedState)
        #checks whether state that is popped from the Queue is the goal state
        successorList = problem.getSuccessors(dequeuedState)    #creates a successor list(the list contains state, path and cost) for the states popped from the queue
        for successor in successorList:                         #for each successor of the popped state
            if not successor[0] in visited:                     #condition to only push the state that has not been popped or visited before
                listToBeEnqueued = [successor[0], path+ [successor[1]], (cost + successor[2])]
                q.push(listToBeEnqueued)
                #print "The following list is pushed" + str(listToBeEnqueued)
                visited.append(successor[0])                    #marks the state visited if it has been pushed to the Queue
        dequeuedState, path, cost = q.pop()
        #print "The following is popped" + str(dequeuedState)
    #return problem.goalVisited
    return path
    #pathcount = pathcount+1

def uniformCostSearch(problem):
    #for the uniform cost search the next state is decided on the cost of the path until that state from the starting state
    from util import PriorityQueue
    pq = PriorityQueue()
    cost = flag = 0
    enqueueList = path = []
    startState = problem.getStartState()
    startList = [startState, path, cost]        #creates a list for the starting state, its path and cost(which is 0)
    pq.push(startList,cost)                     #pushing the starting list onto the priority queue, the cost acts as the priority with which the
                                                #content of the queue has to be popped
    visited=[(startState,cost)]                 #the visited list is initialised with the start state with priority 0
    while not pq.isEmpty():
        dequeuedState,path,cost = pq.pop()      #the priority queue is dequeued(based on the cost). First time the start state is popped
        if problem.isGoalState(dequeuedState):  #checks whether state that is popped from the Queue is the goal state
            return path
        successorList = problem.getSuccessors(dequeuedState)   #creates a successor list(the list contains state, path and cost)
                                                               # for the states popped from the priority queue
        for successor in successorList:                        #for each successor of the popped state
            for visitedState, visitedCost in visited:
                flag = 0
                enqueueList = [successor[0], path + [successor[1]], cost + successor[2]]
                if successor[0] == visitedState and cost + successor[2] >= visitedCost:     #checks if the current successor state has been previosuly pushed to the queue(which is tracked
                                                                                            #by the visited list) and if the the new cost of that state is
                                                                                            #not less than its previous cost
                    flag = 1
                    break
            if not flag:                                                        #if less than the earlier cost of the same state then
                pq.update(enqueueList,enqueueList[2])                           #the cost for that state updated in the priority queue which acts as the priority
                                                                                #with which the next state is popped
            visited.append((enqueueList[0],cost+successor[2]))

def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    #for the astar search the next state is decided based on the combiantion of the cost of the path until that state from the starting state and its heuristic
    """Search the node that has the lowest combined cost and heuristic first."""
    from util import PriorityQueue
    pq = PriorityQueue()
    cost = flag = 0
    enqueueList = path = []
    startState = problem.getStartState()
    startList = [startState, path, (cost)]    #creates a list for the starting state, its path and cost(which is 0)
    pq.push(startList, (cost+heuristic(startState,problem)))                #pushing the starting list onto the priority queue, the cost acts
                                                                            #as the priority with which the content of the queue has to be popped
    visited = [(startState, cost)]                                          #the visited list is initialised with the start state with priority 0
    while not pq.isEmpty():
        dequeuedState, path, cost = pq.pop()                                #the priority queue is dequeued(based on the cost). First time the start state is popped
        if problem.isGoalState(dequeuedState):                              #checks whether state that is popped from the priority Queue is the goal state
            return path
        successorList = problem.getSuccessors(dequeuedState)
        for successor in successorList:
            for visitedState, visitedCost in visited:
                flag = 0
                enqueueList = [successor[0], path + [successor[1]], (cost + successor[2] )]
                if successor[0] == visitedState and (cost + successor[2]) >= visitedCost:   #checks if the current successor state has been previosuly pushed to
                                                                                            #the queue(which is tracked by the visited list) and
                                                                                            #if the the new cost of that state is not less than its previous cost
                    flag = 1
                    break
            if not flag:                                                                    #if less than the earlier cost of the same state then
                pq.update(enqueueList, enqueueList[2]+ heuristic(successor[0],problem))     #update the queue with the new cost by also taking the
                                                                                            #heurisitcs into consideration which acts as the priority with which the
                                                                                            #next state is popped
            visited.append((enqueueList[0], (cost + successor[2])))

# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
