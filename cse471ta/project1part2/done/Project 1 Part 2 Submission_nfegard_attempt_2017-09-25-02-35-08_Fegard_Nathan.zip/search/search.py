# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

# The node structure used in the DFS implementation
class dfsNode:
    def __init__(self, state, action, parentNode):
        self.parentNode = parentNode
        self.state = state
        self.action = action

    def getPathList(self):
        path = []
        current_node = self
        while current_node.action != None:
            path = [current_node.action] + path
            current_node = current_node.parentNode
        return path

def depthFirstSearch(problem):

    # check if the start state is the goal state
    if problem.isGoalState(problem.getStartState()):
        return []

    dfs_stack = util.Stack()
    visited = set()
    startNode = dfsNode(problem.getStartState(), None, None)
    # add the start node to the stack and visited set
    dfs_stack.push(startNode)
    visited.add(startNode.state)

    while not dfs_stack.isEmpty():
        # continue down the branch of the graph
        current_node = dfs_stack.pop()

        if problem.isGoalState(current_node.state):
            # we found the goal state 
            return current_node.getPathList()
        visited.add(current_node.state)
        successors = problem.getSuccessors(current_node.state)

        for successor in successors:
            state = successor[0]
            if state not in visited:
                # every valid successor is added to the stack
                direction = successor[1]
                new_node = dfsNode(state, direction, current_node)
                dfs_stack.push(new_node)
        
    return []

# node class used for breadth first search
class bfsNode:
    def __init__(self, state, action, parentNode):
        self.parentNode = parentNode
        self.state = state
        self.action = action

    def getPathList(self):
        path = []
        current_node = self
        while current_node.action != None:
            path = [current_node.action] + path
            current_node = current_node.parentNode
        return path

def breadthFirstSearch(problem):
    """Search the shallowest nodes in the search tree first."""

    # check if the start state is the goal state
    if problem.isGoalState(problem.getStartState()):
        return []

    bfs_queue = util.Queue()
    visited = set()
    startNode = bfsNode(problem.getStartState(), None, None)
    bfs_queue.push(startNode)
    visited.add(startNode.state)

    while not bfs_queue.isEmpty():
        current_node = bfs_queue.pop()

        if problem.isGoalState(current_node.state):
            # we found the goal state 
            return current_node.getPathList()
        
        successors = problem.getSuccessors(current_node.state)

        for successor in reversed(successors):
            state = successor[0]
            if state not in visited:
                # every valid state is created as a node and added to the queue
                direction = successor[1]
                new_node = bfsNode(state, direction, current_node)
                bfs_queue.push(new_node)
                # states reached are added to the visited set to avoid circular behavior 
                visited.add(new_node.state)
    
    return []

# the node used for uniform cost search
class ucsNode:
    def __init__(self, state, action, pathValue, parentNode):
        self.parentNode = parentNode
        self.state = state
        self.action = action
        self.pathValue = pathValue # value for storing the path cost
        if parentNode != None:
            self.pathValue = parentNode.pathValue + self.pathValue

    def getPathList(self):
        path = []
        current_node = self
        while current_node.action != None:
            path = [current_node.action] + path
            current_node = current_node.parentNode
        return path

def uniformCostSearch(problem):
    """Search the node of least total cost first."""
    "*** YOUR CODE HERE ***"
    # check if start state is the goal state
    if problem.isGoalState(problem.getStartState()):
        return []

    # use a priority queue to arrange the queue from low to high cost
    ucs_queue = util.PriorityQueue()
    visited = set()
    startNode = ucsNode(problem.getStartState(), None, 0, None)
    ucs_queue.push(startNode, 0)
    visited.add(startNode.state)

    while not ucs_queue.isEmpty():
        current_node = ucs_queue.pop()

        if problem.isGoalState(current_node.state):
            # we found the goal state 
            return current_node.getPathList()
        
        successors = problem.getSuccessors(current_node.state)

        for successor in reversed(successors):
            state = successor[0]
            if state not in visited:
                direction = successor[1]
                pathValue = successor[2]
                # create a new node with a path value. the path value is the cost of the entire path.
                new_node = ucsNode(state, direction, pathValue, current_node)
                ucs_queue.push(new_node, new_node.pathValue)
                # because cost is being computed, the first path is not necessarily the "cheapest"
                if not problem.isGoalState(state):
                    visited.add(new_node.state)
    
    return []

def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""
    "*** YOUR CODE HERE ***"
    # check if start state is the goal state
    if problem.isGoalState(problem.getStartState()):
        return []

    # use a priority queue to arrange the queue from low to high cost including variation from a given heuristic
    a_queue = util.PriorityQueue()
    visited = set()
    startNode = ucsNode(problem.getStartState(), None, 0, None)
    a_queue.push(startNode, 0)
    visited.add(startNode.state)

    while not a_queue.isEmpty():
        current_node = a_queue.pop()

        if problem.isGoalState(current_node.state):
            # we found the goal state 
            return current_node.getPathList()
        
        successors = problem.getSuccessors(current_node.state)

        for successor in reversed(successors):
            state = successor[0]
            if state not in visited:
                direction = successor[1]
                pathValue = successor[2]
                pathAdjustment = heuristic(state, problem)
                # construct a new node 
                new_node = ucsNode(state, direction, pathValue, current_node) # a UCS node is used since cost is important
                a_queue.update(new_node, new_node.pathValue + pathAdjustment)
                # because cost is being computed including a heuristic, the first path is not necessarily the "cheapest"
                if not problem.isGoalState(state):
                    visited.add(new_node.state)
    
    return []

# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
