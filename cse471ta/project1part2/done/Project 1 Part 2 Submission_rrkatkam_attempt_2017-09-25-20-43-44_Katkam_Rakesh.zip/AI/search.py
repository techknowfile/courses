# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

def depthFirstSearch(problem):
    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches the
    goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:
    """
    fringe = util.Stack()
    #return if problem state is the goal state
    if problem.isGoalState(problem.getStartState()):
        return[]

    #push successors of the start state into the stack
    for successor in problem.getSuccessors(problem.getStartState()):
            fringe.push((successor[0], successor[1], successor[2], problem.getStartState()))

    """
    :explored holds state as a key and (action, cost, parent) as the value
    :res holds sequence of actons that the agent should make
    """
    explored = {}
    res=[]
    explored[problem.getStartState()]=(None,None)
    while(True):
        #f fringe is empty return the sequence of actions
        if not fringe.isEmpty() == 0:
            return res[1:]
        #pop the next element from the fringe
        nextNode = fringe.pop()

        #if the poped element is goal state then track the path using 'explored' variable and record the sequence of actions in 'res'
        if problem.isGoalState(nextNode[0]) == True:
            tmp = nextNode[0]
            explored[nextNode[0]] = (nextNode[1], nextNode[3])
            while(True):
                if tmp == None:
                    break
                res.insert(0,explored[tmp][0])
                tmp = explored[tmp][1]
            return res[1:]
        #mark the poped node as explored
        explored[nextNode[0]] = (nextNode[1], nextNode[3])
        #push the successors of the poped node into the fringe marking the current node as their parent
        for successor in problem.getSuccessors(nextNode[0]):
                if successor[0] not in explored and successor[0] not in fringe.list:
                    fringe.push((successor[0], successor[1], successor[2], nextNode[0]))

    util.raiseNotDefined()

def breadthFirstSearch(problem):
    """Search the shallowest nodes in the search tree first."""
    fringe = util.Queue()
    explored = []
    parent= {}
    res=[]
    # return if problem state is the goal state
    if problem.isGoalState(problem.getStartState()):
        return[]
    #push the start node into the queue
    fringe.push(problem.getStartState())
    parent[problem.getStartState()] = (None,None)
    """
        :explored holds state as a key and (action, cost, parent) as the value
        :res holds sequence of actons that the agent should make
        """

    # print  problem.getStartState()
    while(True):
        #if fringe is empty return the sequence of actions
        if not fringe.isEmpty() == 0:
            return res[1:]
        # pop the next element from the fringe
        nextNode = fringe.pop()
        # if the poped element is goal state then track the path using 'explored' variable and record the sequence of actions in 'res'

        if problem.isGoalState(nextNode) == True:
            tmp = nextNode
            # explored[nextNode[0]] = (nextNode[1], nextNode[3])
            while(True):
                if tmp == None:
                    break
                res.insert(0,parent[tmp][1])
                tmp = parent[tmp][0]
            return res[1:]
        #push the successors into the queue and update the 'explored' variable
        explored.append(nextNode)
        for successor in problem.getSuccessors(nextNode):
            if successor[0] not in explored and successor[0] not in fringe.list:
                fringe.push(successor[0])
                parent[successor[0]] = (nextNode,successor[1])
                # explored[successor[0][0]] = (successor[1], nextNode[0])

    util.raiseNotDefined()


def uniformCostSearch(problem):
    """Search the node of least total cost first."""
    """
            :explored holds state as a key and (action, cost, parent) as the value
            :res holds sequence of actons that the agent should make
            :fringe is the priority queue
            :fringe_list holds current cost of all the nodes 
            """
    res = []
    explored = {}
    fringe_list={}
    fringe = util.PriorityQueue()
    if problem.isGoalState(problem.getStartState()) == True:
        return []
    # push the start node into the priority queue
    fringe.push((problem.getStartState(),None,0,None),0)
    fringe_list[problem.getStartState()] = 0

    while True:
        # if fringe is empty return the sequence of actions
        if not fringe.isEmpty() == 0:
            return res[1:]
        nextNode = fringe.pop()
        #update the explored nodes
        explored[nextNode[0]] = (nextNode[1], nextNode[2], nextNode[3])
        #if goal state then track the path from the explored variable and return the sequence
        if problem.isGoalState(nextNode[0]) == True:
            tmp = nextNode[0]
            # explored[nextNode[0]] = (nextNode[1],nextNode[0],/ nextNode[2])
            while(True):
                if tmp == None:
                    break
                res.insert(0,explored[tmp][0])
                tmp = explored[tmp][2]
            return res[1:]
        #push the successors of current node into the fringe
        for successor in problem.getSuccessors(nextNode[0]):
            #if successor is not in explored list and in the fringe then push them into the fringe
            if successor[0] not in explored and successor[0] not in fringe_list:
                fringe.push((successor[0], successor[1], nextNode[2]+successor[2], nextNode[0]),nextNode[2]+successor[2])
                fringe_list[successor[0]] = nextNode[2] + successor[2]
            #else if successor is in the fringe and the computed cost is less than the current cost then update
            # the cost of the node with the computed cost in  the fringe and update the parent of the node in 'explored'
            elif successor[0] in fringe_list and nextNode[2]+successor[2] < fringe_list[successor[0]] :
                fringe.update((successor[0],successor[1],nextNode[2]+successor[2],nextNode[0]),nextNode[2]+successor[2])
                fringe_list[successor[0]] = nextNode[2]+successor[2]
                explored[successor[0]] = (successor[1],nextNode[2]+successor[2],nextNode[0])
    util.raiseNotDefined()

def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """

    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""
    """
            :explored holds explored states 
            :res holds sequence of actons that the agent should make
            :fringe is the priority queue
            :fringe_list holds current cost of all the nodes 
            """
    res = []
    explored = []
    parents = {}
    fringe_list = {}
    fringe = util.PriorityQueue()
    #if start state is the goal state then return
    if problem.getStartState() == True:
        return []
    #push the start state to the fringe with the cost zero pus heuristic value
    fringe.push(problem.getStartState(),0 + heuristic(problem.getStartState(),problem))
    fringe_list[problem.getStartState()] = 0

    while True:
        #if fringe is empty then return the sequence of actions 'res'
        if fringe.isEmpty():
            return res[1:]
        #pop a node from the fringe
        nextNode = fringe.pop()

        # if the poped element is in explored then continue
        if nextNode in explored:
            continue
        #if poped element is goal state then track the parents from the current node to the parent node
        #and record the actions in the res state. Return the result
        if problem.isGoalState(nextNode):
            temp = nextNode
            while True:
                if temp == problem.getStartState():
                    break
                res.insert(0,parents[temp][1])
                temp = parents[temp][0]
            return res
        # mark the node as explored
        explored.append(nextNode)
        #push the successors of the eplored node to the fringe
        for successor in problem.getSuccessors(nextNode):
            #if successor is in fringe and computed cost is less than the current cost then update the cost and parent
            #else push the successor to the fringe
            #in second case update functon acts as push
            if successor[0] in fringe_list:
                if successor[2]+fringe_list[nextNode] < fringe_list[successor[0]]:
                    fringe_list[successor[0]] = successor[2] + fringe_list[nextNode]
                    parents[successor[0]] = (nextNode,successor[1])
            else:
                fringe_list[successor[0]] = successor[2] + fringe_list[nextNode]
                parents[successor[0]] = (nextNode, successor[1])
            fringe.update(successor[0],successor[2] + fringe_list[nextNode]+ heuristic(successor[0],problem))

    util.raiseNotDefined()


# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
