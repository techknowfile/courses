# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

def depthFirstSearch(problem):
    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches the
    goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:
    
    print "Start:", problem.getStartState()
    print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    print "Start's successors:", problem.getSuccessors(problem.getStartState())
    "*** YOUR CODE HERE ***"
    """
    #Stack is used to store node and the direction of the discovered node
    stack = util.Stack()
    #visited nodes is a set which contains a list of all the nodes which have been visited already.
    visited_nodes = set()
    #Initially the path is initialized with the starting node and an empty list of direction.
    path = [problem.getStartState(), []]
    #pushing the initial path list in the stack.
    stack.push(path)
    #Repeat the process until the goal node is not found
    while not problem.isGoalState(path[0]):
        current_node, direction = path
        #next_node fetches the successor nodes of the currently visited node and the direction of the successor node.
        next_node = problem.getSuccessors(current_node)
        for node in next_node:
            #while there are successor nodes, keep pushing the node value and the direction into the stack
            stack.push((node[0], direction + [node[1]]))
        while not stack.isEmpty():
            #when there are no more successor nodes for the current node, pop the topmost node out of the stack.
            #Now the current node will be the new topmost most node in the stack.
            #Repeat the entire process again of fetching the successors and pushing them onto the stack.
            node = stack.pop()
            #This is just to check if the current_node is there in the set of visited_nodes or nodes
            if node[0] not in visited_nodes:
                break
        #Assigning node value to the path list
        path = node
        #Once all the successor nodes are visited, mark those nodes as visited. Add them in the visited_nodes set
        visited_nodes.add(node[0])
    #Path is a list which contains the nodes and the directions in which they are traversed. Return the direction list to fetch the current direction of the nodes traversed
    return path[1]
    #util.raiseNotDefined()


def breadthFirstSearch(problem):
    """Search the shallowest nodes in the search tree first."""
    "*** YOUR CODE HERE ***"
    #Breadth First Search algorithm uses a queue to visit all the nodes.
    queue = util.Queue()
    visited_nodes = set()
    path = [problem.getStartState(), []]
    #Here, the current path is pushed into the queue. Queue works on First in First Out methodology.
    #so once all the successors of the first node in the queue are visited, pop it from the queue.
    #Here, current path contains the starting node and an empty list of direction.
    queue.push(path)
    #Adding the starting node of the graph in the visited_nodes set
    visited_nodes.add(problem.getStartState())
    # Repeat the process until the goal node is not found
    while not problem.isGoalState(path[0]):
        current_node, direction = path
        #next_node fetches the successors of the current node.
        next_node = problem.getSuccessors(current_node)
        for node in next_node:
            #while there are successors for the current node, keep pushing the node value and the direction of that node into the queue.
            queue.push((node[0], direction + [node[1]]))
        while not queue.isEmpty():
            #After all the successor nodes of the current node are pushed into the queue, pop the firstmost element of the queue out.
            node = queue.pop()
            if node[0] not in visited_nodes:
                break
            #If the topmost node of the queue is in the visited_nodes set, repeat the process of fetching the successors of this node and pushing them into the queue.
        path = node
        #Add the current node into the visited_nodes set
        visited_nodes.add(node[0])
    #Returning the list of directions of traversal.
    return path[1]
    #util.raiseNotDefined()

def uniformCostSearch(problem):
    """Search the node of least total cost first."""
    "*** YOUR CODE HERE ***"
    #Priority queue are implemented with heaps. Here, each item which will be inserted in the priority queue will have a priority associated to it.
    #The item with lowest priority will be retrieved quickly.
    priority_queue = util.PriorityQueue()
    visited_nodes = set()
    #Along with the state and the list of direction, cost is also stored in the list of path. Initially the cost is assigned as 0.
    path = [problem.getStartState(), [], 0]
    visited_nodes.add(problem.getStartState())
    # Repeat the process until the goal node is not found
    while not problem.isGoalState(path[0]):
        #Cost is being fetched from the path list.
        current_node, direction, cost = path
        #Fetch the successor nodes of the current_node being traversed.
        next_node = problem.getSuccessors(current_node)
        for node in next_node:
            #Pushing the successor nodes, the direction of the traversal and the cost of traversing that node in the priority queue.
            #Here cost is stored as the priority for that entire element.
            priority_queue.push((node[0], direction + [node[1]], cost + node[2]), cost + node[2])
        while not priority_queue.isEmpty():
            #based on the priority of the elements, nodes are popped from the priority queue.
            node = priority_queue.pop()
            if node[0] not in visited_nodes:
                break
            #The process is repeated until the priority queue is not empty.
        #Node value, the direction of traversal and the cost of traversal is stored in the path list
        path = [node[0], node[1], node[2]]
        #Marking the current node in the priority queue as visited.
        visited_nodes.add(node[0])
    #Returning the list of direction of traversal.
    return path[1]
    util.raiseNotDefined()

def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""
    "*** YOUR CODE HERE ***"
    #For A* search, again a priority queue is used. Here also, the cost is the priority value of each node.
    priority_queue = util.PriorityQueue()
    visited_nodes = set()
    #Path is initialized with the starting state value, an empty list of direction and 0 cost.
    path = [problem.getStartState(), [], 0]
    visited_nodes.add(problem.getStartState())
    # Repeat the process until the goal node is not found
    while not problem.isGoalState(path[0]):
        #Current node value, direction list and cost is being fetch from the current path list
        current_node, direction, cost = path
        #Getting the successors of the current node.
        next_node = problem.getSuccessors(current_node)
        for node in next_node:
            #Keep pushing the successor node values, direction of traversal and the cost of traversal in the priority queue.
            #Here the priority of the node will be the sum of cost of the traversal of the node and the heuristic value for the traversal.
            priority_queue.push((node[0], direction + [node[1]], cost + node[2]), cost + node[2] + heuristic(node[0],problem))
        while not priority_queue.isEmpty():
            #Pop the current traversed node out of the priority queue based on its priority until the queue is not empty.
            node = priority_queue.pop()
            if node[0] not in visited_nodes:
                break
        path = node[0], node[1], node[2]
        # Marking the current node in the priority queue as visited.
        visited_nodes.add(node[0])
    # Returning the list of direction of traversal.
    return path[1]
    util.raiseNotDefined()


# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
