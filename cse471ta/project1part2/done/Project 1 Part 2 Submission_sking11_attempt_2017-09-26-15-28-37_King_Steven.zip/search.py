# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
#
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).

"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util
import time

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

def depthFirstSearch(problem):
    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches the
    goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:

    print "Start:", problem.getStartState()
    print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    print "Start's successors:", problem.getSuccessors(problem.getStartState())
    """
    "*** YOUR CODE HERE ***"
    # Initialize our trackers
    # Visited is the set of nodes which have been expanded or are currently in the fringe
    # Paths is a dictionary of successor node -> (parent node, direction from parent to successor), for keeping track of the path from node to node
    # Found is both the stopping condition for the search loop, and an indicator as to whether a solution has been found
    # Goal state is a reference to the final goal state, set just before the loop terminates. This allows us to reconstruct the path from the goal node to the start node using the afforementioned path dictionary
    visited = set()
    paths = dict()
    found = False
    goal_state = None

    # Get the initial start state, initialize the fringe as a stack, and add the first element to the stack
    initial_state = problem.getStartState()
    # Because we are doing a Depth-First-Search, the data structure for managing the fringe is a Stack
    stack = util.Stack()
    stack.push(initial_state)

    # Iterate until the fringe is empty or the goal node is found
    while not stack.isEmpty() and not found:
        current_node = stack.pop()
        # Stop if the currently expanded node is the goal node, set references and terminate the loop
        if problem.isGoalState(current_node):
            goal_state = current_node
            found = True
            break
        # Add the current node to the visited set
        visited.add(current_node)
        # Iterate over the successors (in reverse order so they can be added to the stack in reverse order) and add them to the fringe
        successors = problem.getSuccessors(current_node)[::-1]
        for successor in successors:
            successor_position, direction, _ = successor
            if successor_position not in visited and successor_position:
                paths[successor_position] = (current_node, direction)
                stack.push(successor_position)


    # If the goal node was not found, return a null path
    if not found:
        return []
    # Otherwise, start at the goal node and build the series of directions to the goal node by iteratively following the parents back to the initial node
    else:
        solution = []
        iterator = goal_state
        # Stop once we've arrived at the initial state
        while iterator != initial_state:
            # Get the parent and direction from parent to successor
            previous_position, direction = paths[iterator]
            # Add the parent to the solution
            solution.append(direction)
            # Move the iterator to the parent
            iterator = previous_position
        # The list of directions is built in reverse order; reverse the directions before returning it
        return solution[::-1]

def breadthFirstSearch(problem):
    """Search the shallowest nodes in the search tree first."""
    "*** YOUR CODE HERE ***"
    # Initialize our trackers
    # Visited is the set of nodes which have been expanded or are currently in the fringe
    # on_frige is a set of all items currently in the fringe, in order for O(1) lookups
    # Paths is a dictionary of successor node -> (parent node, direction from parent to successor), for keeping track of the path from node to node
    # Found is both the stopping condition for the search loop, and an indicator as to whether a solution has been found
    # Goal state is a reference to the final goal state, set just before the loop terminates. This allows us to reconstruct the path from the goal node to the start node using the afforementioned path dictionary
    visited = set()
    on_fringe = set()
    paths = dict()
    found = False
    goal_state = None

    # Get the initial start state, initialize the fringe as a stack, and add the first element to the stack
    initial_state = problem.getStartState()
    # Because we are doing a Breadth-First-Search, the data structure for managing the fringe is a Queue
    queue = util.Queue()
    queue.push(initial_state)
    on_fringe.add(initial_state)

    # Iterate until the fringe is empty or the goal node is found
    while not queue.isEmpty() and not found:
        current_node = queue.pop()
        on_fringe.remove(current_node)
        # Stop if the currently expanded node is the goal node, set references and terminate the loop
        if problem.isGoalState(current_node):
            goal_state = current_node
            found = True
            break
        # Add the current node to the visited set
        visited.add(current_node)
        # Iterate over the successors and add them to the fringe if they are not yet on the fringe
        successors = problem.getSuccessors(current_node)
        for successor in successors:
            successor_position, direction, _ = successor
            if successor_position not in visited and successor_position not in on_fringe:
                # visited.add(successor_position)
                paths[successor_position] = (current_node, direction)
                queue.push(successor_position)
                on_fringe.add(successor_position)

    # If the goal node was not found, return a null path
    if not found:
        return []
    # Otherwise, start at the goal node and build the series of directions to the goal node by iteratively following the parents back to the initial node
    else:
        solution = []
        iterator = goal_state
        # Stop once we've arrived at the initial state
        while iterator != initial_state:
            # Get the parent and direction from parent to successor
            previous_position, direction = paths[iterator]
            # Add the parent to the solution
            solution.append(direction)
            # Move the iterator to the parent
            iterator = previous_position
        # The list of directions is built in reverse order; reverse the directions before returning it
        return solution[::-1]


def uniformCostSearch(problem):
    """Search the node of least total cost first."""
    "*** YOUR CODE HERE ***"
    # Initialize our trackers
    # Visited is the set of nodes which have been expanded or are currently in the fringe
    # Costs is a dictonary of node -> total cost to reach the node, so that we can lookup the cost to reach a parent node or detect if a shorter path to a successor node has been found
    # Paths is a dictionary of successor node -> (parent node, direction from parent to successor), for keeping track of the path from node to node
    # Found is both the stopping condition for the search loop, and an indicator as to whether a solution has been found
    # Goal state is a reference to the final goal state, set just before the loop terminates. This allows us to reconstruct the path from the goal node to the start node using the afforementioned path dictionary
    visited = set()
    costs = dict()
    paths = dict()
    found = False
    goal_state = None

    # Because we are doing Uniform Cost Search, the data structure for managing the fringe is a PriorityQueue, organized by the total cost to reach a node
    initial_state = problem.getStartState()
    queue = util.PriorityQueue()
    queue.push(initial_state, 0)
    # The total cost to reach the first node is 0
    costs[initial_state] = 0

    # Iterate until the fringe is empty or the goal node is found
    while not queue.isEmpty() and not found:
        current_node = queue.pop()
        # Stop if the currently expanded node is the goal node, set references and terminate the loop
        if problem.isGoalState(current_node):
            goal_state = current_node
            found = True
            break
        # Add the current node to the visited set
        visited.add(current_node)
        # Iterate over the successors and add them to the fringe if they are not yet on the fringe, or update their priority on the fringe if a shorter path is found
        successors = problem.getSuccessors(current_node)
        for successor in successors:
            successor_position, direction, cost = successor
            if successor_position not in visited:
                # Estimate costs
                current_cost = costs[current_node]
                total_cost = current_cost + cost
                # Set the path and cost to reach successor if not already present, or if a shorter path has been found than already exists
                if successor_position not in paths or total_cost < costs[successor_position]:
                    costs[successor_position] = total_cost
                    paths[successor_position] = (current_node, direction)
                # queue.update instead of queue.add ensures that new nodes are added and old nodes will have priorities/costs revaluated
                queue.update(successor_position, total_cost)

    # If the goal node was not found, return a null path
    if not found:
        return []
    # Otherwise, start at the goal node and build the series of directions to the goal node by iteratively following the parents back to the initial node
    else:
        solution = []
        iterator = goal_state
        # Stop once we've arrived at the initial state
        while iterator != initial_state:
            # Get the parent and direction from parent to successor
            previous_position, direction = paths[iterator]
            # Add the parent to the solution
            solution.append(direction)
            # Move the iterator to the parent
            iterator = previous_position
        # The list of directions is built in reverse order; reverse the directions before returning it
        return solution[::-1]

def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""
    "*** YOUR CODE HERE ***"
    # Initialize our trackers
    # Visited is the set of nodes which have been expanded or are currently in the fringe
    # Costs is a dictonary of node -> total cost to reach the node, so that we can lookup the cost to reach a parent node or detect if a shorter path to a successor node has been found
    # Paths is a dictionary of successor node -> (parent node, direction from parent to successor), for keeping track of the path from node to node
    # Found is both the stopping condition for the search loop, and an indicator as to whether a solution has been found
    # Goal state is a reference to the final goal state, set just before the loop terminates. This allows us to reconstruct the path from the goal node to the start node using the afforementioned path dictionary
    visited = set()
    costs = dict()
    paths = dict()
    found = False
    goal_state = None

    # Because we are doing A* Search, the data structure for managing the fringe is a PriorityQueue, organized by the total cost to reach a node
    initial_state = problem.getStartState()
    queue = util.PriorityQueue()
    queue.push(initial_state, 0)
    # The total cost to reach the first node is 0
    costs[initial_state] = 0

    # Iterate until the fringe is empty or the goal node is found
    while not queue.isEmpty() and not found:
        current_node = queue.pop()
        # Stop if the currently expanded node is the goal node, set references and terminate the loop
        if problem.isGoalState(current_node):
            goal_state = current_node
            found = True
            break
        # Add the current node to the visited set
        visited.add(current_node)
        # Iterate over the successors and add them to the fringe if they are not yet on the fringe, or update their priority on the fringe if a shorter path is found
        successors = problem.getSuccessors(current_node)
        for successor in successors:
            successor_position, direction, cost = successor
            if successor_position not in visited:
                # Estimate costs
                current_cost = costs[current_node]
                total_cost = current_cost + cost
                # Set the path and cost to reach successor if not already present, or if a shorter path has been found than already exists
                if successor_position not in paths or total_cost < costs[successor_position]:
                    costs[successor_position] = total_cost
                    paths[successor_position] = (current_node, direction)
                # queue.update instead of queue.add ensures that new nodes are added and old nodes will have priorities/costs revaluated
                queue.update(successor_position, total_cost + heuristic(successor_position, problem))

    # If the goal node was not found, return a null path
    if not found:
        return []
    # Otherwise, start at the goal node and build the series of directions to the goal node by iteratively following the parents back to the initial node
    else:
        solution = []
        iterator = goal_state
        # Stop once we've arrived at the initial state
        while iterator != initial_state:
            # Get the parent and direction from parent to successor
            previous_position, direction = paths[iterator]
            # Add the parent to the solution
            solution.append(direction)
            # Move the iterator to the parent
            iterator = previous_position
        # The list of directions is built in reverse order; reverse the directions before returning it
        return solution[::-1]


# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
