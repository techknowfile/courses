# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

def depthFirstSearch(problem):
    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches the
    goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:

    print "Start:", problem.getStartState()
    print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    print "Start's successors:", problem.getSuccessors(problem.getStartState())
    """
    openList = util.Stack();  # LIFO order is maintained for DFS
    closed = []  # closed list to maintain already explored nodes
    startNode = (problem.getStartState(), [], 0);  # start node
    openList.push(startNode);  # each node comprises of : 1) coordinates(x,y), 2)direction(S/W) 3)cost

    while openList.isEmpty() is False:  # loop until the openlist is not exhausted
        currCoor, currDir, currCost = openList.pop();
        current = (currCoor, currDir, currCost);

        if problem.isGoalState(current[0]):  # check if the newly explored node is a goal node and return the list of directions to be followed.
            print "Goal Reached with DirectionList: ", current[1];
            print "Cost to achieve the Goal: ", current[2];
            return current[1];

        if current[0] in closed:  # skip the loop incase the current node has already been explored
            continue

        closed.append(current[0])  # add the current node to closed list incase it is a new node

        successors = problem.getSuccessors(current[0]);  # extract the successors/children of this newly explored node
        for successor in successors:
            newDirection = current[1] + [successor[1]];
            newCost = current[2] + successor[2];
            newNode = (successor[0], newDirection, newCost);  # update the direction and cost values of the new node
            openList.push(newNode);  # push the new node into the open list

    return [];
    util.raiseNotDefined()

def breadthFirstSearch(problem):
    """Search the shallowest nodes in the search tree first."""
    openList = util.Queue();  # FIFO order is maintained for BFS
    closed = []  # closed list to maintain already explored nodes
    startNode = (problem.getStartState(), [], 0);  # start node
    openList.push(startNode);  # each node comprises of : 1) coordinates(x,y), 2)direction(S/W) 3)cost

    while openList.isEmpty() is False:  # loop until the openlist is not exhausted
        currCoor, currDir, currCost = openList.pop();
        current = (currCoor, currDir, currCost);

        if problem.isGoalState(current[0]):  # check if the newly explored node is a goal node and return the list of directions to be followed.
            #print "Goal Reached with DirectionList: ", current[1];
            #print "Cost to achieve the Goal: ", current[2];
            return current[1];

        if current[0] in closed:  # skip the loop incase the current node has already been explored
            continue

        closed.append(current[0]);  # add the current node to closed list incase it is a new node

        successors = problem.getSuccessors(current[0]);  # extract the successors/children of this newly explored node
        for successor in successors:
            newDirection = current[1] + [successor[1]];
            newCost = current[2] + successor[2];
            newNode = (successor[0], newDirection, newCost);  # update the direction and cost values for new node
            openList.push(newNode);  # push the new node in the open list

    return [];
    util.raiseNotDefined()


def uniformCostSearch(problem):
    """Search the node of least total cost first."""
    openList = util.PriorityQueue();  # Priority Queue is maintained for UCS based on path-cost(g-value)
    closed = [];  # closed list to maintain list of explored nodes
    startNode = (problem.getStartState(), [], 0);  # start node
    openList.push(startNode, startNode[2]);  # each node comprises of : 1) coordinates(x,y), 2)direction(S/W) 3)cost

    while openList.isEmpty() is False:  # loop until the openlist is not exhausted
        currCoor, currDir, currCost = openList.pop();
        current = (currCoor, currDir, currCost);

        if problem.isGoalState(current[0]):  # check if the newly explored node is a goal node and return the list of directions to be followed.
            print "Goal Reached with DirectionList: ", current[1];
            print "Cost to achieve the Goal: ", current[2];
            return current[1];

        if current[0] not in closed:  # check if the current node is already explored
            successors = problem.getSuccessors(current[0]);  # extract the successors/children of this new node
            for coordinate, direction, cost in successors:
                if coordinate not in closed:
                    newDirection = current[1] + [direction];  # update the direction value for new node
                    newCost = problem.getCostOfActions(current[1] + [direction]);  # update the cot value for new node which could even change its priority in the queue
                    newNode = (coordinate, newDirection, newCost);
                    openList.push(newNode, newNode[2]);  # push the new node in openList with updated priority
        closed.append(current[0]);  # append the current node in closed list
    return [];
    util.raiseNotDefined()

def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""
    openList = util.PriorityQueue();  # Priority Queue is maintained for A* based on f-value(g-value + h-value)
    closed = [];  # closed list to maintain the list of explored nodes
    startNode = (problem.getStartState(), []);  # start node
    openList.push(startNode, heuristic(startNode[0],problem));  # each node comprises of : 1) coordinates(x,y), 2)direction(S/W) 3)cost(f-value=g-value+h-value)

    while openList.isEmpty() is False:  # loop until openlist is not exhausted
        currCoor, currDir = openList.pop();
        current = (currCoor, currDir);

        if problem.isGoalState(current[0]):  # check if the newly explored node is a goal node and return the list of directions to be followed.
            print "Goal Reached with DirectionList: ", current[1];
            return current[1];

        if current[0] not in closed:  # check if the current node is already explored
            successors = problem.getSuccessors(current[0]);  # extract the successors/children of this newly explored node
            for successor in successors:
                coordinate = successor[0]
                if coordinate not in closed:
                    newDirection = current[1] + [successor[1]];  # update the direction value for new node
                    newCost = problem.getCostOfActions(newDirection) + heuristic(coordinate,problem);  # update the cost value based on new directions(g-value) and h-value for coorindate
                    newNode = (coordinate, newDirection);
                    openList.push(newNode, newCost);  # push the new node into open list with updated priority
        closed.append(current[0]);  # append the current node in closed list
    return [];
    util.raiseNotDefined()


# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
