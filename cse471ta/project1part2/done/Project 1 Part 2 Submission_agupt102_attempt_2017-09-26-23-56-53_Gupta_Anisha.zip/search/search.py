# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
#
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).

# Anisha Gupta
# 1207134535

"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util
from util import Stack
from util import Queue
from util import PriorityQueue


class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]


def printGraph(graph, start, end, path=[]):
        path = path + [start]
        if start == end:
            return [path]
        if not graph.has_key(start):
            return []
        paths = []
        for node in graph[start]:
            if node not in path:
                newpaths = find_all_paths(graph, node, end, path)
                for newpath in newpaths:
                    paths.append(newpath)
        return paths

def depthFirstSearch(problem):

    """Search the deepest nodes in the search tree first."""

    #DFS requires a LIFO data structure, using Stack in util
    frontier = Stack()
    #initialize the frontier using the initial state of the problem, added initial cost and path for universal
    startState = problem.getStartState()
    startPath = []
    startCost = 0
    node = (startState, startPath, startCost)
    #Add the starting node into the frontier as the starting point of the search.
    frontier.push(node)

    # initialize the explored set to be empty
    explored = set()

    #Keeps iterating through each frontier
    while not frontier.isEmpty():
        #chooses a node and remove it as a state from the frontier
        #In this case, choosing a state and removing it
        node = frontier.pop()
        (state, path, cost) = node

        #if node is a goal state return path as solution
        # A terminating case that allows for the path to be returned once
        # a goal state is reached
        if problem.isGoalState(state):
            return path

        #Checks to make sure that the state is not in the explored set
        # Not required in DFS but an extra check
        if not state in explored:
        #Add the node to the explored set
            explored.add(state)
        else:
            continue

        # Expand the chosen node
        # The nextNode from the successors is taken and accounts for the new actions in this case
        # newPath to input into the newNode which will be placed in the frontier.
        for nextState, nextPath, cost in problem.getSuccessors(state):
            #only if not in the explored set
            if nextState not in explored:
                newPath = path + [nextPath]
                newNode = (nextState, newPath, cost)
                # add resulting nodes to the frontier
                frontier.push(newNode)
    return []

def breadthFirstSearch(problem):
    """Search the shallowest nodes in the search tree first."""

    # Overall BFS utilizes the same graph search algorithm as DFS but with a Queue instead of
    # a stack which allows each level to be searched before going to a new depth.

    #BFS requires a FIFO data structure, using Queue in util
    frontier = Queue()
    #initialize the frontier using the initial state of the problem, added initial cost and path for universal
    startState = problem.getStartState()
    startPath = []
    startCost = 0
    node = (startState, startPath, startCost)
    frontier.push(node)

    # initialize the explored set to be empty
    explored = set()

    while not frontier.isEmpty():
        #chooses a node and remove it as a state from the frontier
        #In this case, choosing a state and removing it
        node = frontier.pop()
        (state, path, cost) = node

        #if node is a goal state return path as solution
        if problem.isGoalState(state):
            return path

        #Checks to make sure that the state is not in the explored set
        if not state in explored:
        #Add the node to the explored set
            explored.add(state)
        else:
            continue

        # Expand the chosen node
        # The nextNode from the successors is taken and accounts for the new actions in this case
        # newPath to input into the newNode which will be placed in the frontier.
        for nextState, nextPath, cost in problem.getSuccessors(state):
            node = (nextState, nextPath, cost)
            #only if not in the explored set
            if nextState not in explored:
                newPath = path + [nextPath]
                newNode = (nextState, newPath, cost)
                # add resulting nodes to the frontier
                frontier.push(newNode)
    return []



def uniformCostSearch(problem):
    """Search the node of least total cost first."""

    frontier = PriorityQueue()
    #initialize the frontier using the initial state of the problem, added initial cost and path for universal
    startState = problem.getStartState()
    startPath = []
    startCost = 0
    startNode = (startState, startPath, startCost)
    frontier.push(startNode, startCost)

    # initialize the explored set to be empty
    explored = set()

    while not frontier.isEmpty():
        #chooses a node and remove it as a state from the frontier
        #In this case, choosing a state and removing it
        (state, path, cost) = frontier.pop()

        #if node is a goal state return path as solution
        if problem.isGoalState(state):
            return path

        if not state in explored:
        #Add the node to the explored set
            explored.add(state)
        else:
            continue


        # Expand the chosen node
        # The nextNode from the successors is taken and accounts for the new actions in this case
        # newPath to input into the newNode which will be placed in the frontier.
        # Furthermore, for uniformCost, the newCost is taken in account and pushed with the newNode in the
        # frontier.
        for nextState, nextPath, nextCost in problem.getSuccessors(state):
            #only if not in the explored set
            if nextState not in explored:
                newPath = path + [nextPath]
                newCost = cost + nextCost
                newNode = (nextState, newPath, newCost)
                # add resulting nodes to the frontier
                frontier.push(newNode, newCost)
    return []

def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""

    frontier = PriorityQueue()
    #initialize the frontier using the initial state of the problem, added initial cost and path for universal
    startState = problem.getStartState()
    startPath = []
    startCost = 0
    startNode = (startState, startPath, startCost)
    frontier.push(startNode, startCost)

    # initialize the explored set to be empty
    explored = set()

    while not frontier.isEmpty():
        #chooses a node and remove it as a state from the frontier
        #In this case, choosing a state and removing it
        (state, path, cost) = frontier.pop()

        #if node is a goal state return path as solution
        if problem.isGoalState(state):
            return path

        if not state in explored:
        #Add the node to the explored set
            explored.add(state)
        else:
            continue


        # Expand the chosen node
        # The nextNode from the successors is taken and accounts for the new actions in this case
        # newPath to input into the newNode which will be placed in the frontier.
        # Furthermore, for uniformCost, the heuristicCost is taken in account and pushed with the newNode in the
        # frontier. The heuristic value is calculated by summing up the newCost with the heuristic of the nextState of the
        # successor value.
        for nextState, nextPath, nextCost in problem.getSuccessors(state):
            #only if not in the explored set
            if nextState not in explored:
                newPath = path + [nextPath]
                newCost = cost + nextCost
                newNode = (nextState, newPath, newCost)
                heuristicCost = newCost + heuristic(nextState,problem)
                if nextState not in frontier.heap and nextState not in explored:
                    # add resulting nodes to the frontier
                    frontier.push(newNode, heuristicCost)
    return []


# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
