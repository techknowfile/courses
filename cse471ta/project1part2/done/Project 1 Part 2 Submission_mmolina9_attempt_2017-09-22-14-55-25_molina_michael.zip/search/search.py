# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
#
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).

import util

class SearchProblem:

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

def depthFirstSearch(problem):
    """
    Returns a sequence of moves that solves any maze via depth first search algorithm.
    """
    dfsP = util.Stack()
    dfsP.push( (problem.getStartState(), []) )
    visited = [problem.getStartState()]

    while not dfsP.isEmpty():
        current, actions = dfsP.pop()

        if problem.isGoalState(current):
            return actions

        visited.append(current)

        for coord, direction, steps in problem.getSuccessors(current):
            if coord not in visited:
                dfsP.push((coord, actions + [direction]))


    return []

def breadthFirstSearch(problem):
    """
    Returns a sequence of moves that solves any maze via breadth first search algorithm.
    """
    bfsP = util.Queue()
    bfsP.push( (problem.getStartState(), []) )
    visited = [problem.getStartState()]

    while not bfsP.isEmpty():
        current, actions = bfsP.pop()

        if problem.isGoalState(current):
            return actions

        for coord, direction, steps in problem.getSuccessors(current):
            if coord not in visited:
                bfsP.push((coord, actions + [direction]))
                visited.append(coord)

    return []

def uniformCostSearch(problem):
    """
    Returns a sequence of moves that solves any maze via an algorthm that works for uniform cost of earch node.
    """
    ucsP = util.PriorityQueue()
    ucsP.push( (problem.getStartState(), [], 0), 0)
    visited = {problem.getStartState(): 0}

    while not ucsP.isEmpty():
        current, actions, cost = ucsP.pop()

        if problem.isGoalState(current):
            return actions

        for coord, direction, steps in problem.getSuccessors(current):
            if coord not in visited or (cost + steps) < visited[coord]:
                ucsP.push((coord, actions + [direction], cost + steps), cost + steps)
                visited[coord] = cost + steps

    return []

def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    """
    Returns a sequence of moves that solves any maze via an algorthm that works form each cost of the node via the cost of each action as well as it distance from the goal node.
    """
    ucsP2 = util.PriorityQueue()
    ucsP2.push((problem.getStartState(), []), problem.getCostOfActions({}) + heuristic(problem.getStartState(), problem))
    visited = set([])

    while not ucsP2.isEmpty():
        current, actions = ucsP2.pop()

        if problem.isGoalState(current) :
            return actions

        if not current in visited :
            visited.add(current)
            for coord, direction, steps in problem.getSuccessors(current):
                ucsP2.push( ( coord, actions + [direction]), problem.getCostOfActions(actions + [direction]) + heuristic(coord, problem) )


# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
