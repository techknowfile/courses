# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

def depthFirstSearch(problem):
    """
    This algorithm searches for the deepest nodes first

    print "Start:", problem.getStartState()
    print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    print "Start's successors:", problem.getSuccessors(problem.getStartState())
    """
    "*** YOUR CODE HERE ***"
    stack = util.Stack()
    visited = []                                             # stores the list of visited nodes
    stack.push([(problem.getStartState(), "", 0)])           # push the inital state of the problem onto the stack

    while not stack.isEmpty():
        actionList = stack.pop()
        element = actionList[len(actionList) - 1]
        element = element[0]

        if problem.isGoalState(element):          # if goal state is found, then return the list of actions
            return [val[1] for val in actionList][1:]

        if element not in visited:
            visited.append(element)    # if the node is not visited, append the node to the visited list

            for next in problem.getSuccessors(element):   # loop through the successors of the current node
                if next[0] not in visited:
                    nextList = actionList[:]
                    nextList.append(next)
                    stack.push(nextList)
    # util.raiseNotDefined()

def breadthFirstSearch(problem):
    """Search the shallowest nodes in the search tree first."""
    "*** YOUR CODE HERE ***"
    queue = util.Queue()
    visited = []       # stores the list of visited nodes
    queue.push([(problem.getStartState(), "", 0)])  # initial states of the problem is pushed onto the queue

    while not queue.isEmpty():
        actionList = queue.pop()
        element = actionList[len(actionList) - 1]
        element = element[0]

        if problem.isGoalState(element):
            return [val[1] for val in actionList][1:]   # if goal state reached, return the list of actions

        if element not in visited:
            visited.append(element)                     # if the node is not visited, append it to visited list

            for next in problem.getSuccessors(element):  # loop through the succcessors of the current node
                if next[0] not in visited:
                    nextList = actionList[:]
                    nextList.append(next)
                    queue.push(nextList)
    # util.raiseNotDefined()

def uniformCostSearch(problem):
    """Search the node of least total cost first."""
    "*** YOUR CODE HERE ***"
    return aStarSearch(problem)
    # util.raiseNotDefined()

def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""
    "*** YOUR CODE HERE ***"
    return searchImpl(problem, util.PriorityQueue(), heuristic)
    # util.raiseNotDefined()


def searchImpl(problem, queue, heuristic=None):
    """
    This algorithm first goes as deep as it can before it explores other path.
    """

    travelled = []    # stores the list of already visited nodes
    list_steps = []   # stores the list of actions taken
    start_state = problem.getStartState()  # problem starting state

    # push the initial state and the initial list of actions onto the queue
    # data structure
    if isinstance(queue, util.Stack) or isinstance(queue, util.Queue):
        queue.push((start_state, list_steps))
    elif isinstance(queue, util.PriorityQueue):
        queue.push((start_state, list_steps), heuristic(start_state, problem))

    # expanding all the nodes and storing the value of cost and the actions.
    # if the node is a goal node, then we stop else we try to find the child of the
    # current node. We update the value of the cost by adding the current cost and the
    # previous cost.

    while queue:
        if isinstance(queue, util.Stack) or isinstance(queue, util.Queue):
            cur_node, steps = queue.pop()
        elif isinstance(queue, util.PriorityQueue):
            cur_node, steps = queue.pop()

        if not cur_node in travelled:
            travelled.append(cur_node)

            if problem.isGoalState(cur_node):
                return steps

            child = problem.getSuccessors(cur_node) # get the successor of the current node

            for next in child:
                state, next_step, cost = next
                updated_steps = steps + [next_step]   # update the list of steps

                if isinstance(queue, util.Stack) or isinstance(queue, util.Queue):
                    queue.push((state, updated_steps))   # push the current state and the updated steps on the queue
                elif isinstance(queue, util.PriorityQueue):
                    updated_cost = problem.getCostOfActions(updated_steps) + \
                              heuristic(state, problem)               # update the cost
                    queue.push((state, updated_steps), updated_cost)


# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
