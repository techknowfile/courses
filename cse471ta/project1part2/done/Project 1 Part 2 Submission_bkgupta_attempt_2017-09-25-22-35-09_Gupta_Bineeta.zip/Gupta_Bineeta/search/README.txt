ReadMe File:

1. IDE: Used VSCode 
2. Language: Python 
3. At top of each function: 
	a) what is the function ?
	b) Startegy
	c) Pseudo code
	d) Refrences

Commands checked and are successfully working:
1. Python autograder.py
2. python pacman.py -l <tiny/medium/Big>Maze -p SearchAgent -a fn=<dfs/bfs/ucs>
3. python pacman.py -l mediumDottedMaze -p StayEastSearchAgent
4. python pacman.py -l mediumScaryMaze -p StayWestSearchAgent
5. python pacman.py -l bigMaze -z .5 -p SearchAgent -a fn=astar,heuristic=manhattanHeuristic

-Bineeta Gupta (1211257447)