# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
#
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

def depthFirstSearch(problem):
    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches the
    goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:

    print "Start:", problem.getStartState()
    print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    print "Start's successors:", problem.getSuccessors(problem.getStartState())
    """
    "*** YOUR CODE HERE"

    #'explored' will store the nodes that have been explored (aka expanded)
    explored = []
    #actions will store the series of actions required to get from the start state to the goal
    actions = util.Queue()
    #'parents' is used to keep track of the state that preceeds each state and the direciton the earlier state took to get to them
    #{state: [preceedingState, direction]}
    parents = {}
    #create a stack that will store the discovered states and push the start state onto the stack
    frontier = util.Stack()
    frontier.push(problem.getStartState())
    #while there is at least one state still on the stack, continue searching
    while not (frontier.isEmpty()):
        state = frontier.pop()
        #if the current state is a goal state, then get the path from start to the goal
        if problem.isGoalState(state):
            #while the current state is not the start state, add the direction that led to the current state to 'actions' and change the state to the one that preceeded it
            while not (state == problem.getStartState()):
                actions.push(parents[state][1])
                state = parents[state][0]
            return actions.list
        #otherwise, if the current state has not been explored yet, add it to 'explored' and add unexplored successors to the stack
        elif state not in explored:
            explored.append(state)
            successors = problem.getSuccessors(state)
            #for each successor, if the state has not yet been explored, push it to the stack and add its parent info to the dictionary
            for successor in successors:
                successorState = successor[0]
                directionToSuccessor = successor[1]
                if successorState not in explored:
                    frontier.push(successorState)
                    parents[successorState] = [state, directionToSuccessor]

    util.raiseNotDefined()

def breadthFirstSearch(problem):
    """Search the shallowest nodes in the search tree first."""
    "*** YOUR CODE HERE ***"

    #'explored' will store the nodes that have been explored (aka expanded)
    explored = []
    #actions will store the series of actions required to get from the start state to the goal
    actions = util.Queue()
    #use a dictionary to keep track of the state that preceeds each state and the direciton the earlier state took to get to them
    #{state: [preceedingState, direction]}
    parents = {}
    #create a queue that will store the discovered states and push the start state onto the queue
    frontier = util.Queue()
    frontier.push(problem.getStartState())
    #while there is at least one state still on the queue, continue searching
    while not (frontier.isEmpty()):
        state = frontier.pop()
        #if the current state is a goal state, then get the path from start to the goal
        if problem.isGoalState(state):
            #while the current state is not the start state, add the direction that led to the current state to 'actions' and change the state to the one that preceeded it
            while not (state == problem.getStartState()):
                actions.push(parents[state][1])
                state = parents[state][0]
            return actions.list
        #otherwise, if the current state has not been explored yet, add it to 'explored' and add unexplored successors to the queue
        elif state not in explored:
            explored.append(state)
            successors = problem.getSuccessors(state)
            for successor in successors:
                successorState = successor[0]
                successor = successor[1]
                #if the state has not yet been explored and it has not been discovered by another state, push it to the queue
                if (successorState not in explored) and (successorState not in parents):
                    frontier.push(successorState)
                    parents[successorState] = [state, successor]

    util.raiseNotDefined()

def uniformCostSearch(problem):
    """Search the node of least total cost first."""
    "*** YOUR CODE HERE ***"

    #'explored' will store the nodes that have been explored (aka expanded)
    explored = []
    #actions will store the series of actions required to get from the start state to the goal
    actions = util.Queue()
    #use a dictionary to keep track of the state that preceeds each state and the direciton the earlier state took to get to them
    #{state: [preceedingState, direction, cost]}
    parents = {}
    #create a priority queue that will store the discovered states and the cost to reach them
    frontier = util.PriorityQueue()
    frontier.push(problem.getStartState(), 0)
    #while there is at least one state still on the queue, continue searching
    while not (frontier.isEmpty()):
        state = frontier.pop()
        #if the current state is a goal state, then get the path from start to the goal
        if problem.isGoalState(state):
            #while the current state is not the start state, add the direction that led to the current state to 'actions' and change the state to the one that preceeded it
            while not (state == problem.getStartState()):
                actions.push(parents[state][1])
                state = parents[state][0]
            return actions.list
        #otherwise, if the current state has not been explored yet, add it to 'explored'
        elif state not in explored:
            explored.append(state)
            successors = problem.getSuccessors(state)
            for successor in successors:
                successorState = successor[0]
                directionToSuccessor = successor[1]
                successorCost = successor[2]
                if successorState not in explored:
                    #if the current state is the start state, then add the successor to the priority queue and parents dictionary with the cost being: cost to successor + 0
                    if state == problem.getStartState():
                        frontier.push(successorState, successorCost)
                        parents[successorState] = [state, directionToSuccessor, successorCost]
                    #otherwise, the current state is not the start state which means that it has some cost associated with it
                    else:
                        parentCost = parents[state][2]
                        #if the successor has no prior parent, add it to the priority queue and parents dictionary with cost being: cost to successor + cost to current state
                        if successorState not in parents:
                            frontier.push(successorState, successorCost + parentCost)
                            parents[successorState] = [state, directionToSuccessor, successorCost + parentCost]
                        #if the successor has a prior parent and its old cost is > (cost to successor + cost to current state), update its costs in the queue and dictionary
                        elif parents[successorState][2] > (successorCost + parentCost):
                            frontier.update(successorState, successorCost + parentCost)
                            parents[successorState] = [state, directionToSuccessor, successorCost + parentCost]


    util.raiseNotDefined()

def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""
    "*** YOUR CODE HERE ***"

    #'explored' will store the nodes that have been explored (aka expanded)
    explored = []
    #actions will store the series of actions required to get from the start state to the goal
    actions = util.Queue()
    #use a dictionary to keep track of the state that preceeds each state and the direciton the earlier state took to get to them
    #{state: [preceedingState, direction, cost]}
    parents = {}
    #create a priority queue that will store the discovered states and the cost to reach them
    frontier = util.PriorityQueue()
    frontier.push(problem.getStartState(), 0)
    #while there is at least one state still on the queue, continue searching
    while not (frontier.isEmpty()):
        state = frontier.pop()
        #if the current state is a goal state, then get the path from start to the goal
        if problem.isGoalState(state):
            #while the current state is not the start state, add the direction that led to the current state to 'actions' and change the state to the one that preceeded it
            while not (state == problem.getStartState()):
                actions.push(parents[state][1])
                state = parents[state][0]
            return actions.list
        #otherwise, if the current state has not been explored yet, add it to 'explored'
        elif state not in explored:
            explored.append(state)
            successors = problem.getSuccessors(state)
            for successor in successors:
                successorState = successor[0]
                directionToSuccessor = successor[1]
                successorCost = successor[2]
                heuristicCost = heuristic(successorState, problem)
                if successorState not in explored:
                    #if the current state is the start state, then add the successor to the priority queue and parents dictionary with the cost being: cost to successor + 0
                    if state == problem.getStartState():
                        frontier.push(successorState, successorCost + heuristicCost)
                        parents[successorState] = [state, directionToSuccessor, successorCost]
                    #otherwise, the current state is not the start state which means that it has some cost associated with it
                    else:
                        parentCost = parents[state][2]
                        #if the successor has no prior parent, add it to the priority queue and parents dictionary with cost being: cost to successor + cost to current state
                        if successorState not in parents:
                            frontier.push(successorState, successorCost + parentCost + heuristicCost)
                            parents[successorState] = [state, directionToSuccessor, successorCost + parentCost]
                        #if the successor has a prior parent and its old cost is > (cost to successor + cost to current state), update its costs in the queue and dictionary
                        elif parents[successorState][2] > (successorCost + parentCost):
                            frontier.update(successorState, successorCost + parentCost + heuristicCost)
                            parents[successorState] = [state, directionToSuccessor, successorCost + parentCost]

    util.raiseNotDefined()


# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
