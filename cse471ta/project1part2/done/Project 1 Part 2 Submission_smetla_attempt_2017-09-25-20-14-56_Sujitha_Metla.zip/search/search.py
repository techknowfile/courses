# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

def depthFirstSearch(problem):
    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches the
    goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:

    print "Start:", problem.getStartState()
    print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    print "Start's successors:", problem.getSuccessors(problem.getStartState())"""
    """Depth First Search uses Stack DataStructure to track all the nodes"""
    """Visit node, Check if goal has been reached. 
    If not get the successors and add to stack(LIFO). 
    Iterate the process until goal is reached."""
    """Tracking the visited nodes"""
    closedListOfNodes = []
    """Stack to track all the successor nodes"""
    openListOfNodes = util.Stack()
    """Pushing start state in to the stack"""
    openListOfNodes.push( (problem.getStartState(), []) )
    """Check whether Stack is empty or not"""
    while not openListOfNodes.isEmpty():
        (nodeState, direction) = openListOfNodes.pop()
        """Check whether node has been visited or not as this is undirected graph"""
        if not nodeState in closedListOfNodes:
            """Checking whether current node is Goal node or not"""
            if problem.isGoalState(nodeState):
                """If Goal is reached return the direction array"""
                return direction
            else:
                """Append the visited node to nodesVisited array"""
                closedListOfNodes.append(nodeState)
                """Get successor nodes from the current node"""
                for (successorNode, nextStep, stepCost) in problem.getSuccessors(nodeState):
                    updateDirections = list(direction)
                    updateDirections.append(nextStep)
                    openListOfNodes.push((successorNode, updateDirections))
    return []


def breadthFirstSearch(problem):
    """Search the shallowest nodes in the search tree first."""
    """Depth First Search uses Queue DataStructure to track all the nodes"""
    """Visit node, Check if goal has been reached. 
    If not get the successors and add to queue(FIFO). 
    Iterate the process until goal is reached."""
    """Tracking the visited nodes"""
    closedListOfNodes = []
    """Queue to track all the successor nodes"""
    openListOfNodes = util.Queue()
    """Pushing start state in to the queue"""
    openListOfNodes.push((problem.getStartState(), []))
    """Check whether Queue is empty or not"""
    while not openListOfNodes.isEmpty():
        (nodeState, direction) = openListOfNodes.pop()
        """Check whether node has been visited or not"""
        if not nodeState in closedListOfNodes:
            """Checking whether current node is Goal node or not"""
            if problem.isGoalState(nodeState):
                """If Goal is reached return the direction array"""
                return direction
            else:
                """Append the visited node to nodesVisited array"""
                closedListOfNodes.append(nodeState)
                """Get successor nodes from the current node"""
                for (successorNode, nextStep, stepCost) in problem.getSuccessors(nodeState):
                    updateDirections = list(direction)
                    updateDirections.append(nextStep)
                    openListOfNodes.push((successorNode, updateDirections))
    return []

def uniformCostSearch(problem):
    """Search the node of least total cost first."""
    """Uniform Cost Search uses Priority Queue DataStructure to track all the nodes"""
    """Visit node, Check if goal has been reached. 
    If not get the successors and calculate the cost. 
    Iterate the process until goal is reached."""
    """Tracking the visited nodes"""
    closedListOfNodes = []
    """Queue to track all the successor nodes"""
    openListOfNodes = util.PriorityQueue()
    """Pushing start state in to the priority queue"""
    openListOfNodes.push((problem.getStartState(), [],0),0)
    """Check whether Queue is empty or not"""
    while not openListOfNodes.isEmpty():
        (nodeState, direction, cost) = openListOfNodes.pop()
        """Check whether node has been visited or not"""
        if not nodeState in closedListOfNodes:
            """Checking whether current node is Goal node or not"""
            if problem.isGoalState(nodeState):
                """If Goal is reached return the direction array"""
                return direction
            else:
                """Append the visited node to nodesVisited array"""
                closedListOfNodes.append(nodeState)
                """Get successor nodes from the current node"""
                for (successorNode, nextStep, stepCost) in problem.getSuccessors(nodeState):
                    updateDirections = list(direction)
                    updateDirections.append(nextStep)
                    updatedStepCost = cost + stepCost
                    openListOfNodes.push((successorNode, updateDirections, updatedStepCost),updatedStepCost)
    return []

def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""
    """A* Search uses Priority Queue DataStructure to track all the nodes"""
    """Visit node, Check if goal has been reached. 
    If not get the successors and calculate the cost which is costOfTheNode+heuristicValueOfTheNode. 
    Iterate the process until goal is reached."""
    """Tracking the visited nodes"""
    closedListOfNodes = {}
    """Queue to track all the successor nodes"""
    openListOfNodes = util.PriorityQueue()
    """Pushing start state in to the priority queue"""
    openListOfNodes.push((problem.getStartState(), [],0),heuristic(problem.getStartState(), problem))
    """Check whether Queue is empty or not"""
    while not openListOfNodes.isEmpty():
        (nodeState, direction, cost) = openListOfNodes.pop()
        """Check whether node has been visited or not"""
        if not nodeState in closedListOfNodes.keys():
            """Checking whether current node is Goal node or not"""
            if problem.isGoalState(nodeState):
                """If Goal is reached return the direction array"""
                return direction
            else:
                """Append the visited node to nodesVisited array"""
                closedListOfNodes[nodeState] = cost
                """Get successor nodes from the current node"""
                for (successorNode, nextStep, stepCost) in problem.getSuccessors(nodeState):
                    updateDirections = list(direction)
                    updateDirections.append(nextStep)
                    updatedStepCost = cost + stepCost
                    totalCost = updatedStepCost + heuristic(successorNode, problem)
                    openListOfNodes.push((successorNode, updateDirections, updatedStepCost),totalCost)
    util.raiseNotDefined()


# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
