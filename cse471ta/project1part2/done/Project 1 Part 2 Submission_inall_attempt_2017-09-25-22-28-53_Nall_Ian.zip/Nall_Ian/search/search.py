# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util


class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return [s, s, w, s, w, w, s, w]


def depthFirstSearch(problem):
    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches the
    goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:

    print "Start:", problem.getStartState()
    print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    print "Start's successors:", problem.getSuccessors(problem.getStartState())
    """
    "*** YOUR CODE HERE ***"
    fringe = util.Stack()
    seen = []
    # print "Start:", problem.getStartState()
    # print "Start's successors:", problem.getSuccessors(problem.getStartState())
    # Other set up, tuple, direction, parent
    # fringe.push((problem.getStartState(), "Start", 0))
    fringe.push([(problem.getStartState(), [])])
    
    while not fringe.isEmpty():
        view = fringe.pop()
        see = view[len(view)-1]
        see = see[0]
        # print "view ", view
        if problem.isGoalState(see):
            return [x[1] for x in view][1:]
        if see not in seen:
            seen.append(see)
            #print "Exploring: ", view
            for successor in problem.getSuccessors(see):
                if successor[0] not in seen:
                    path = view[:]
                    path.append(successor)
                    #print "Successors path: ", path
                    fringe.push(path)
    return []
'''if problem.isGoalState(view):
        else :
            soon = problem.getSuccessors(view)
            for i in fringe.length():
                fringe.push(soon[i))'''

def breadthFirstSearch(problem):
    """Search the shallowest nodes in the search tree first."""
    "*** YOUR CODE HERE ***"
    fringe = util.Queue()
    seen = []
    # print "Start:", problem.getStartState()
    # print "Start's successors:", problem.getSuccessors(problem.getStartState())
    # Other set up, tuple, direction, parent
    # fringe.push((problem.getStartState(), "Start", 0))
    fringe.push([(problem.getStartState(), [])])
    
    while not fringe.isEmpty():
        view = fringe.pop()
        see = view[len(view)-1]
        see = see[0]
        # print "view ", view
        if problem.isGoalState(see):
            return [x[1] for x in view][1:]
        if see not in seen:
            seen.append(see)
            #print "Exploring: ", view
            for successor in problem.getSuccessors(see):
                if successor[0] not in seen:
                    path = view[:]
                    path.append(successor)
                    #print "Successors path: ", path
                    fringe.push(path)
    return []


def uniformCostSearch(problem):
    """Search the node of least total cost first."""
    # print "Start:", problem.getStartState()
    # print "Start's successors:", problem.getSuccessors(problem.getStartState())
    # Other set up, tuple, direction, parent
    # fringe.push((problem.getStartState(), "Start", 0))
    "*** YOUR CODE HERE ***"
    fringe = util.PriorityQueue()
    seen = set()
    
    
    #fringe.push(list, 0)
    fringe.push([(problem.getStartState(), [], 0)], 0)
    
    while not fringe.isEmpty():
        view = fringe.pop()
        see = view[len(view)-1]
        see = see[0]
        
        #print "view ", view
        if problem.isGoalState(see):
            return [x[1] for x in view][1:]
        if see not in seen:
            seen.add(see)
            #print "Exploring: ", view
            #print "See: ", see
            for successor in problem.getSuccessors(see):
                if successor[0] not in seen:
                    #print "View before path", view
                    path = view[:]
                    
                    lst = list(successor)
                    cost = view[len(view)-1][2] + successor[2]
                    lst[2] += view[len(view)-1][2]
                    t = tuple(lst)
                    path.append(t)
                    
                    #print "Successors path b4 append: ", path
                    
                    #print "Successors path: ", path
                    #print "Cost: ", cost
                    #print "Seen: ", seen
                    fringe.update(path, cost)
                    #fringe.update(path, cost)
    return []
	
#util.raiseNotDefined()

def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0


def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""
    "*** YOUR CODE HERE ***"
    fringe = util.PriorityQueue()
    seen = []
    
    
    #fringe.push(list, 0)
    iCost = heuristic(problem.getStartState(), problem)
    fringe.push([(problem.getStartState(), [], 0+iCost)], iCost)
    
    while not fringe.isEmpty():
        view = fringe.pop()
        see = view[len(view)-1]
        see = see[0]
        
        #print "view ", view
        if problem.isGoalState(see):
            return [x[1] for x in view][1:]
        
        if see not in seen:
            seen.append(see)
            #print "Exploring: ", view
            #print "See: ", see
            for successor in problem.getSuccessors(see):
                if successor[0] not in seen:
                    #print "View before path", view
                    #cost = view[0][2]
                    path = view[:]
                    lst = list(successor)
                    cost = view[len(view)-1][2] + successor[2] + heuristic(successor[0], problem)
                    lst[2] += view[len(view)-1][2]
                    t = tuple(lst)
                    path.append(t)
                    #print "Cost: ", cost
                    #print "view cost: ", view[len(view)-1][2]
                    #print "Successor cost: ", successor[2]
                    #print "Successor Heuristic: ", heuristic(successor[0], problem)
                    #print "view's heuristic: ", heuristic(view[len(view)-1][0],problem)
                    #Stopping error
                    #cost = view[len(view)-1][2] + successor[2] + heuristic(successor[0], problem)+heuristic(view[len(view)-1],problem)
                    #print "Successors path b4 append: ", path
                    #print "Successors path: ", path
                    #print "Cost: ", cost
                    #print "Seen: ", seen
                    #fringe.push(path, cost)
                    fringe.update(path, cost)
                    
    return []


# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
