# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

def depthFirstSearch(problem):
    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches the
    goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:

    print "Start:", problem.getStartState()
    print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    print "Start's successors:", problem.getSuccessors(problem.getStartState())
    """
    "*** YOUR CODE HERE ***"    
    solution = list()
    frontier = util.Stack()   
    #initialize the frontier using the initial state of problem
    frontier.push([(problem.getStartState(),'',None)]) # create first triple ((x,y),'Dir',i_cost)
    #initialize the explored set to be empty 
    explored = set([])   
    #loop do
    while(1):
    #if the frontier is empty then return failure        
        if frontier.isEmpty():
            return       
    #choose a leaf node and remove it from the frontier
        solution = frontier.pop()
        chosen_node = solution[0][0]
    #if the node contains a goal state 
        if problem.isGoalState(chosen_node):
    #then return the corresponding solution
            corresponding_solution = []
            #print solution
            for i in range(len(solution)-2,-1,-1):                
                #print solution[i][1] 
                corresponding_solution.append(solution[i][1])
            #print corresponding_solution    
            return corresponding_solution        
    #add the node to the explored set
        explored.add(chosen_node)
    #expand the chosen node, adding the resulting nodes to the frontier    
        for new_node in problem.getSuccessors(chosen_node): 
            expandedsolution = list(solution)
            expandedsolution.insert(0,new_node)
    #only if not in the frontier or explored set
            if new_node[0] not in explored:
                frontier.push(expandedsolution)   
    #util.raiseNotDefined()  

def breadthFirstSearch(problem):
    """Search the shallowest nodes in the search tree first."""
    "*** YOUR CODE HERE ***"
    solution = []
    frontier = util.Queue()   
    #initialize the frontier using the initial state of problem
    frontier.push([(problem.getStartState(),'',0)]) # create first triple ((x,y),'Dir',i_cost)
    #initialize the explored set to be empty 
    explored = []   
    #loop do
    while(1):
    #if the frontier is empty then return failure        
        if frontier.isEmpty():
            return 
        solution = frontier.pop()
    #choose a leaf node and remove it from the frontier
        chosen_node = solution[0][0]
    #if the node contains a goal state 
        if problem.isGoalState(chosen_node):
    #then return the corresponding solution
            corresponding_solution = []
            #print solution
            for i in range(len(solution)-2,-1,-1):                
                #print solution[i][1] 
                corresponding_solution.append(solution[i][1])
            #print corresponding_solution    
            return corresponding_solution        
    #add the node to the explored set
        if chosen_node not in explored:
            explored.append(chosen_node)
        #expand the chosen node, adding the resulting nodes to the frontier    
            for new_node in problem.getSuccessors(chosen_node): 
                expandedsolution = list(solution)
                expandedsolution.insert(0,new_node)
        #only if not in the frontier or explored set
                if new_node[0] not in explored:
                    frontier.push(expandedsolution)   
        #util.raiseNotDefined() 

def uniformCostSearch(problem):
    """Search the node of least total cost first."""
    "*** YOUR CODE HERE ***"
    "FROM THE BOOK"
    '''The algorithm is identical to the general graph search algorithm, 
    except for the use of a priority queue and the addition of an extra check
    in case a shorter path to a frontier state is discovered.
    The data structure for frontier needs to support efficient membership testing,
    so it should combine the capabilities of a priority queue and a hash table.'''   
    #frontier <- a priority queue ordered by PATH-COST, with node as the only element
       
    solution = list()
    #function UNIFORM-COST-SEARCH(problem) returns a solution, or failure
    frontier = util.PriorityQueue()   
    #node a <- node with STATE = problem.INITIAL-STATE, PATH-COST = 0
    STATE = problem.getStartState()
    frontier.push([(STATE,'',0)],0) 
    #explored <- an empty set
    explored = set([])   
    #loop do
    while(1):
    #if EMPTY?(frontier ) then return failure        
        if frontier.isEmpty():
            return 
    #node <- POP(frontier ) /* chooses the lowest-cost node in frontier */     
        solution = frontier.pop()
        chosen_node = solution[0]
        cost_counter = solution[0][2]
    #if problem.GOAL-TEST(node.STATE) then return SOLUTION(node)    
        if problem.isGoalState(chosen_node[0]):
            corresponding_solution = []
            #print solution
            for i in range(len(solution)-2,-1,-1):                
                #print solution[i][1] 
                corresponding_solution.append(solution[i][1])
            #print corresponding_solution    
            return corresponding_solution        
    #add node.STATE to explored
        else:
            if chosen_node[0] not in explored:
                explored.add(chosen_node[0])
        #for each action in problem.ACTIONS(node.STATE) do 
        #child <- CHILD-NODE(problem, node, action)
                PATH_COST = 0
                for new_node in problem.getSuccessors(chosen_node[0]): 
                    PATH_COST = new_node[2] + cost_counter
                    expandedsolution = list(solution)
                    new_new_node = (new_node[0],new_node[1],PATH_COST) #UPDATED!!!
                    expandedsolution.insert(0,new_new_node)
        #if child.STATE is not in explored or frontier then
                    #if new_node[0] not in explored:
        #frontier <- INSERT(child,frontier )                   
        #else if child.STATE is in frontier with higher PATH-COST then
        #replace that frontier node with child  (handeld by priorityqueue)                         
                    frontier.push(expandedsolution,PATH_COST)
        #util.raiseNotDefined()

def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""
    "*** YOUR CODE HERE ***"
    '''The algorithm is identical to UNIFORM-COST-SEARCH except
    that A* uses g + h instead of g.'''
    
    #frontier <- a priority queue ordered by PATH-COST, with node as the only element
       
    solution = list()
    #function UNIFORM-COST-SEARCH(problem) returns a solution, or failure
    frontier = util.PriorityQueue()   
    #node a <- node with STATE = problem.INITIAL-STATE, PATH-COST = 0
    STATE = problem.getStartState()
    frontier.push([(STATE,'',0)],0) 
    #explored <- an empty set
    explored = []   
    #loop do
    while(1):
    #if EMPTY?(frontier ) then return failure        
        if frontier.isEmpty():
            return 
    #node <- POP(frontier ) /* chooses the lowest-cost node in frontier */     
        solution = frontier.pop()
        chosen_node = solution[0]
        cost_counter = solution[0][2]
    #if problem.GOAL-TEST(node.STATE) then return SOLUTION(node)    
        if problem.isGoalState(chosen_node[0]):
            corresponding_solution = []
            #print solution
            for i in range(len(solution)-2,-1,-1):                
                #print solution[i][1] 
                corresponding_solution.append(solution[i][1])
            #print corresponding_solution    
            return corresponding_solution        
    #add node.STATE to explored
        #print(chosen_node[0])
        #print(explored)
        if chosen_node[0] not in explored:
            explored.append(chosen_node[0])
    #for each action in problem.ACTIONS(node.STATE) do 
    #child <- CHILD-NODE(problem, node, action)
            for new_node in problem.getSuccessors(chosen_node[0]): 
                g = new_node[2] + cost_counter
                h = heuristic(new_node[0],problem)
                f = g + h # THE MAGIC HAPPENS HERE :) 
                expandedsolution = list(solution)
                new_new_node = (new_node[0],new_node[1],g) #UPDATED!!!
                expandedsolution.insert(0,new_new_node)
    #if child.STATE is not in explored or frontier then
                #if new_node[0] not in explored:
    #frontier <- INSERT(child,frontier )                   
    #else if child.STATE is in frontier with higher PATH-COST then
    #replace that frontier node with child  (handeld by priorityqueue)                         
                frontier.update(expandedsolution,f)
    #util.raiseNotDefined() 
    #util.raiseNotDefined()


# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
