# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
#
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""
import util
class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

def depthFirstSearch(problem):
    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches the
    goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:

    print "Start:", problem.getStartState()
    print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    print "Start's successors:", problem.getSuccessors(problem.getStartState())
    """
    """
    # Create a dictionary visited with states as the key and boolean as the value
    1. Get the start state and add it to the stack. Make visited[StartState] = true
    2. While loop in which the start state is popped, also while until the popped state = goal state.
    3. Inside the while loop, expand the popped state to its successors and add the successors to the stack if they have not been visited.
    4.
    """
    from util import Stack          #Implementing stack defined in util.py
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    e = Directions.EAST
    n = Directions.NORTH
    directionsList = []             # Empty list to store the directions to be performed to reach the food.
    stack = Stack()                 # stack to store the visited nodes
    visited = {}                    # dictionary visited which takes the position as the key and sets the value to a boolean varianble
    startState = problem.getStartState()
    node = (startState, directionsList)
    stack.push(node)
    if problem.isGoalState(startState): # if the start state is a goal state
        return directionsList
    while stack.isEmpty() == False:     # Until all the elements in the stack are popped
        parent = stack.pop()
        if problem.isGoalState(parent[0]):  # parent[0] contains the state
            return parent[1]                # parent[1] contains the path to the state
        if not parent[0] in visited.keys() :# If the key is not present in the dictionary, then it has not been visited.
            visited[parent[0]] = True       # Setting the key to true
            successors = problem.getSuccessors(parent[0])
            for successor in successors:    # looping through the successors
                state = successor[0]
                direction = successor[1]
                dirList = list(parent[1])
                dirList.append(direction)   # Adding the direction to the temporary list.
                stack.push((state,dirList))

    return directionsList   #returning empty list


#    "*** YOUR CODE HERE ***"
    util.raiseNotDefined()

def breadthFirstSearch(problem):
    """Search the shallowest nodes in the search tree first."""
    "*** YOUR CODE HERE ***"
    
    from util import Queue              # Implementing Queue defined in util.py
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    e = Directions.EAST
    n = Directions.NORTH
    directionsList = []                 # Empty list to store the directions to be performed to reach the food.
    queue = Queue()                     # stack to store the visited nodes
    visited = {}                        # dictionary visited which takes the position as the key and sets the value to a boolean varianble
    startState = problem.getStartState()
    node = (startState, directionsList)
    queue.push(node)
    visited[startState] = True          #dictionary with key startState set to True
    if problem.isGoalState(startState):
        return directionsList
    while queue.isEmpty() == False:     # Until the queue is empty
        parent = queue.pop()
        if problem.isGoalState(parent[0]):
            return parent[1]
        successors = problem.getSuccessors(parent[0])
        for successor in successors:
            state = successor[0]
            direction = successor[1]
            dirList = list(parent[1])
            cost = successor[2]
            if not state in visited.keys(): # Checking if the key is not present in the dictionary to check for visited states.
                visited[state] = True       # Setting the value with key as the state to true
                dirList.append(direction)
                queue.push((state,dirList))

    return directionsList   #returning empty list



def uniformCostSearch(problem):
    """Search the node of least total cost first."""
    "*** YOUR CODE HERE ***"
    from util import PriorityQueue         # Implementing priority queue defined in util.py
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    e = Directions.EAST
    n = Directions.NORTH
    directionsList = [] # Empty list to store the directions to be performed to reach the food.
    pqueue = PriorityQueue()     # stack to store the visited nodes
    visited = {}        # dictionary visited which takes the position as the key and sets the value to a boolean varianble
    startState = problem.getStartState()
    cost = 0            # Total cost value intialized to 0
    node = (startState, directionsList, cost)
    pqueue.push((node),cost)
    if problem.isGoalState(startState):
        return directionsList
    while pqueue.isEmpty() == False:
        parent = pqueue.pop()
        if problem.isGoalState(parent[0]):      # if the state is the goal state, return the list of direction
            return parent[1]
        if not parent[0] in visited.keys() :    # If the state has not been visited
            visited[parent[0]] = True           # set the value to true
            successors = problem.getSuccessors(parent[0])
            for successor in successors:        # Looping through the successors
                state = successor[0]
                direction = successor[1]
                cost = parent[2] + successor[2] # Getting the total cost
                dirList = list(parent[1])
                dirList.append(direction)
                pqueue.push((state,dirList,cost),cost)

    return directionsList   #returning empty list
    util.raiseNotDefined()

def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""
    "*** YOUR CODE HERE ***"
    from util import PriorityQueue
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    e = Directions.EAST
    n = Directions.NORTH
    directionsList = [] # Empty list to store the directions to be performed to reach the food.
    pqueue = PriorityQueue()     # stack to store the visited nodes
    visited = {}        # dictionary visited which takes the position as the key and sets the value to a boolean varianble
    startState = problem.getStartState()
    cost = 0            # Total cost value intialized to 0
    node = (startState, directionsList, cost)
    pqueue.push((node),cost)
    if problem.isGoalState(startState):
        return directionsList
    while pqueue.isEmpty() == False:
        parent = pqueue.pop()
        if problem.isGoalState(parent[0]):
            return parent[1]
        if not parent[0] in visited.keys() :        # if the state is not visited
            visited[parent[0]] = True               # setting the state visited part to true
            successors = problem.getSuccessors(parent[0])
            for successor in successors:            # looping through the successors
                state = successor[0]
                direction = successor[1]
                hCost = heuristic(state, problem)       # Cost calculated using the heuristic function
                dirList = list(parent[1])
                dirList.append(direction)
                cost = hCost + problem.getCostOfActions(dirList)    #Total cost by adding heuristic cost and cost of action.
                pqueue.push((state,dirList,cost),cost)


    return directionsList   #returning direction list
    util.raiseNotDefined()
    util.raiseNotDefined()


# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
