# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

def depthFirstSearch(problem):
    """
    Search the deepest next_states in the search tree first.

    Your search algorithm needs to return a list of actions that reac
    hes the
    goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:

    print "Start:", problem.getStartState()
    print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    print "Start's successors:", problem.getSuccessors(problem.getStartState())
    """
    
    #Using stack to add the next state to the top of the list
    #Then pop at the top of the list
    stack = util.Stack()
    
    #A Set to keep track of all the next_states visited
    visited = set()
    
    #Push a tuple of the first state and an empty list
    stack.push((problem.getStartState(), []))
    
    #As long as the stack is not empty
    while stack.isEmpty() == False: 
        
        #Get the next state and list of directions
        next_state, list_of_directions = stack.pop() 
        
        #Check the next state only if it has not been checked
        if next_state not in visited:
        
            #If the state is the Goal state 
            #return the list of directions to get there
            if problem.isGoalState(next_state):
                return list_of_directions
            
            #get a tuple of neighbors
            neighbors = problem.getSuccessors(next_state)
            
            #check every neighbor
            for i in neighbors:
            
                #Get state direction and cost from neighbor
                i_state, i_direction, i_cost = i
                
                #Update the list of directions
                new_list_of_directions = list_of_directions + [i_direction]
                
                #Push the neighboring state 
                #and direction on how to get there
				#to the end of the stack
                stack.push((i_state, new_list_of_directions))
                
            #add the state to checked
            visited.add(next_state)    
    
    #If the the list of directions to the goal was not sent send an empty list 
    return []
    
    util.raiseNotDefined()
    
def breadthFirstSearch(problem):
    """Search the shallowest next_states in the search tree first."""
    "*** YOUR CODE HERE ***"
    
	#Using queue to add the next state to the bottom of the list
    #Then pop at the top of the list
    queue = util.Queue()
    
    #A Set to keep track of all the next_states visited
    visited = set()

    #Push a tuple of the first state and an empty list
    queue.push((problem.getStartState(), []))
    
    #As long as the queue is not empty
    while queue.isEmpty() == False: 
    
        #Get the next state and list of directions
        next_state, list_of_directions = queue.pop() 
        
        #Check the next state only if it has not been checked
        if next_state not in visited:
        
            #If the state is the Goal state 
            #return the list of directions to get there
            if problem.isGoalState(next_state):
                return list_of_directions
                
            #get a tuple of neighbors
            neighbors = problem.getSuccessors(next_state)
            
            #check every neighbor
            for i in neighbors:
            
                #Get state direction and cost from neighbor
                i_state, i_direction, i_cost = i
                
                #Update the list of directions
                new_list_of_directions = list_of_directions + [i_direction]
                
                #Push the neighboring state 
                #and direction on how to get there
				#to the beginning of the queue
                queue.push((i_state, new_list_of_directions))
                
            #add the state to checked
            visited.add(next_state)
    
    #If the the list of directions to the goal was not sent send an empty list 
    return []
    
    util.raiseNotDefined()

def uniformCostSearch(problem):
    """Search the next_state of least total cost first."""
    "*** YOUR CODE HERE ***"
    
	#Using a priority queue
	#because of giving a priority of each cost of the heuristic
    p_queue = util.PriorityQueue()
    
    #A Set to keep track of all the next_states visited
    visited = set()

    #Push a tuple of the 
    #(first state and an empty list)
    #seting the heuristic to 0
    p_queue.push((problem.getStartState(), []), 0)
    
    #As long as the queue is not empty
    while p_queue.isEmpty() == False: 
        
        #Get the next state and list of directions
        next_state, list_of_directions = p_queue.pop() 
        
        #Check the next state only if it has not been checked
        if next_state not in visited:
            
            #If the state is the Goal state 
            #return the list of directions to get there
            if problem.isGoalState(next_state):
                return list_of_directions
            
            #get a tuple of neighbors
            neighbors = problem.getSuccessors(next_state)
            
            #check every neighbor
            for i in neighbors:
                
                #Get state direction and cost from neighbor
                i_state, i_direction, i_cost = i
                
                #Update the list of directions
                new_list_of_directions = list_of_directions + [i_direction]
                
				#Getting the new cost from the new list of directions
                new_cost = problem.getCostOfActions(new_list_of_directions)
                
				#Pushing the neighbor state, new list, and new cost
                p_queue.push((i_state, new_list_of_directions), new_cost) 
                
            #add the state to checked
            visited.add(next_state)    
    
    #If the the list of directions to the goal was not sent send an empty list 
    return []
    
    util.raiseNotDefined()

def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the next_state that has the lowest combined cost and heuristic first."""
    "*** YOUR CODE HERE ***"
    
	#Using a priority queue
	#because of giving a priority of each cost of the heuristic
    p_queue = util.PriorityQueue()
    
    #A Set to keep track of all the next_states visited
    visited = set()

    #Push a tuple of the 
    #(first state and an empty list)
    #setting the heuristic to the parameter heuristic
    p_queue.push((problem.getStartState(), []), heuristic(problem.getStartState(), problem))
    
    #As long as the queue is not empty
    while p_queue.isEmpty() == False: 
        
        #Get the next state and list of directions
        next_state, list_of_directions = p_queue.pop() 
        
        #Check the next state only if it has not been checked
        if next_state not in visited:
            
            #If the state is the Goal state 
            #return the list of directions to get there
            if problem.isGoalState(next_state):
                return list_of_directions
            
            #get a tuple of neighbors
            neighbors = problem.getSuccessors(next_state)
            
            #check every neighbor
            for i in neighbors:
                
                #Get state direction and cost from neighbor
                i_state, i_direction, i_cost = i
                
                #Update the list of directions
                new_list_of_directions = list_of_directions + [i_direction]
                
				#Getting the new cost adding the heuristic
                new_cost = problem.getCostOfActions(new_list_of_directions) + heuristic(i_state, problem)
                
				#Pushing the neighbor state, new list, and new cost
                p_queue.push((i_state, new_list_of_directions), new_cost) 
            
            #add the state to checked
            visited.add(next_state)    
			
    #If the the list of directions to the goal was not sent send an empty list 
    return []
    
    util.raiseNotDefined()


# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
